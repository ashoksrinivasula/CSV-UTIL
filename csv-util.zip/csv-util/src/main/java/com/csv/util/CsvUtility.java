package com.csv.util;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvListReader;
import org.supercsv.io.ICsvListReader;
import org.supercsv.prefs.CsvPreference;

import com.mysql.jdbc.StringUtils;


public class CsvUtility {

    public static void main(String[] args){

        ICsvListReader listReader = null;
        try {
            String fileName =  args[0];
            String targetFIle = args[1];
            listReader = new CsvListReader(new FileReader(fileName), CsvPreference.TAB_PREFERENCE);
            final String[] header =  listReader.getHeader(true); // skip the header (can't be used with CsvListReader
            int amountOfColumns=listReader.length();
            CellProcessor[] processor = new CellProcessor[amountOfColumns];
            List<Object> customerList;
            int lc_index=0;              
            String str = header[0]+"\n";
            for(String s:str.split(",")){
                if(s.trim().equalsIgnoreCase("lookup_code")){
                    break;
                }
                lc_index++;
            }               
            File report = new File(targetFIle);
            if(report.exists()){
                report.delete();
            }
            FileUtils.write(report, str, Charset.forName("UTF-8"), true);
            while((customerList = listReader.read(processor)) != null ) {
                String tempStrng = (String)customerList.get(0);
                String[] tokens = tempStrng.split(",");
                String lc_value = tokens[lc_index];
                if(!(StringUtils.isNullOrEmpty(lc_value) || lc_value.equalsIgnoreCase("null") || lc_value.equalsIgnoreCase("space"))){
                    FileUtils.write(report, (String) customerList.get(0)+"\n", Charset.forName("UTF-8"), true);
                }
            }
        }catch(ArrayIndexOutOfBoundsException e){
            System.out.println("Please Eneter input and output Csv files");
        }catch(Exception e){
            e.printStackTrace();
        }
        finally {
            if( listReader != null ) {
                try {
                    listReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


    }
}
