package gov.uspto.pe2e.dav.document.etl.util;

import java.util.Collections;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.pe2e.dav.document.etl.model.message.DeletedDocCodeResponse;
import gov.uspto.pe2e.dav.document.etl.model.message.DocCodeResponse;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.SdwpDocumentResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RunWith(MockitoJUnitRunner.class)
public class RestServiceClientTest {

    private RestServiceClient restServiceClient;

    @Before
    public void setup() {
        String sdwpUrl = "http://sdwp-extraction.sit.uspto.gov/DocAccessService/services/batch/sirdev/application/";
        String docCodeUrl = "http://dav.uspto.gov/message-services/docCodes?count=10000";
        String messageServiceDeletedDocCodesUrl = "http://dav.dev.uspto.gov/message-services/docCodes/deleted?count=10000";
        restServiceClient = new RestServiceClient(sdwpUrl, docCodeUrl,messageServiceDeletedDocCodesUrl, 3000, 60000);
    }

    @Test
    public void testSdwpServiceCall() {
        SdwpDocumentResponse documentResponse =
                restServiceClient.getSDWPDocuments("10126832", Collections.singletonList("E4EUDWZOPP1GUI3"));
        log.debug("documentResponse" + documentResponse);
        Assert.assertNotNull(documentResponse);
    }

    @Test
    public void testMessageServiceCall() {
        DocCodeResponse docCodeResponse = restServiceClient.getDocCodes();
        log.debug("docCodeResponse " + docCodeResponse);
        Assert.assertNotNull(docCodeResponse);
    }
    
    @Test
    public void testgetDeletedDocCodesCall() {
    	DeletedDocCodeResponse deletedDocCodeResponse = restServiceClient.getDeletedDocCodes();
        log.debug("deletedDocCodeResponse " + deletedDocCodeResponse);
        Assert.assertNotNull(deletedDocCodeResponse);
    }

}