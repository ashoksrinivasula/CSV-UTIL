package gov.uspto.pe2e.dav.document.etl.service;

import gov.uspto.pe2e.dav.document.etl.model.notification.Action;
import gov.uspto.pe2e.dav.document.etl.model.notification.Details;
import gov.uspto.pe2e.dav.document.etl.model.notification.Document;
import gov.uspto.pe2e.dav.document.etl.model.notification.Notification;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.ApplicationMetadata;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.DocumentMetadata;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.PackageMetadata;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.SdwpDocumentResponse;
import gov.uspto.pe2e.dav.document.etl.util.MessageDeserializer;
import gov.uspto.pe2e.dav.document.etl.util.RestServiceClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ETLServiceTest {

    private ETLService etlService;

    @Mock
    private DossierService dossierService;
    @Mock
    private PackageService packageService;
    @Mock
    private DocumentService documentService;
    @Mock
    private RestServiceClient restServiceClient;
    @Mock
    private MessageDeserializer messageDeserializer;


    @Before
    public void setup() {
        etlService = new ETLService(packageService, restServiceClient, dossierService, documentService, messageDeserializer);
        doNothing().when(packageService).processPackages(anyList(), anyString());
        when(restServiceClient.getSDWPDocuments(anyString(), anyList())).thenReturn(createSdwpResponse());
        when(messageDeserializer.convert(anyString())).thenReturn(createNotification(Action.NEW));
        when(dossierService.saveAndGetDosKey("123")).thenReturn("doskey");
    }

    @Test
    public void testProcessNotificationNewAction() {
        etlService.processNotification("test");
        verify(messageDeserializer, times(1)).convert(anyString());
        verify(dossierService, times(1)).saveAndGetDosKey(anyString());
        verify(packageService, times(1)).processPackages(anyList(), anyString());
    }

    @Test
    public void testProcessNotificationNewActionNullSDWPResult() {
        SdwpDocumentResponse sdwpDocumentResponse = createSdwpResponse();
        sdwpDocumentResponse.setResultBag(null);
        when(restServiceClient.getSDWPDocuments(anyString(), anyList())).thenReturn(sdwpDocumentResponse);

        etlService.processNotification("test");
        verify(messageDeserializer, times(1)).convert(anyString());
        verify(dossierService, times(0)).saveAndGetDosKey(anyString());
        verify(packageService, times(0)).processPackages(anyList(), anyString());
    }

    @Test
    public void testProcessNotificationNewActionEmptySDWPResult() {
        SdwpDocumentResponse sdwpDocumentResponse = createSdwpResponse();
        sdwpDocumentResponse.setResultBag(Collections.emptyList());
        when(restServiceClient.getSDWPDocuments(anyString(), anyList())).thenReturn(sdwpDocumentResponse);

        etlService.processNotification("test");
        verify(messageDeserializer, times(1)).convert(anyString());
        verify(dossierService, times(0)).saveAndGetDosKey(anyString());
        verify(packageService, times(0)).processPackages(anyList(), anyString());
    }

    @Test
    public void testProcessNotificationUpdateAction() {
        when(messageDeserializer.convert(anyString())).thenReturn(createNotification(Action.UPDATE));
        etlService.processNotification("test");
        verify(messageDeserializer, times(1)).convert(anyString());
        verify(dossierService, times(1)).saveAndGetDosKey(anyString());
        verify(packageService, times(1)).processPackages(anyList(), anyString());
    }

    @Test
    public void testProcessNotificationDeleteAction() {
        when(messageDeserializer.convert(anyString())).thenReturn(createNotification(Action.DELETE));
        doNothing().when(documentService).delete(anyList());
        etlService.processNotification("test");
        verify(documentService, times(1)).delete(anyList());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testProcessNotificationSerializerError() {
        when(messageDeserializer.convert(anyString())).thenThrow(new IllegalArgumentException("parse error"));
        etlService.processNotification("test");
        verify(restServiceClient, times(0)).getSDWPDocuments(anyString(), anyList());
    }

    private SdwpDocumentResponse createSdwpResponse() {
        DocumentMetadata documentMetadata = new DocumentMetadata();
        PackageMetadata packageMetadata = new PackageMetadata();
        packageMetadata.setDocuments(Collections.singletonList(documentMetadata));

        ApplicationMetadata applicationMetadata = new ApplicationMetadata();
        applicationMetadata.setApplicationId("123");
        applicationMetadata.setPackages(Collections.singletonList(packageMetadata));

        SdwpDocumentResponse response = new SdwpDocumentResponse();
        response.setResultBag(Collections.singletonList(applicationMetadata));
        return response;
    }

    private Notification createNotification(Action action) {
        Details details = new Details();
        Document document = new Document();
        document.setSourceSystemKey("test");
        details.setAction(action);
        details.setDocuments(Collections.singletonList(document));
        Notification notification = new Notification();
        notification.setAppId("123");
        notification.setDetails(details);
        return notification;
    }
}