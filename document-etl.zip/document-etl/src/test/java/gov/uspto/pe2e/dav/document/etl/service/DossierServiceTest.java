package gov.uspto.pe2e.dav.document.etl.service;

import gov.uspto.pe2e.dav.document.etl.entity.Dossier;
import gov.uspto.pe2e.dav.document.etl.repository.DossierRepository;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DossierServiceTest {

    private DossierService dossierService;
    @Mock
    private DossierRepository dossierRepository;

    @Before
    public void setUp() {
        dossierService = new DossierService(dossierRepository);
        when(dossierRepository.findByDosorinumber(anyString())).thenReturn(Optional.of(createDossier()));
        when(dossierRepository.merge(any())).thenReturn(createDossier());
    }

    @Test
    public void testSaveAndGetDosKeyExisting() {
        String dosKey = dossierService.saveAndGetDosKey("test");
        Assert.assertEquals("dos", dosKey);
    }

    @Test
    public void testSaveAndGetDosKeyNew() {
        when(dossierRepository.findById(any())).thenReturn(Optional.empty());
        when(dossierRepository.findByDosorinumber(anyString())).thenReturn(Optional.empty());
        String dosKey = dossierService.saveAndGetDosKey("test");
        Assert.assertNotNull(dosKey);
    }

    private Dossier createDossier() {
        Dossier dossier = new Dossier();
        dossier.setDoskey("dos");
        return dossier;
    }
}