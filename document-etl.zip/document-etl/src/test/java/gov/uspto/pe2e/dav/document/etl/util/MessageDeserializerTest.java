package gov.uspto.pe2e.dav.document.etl.util;

import gov.uspto.pe2e.dav.document.etl.model.notification.Notification;
import gov.uspto.pe2e.dav.document.etl.model.topic.TopicMessage;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@Slf4j
public class MessageDeserializerTest {

    private static final int FIRST_ELEMENT = 0;
	private MessageDeserializer unmarshaller;

    @Before
    public void setup() {
        unmarshaller = new MessageDeserializer();
        unmarshaller.init();
    }

    @Test
    public void convertToJsonGoodPayload() {
    	String payload = "{\"appId\":\"10126832\",\"intakeSourceId\":\"8\",\"srcLastModTs\":\"2018-09-01T11:00:00\","
    			+ "\"details\": {\"action\": \"new\",\"documents\":[{\"sourceSystemKey\":\"JUOVQTKARXEAPX4\",\"documentCode\": \"CLM\",\"closed\": false}]}}";
        Notification notification = unmarshaller.convert(payload);
        assertNotNull(notification);
    }

    @Test(expected = IllegalArgumentException.class)
    public void convertToJsonMissingDetails() {
        String payload = "{\"appId\":\"10126832\",\"intakeSourceId\":\"8\",\"srcLastModTs\":\"2018-09-01T11:00:00\"}";
        Notification notification = unmarshaller.convert(payload);
        log.info("Details " + notification.getDetails());
    }

    @Test(expected = IllegalArgumentException.class)
    public void convertToJsonMissingAction() {
        String payload = "{\"appId\":\"10126832\",\"intakeSourceId\":\"8\",\"srcLastModTs\":\"2018-09-01T11:00:00\","
    			+ "\"details\": {\"documents\":[{\"sourceSystemKey\":\"JUOVQTKARXEAPX4\",\"documentCode\": \"CLM\",\"closed\": false}]}}";
        Notification notification = unmarshaller.convert(payload);
        log.info("Action " + notification.getDetails().getAction());
    }

    @Test(expected = IllegalArgumentException.class)
    public void convertToJsonMissingDocuments() {
        String payload = "{\"appId\":\"10126832\",\"intakeSourceId\":\"8\",\"srcLastModTs\":\"2018-09-01T11:00:00\","
    			+ "\"details\": {\"action\": \"new\"}}";
        Notification notification = unmarshaller.convert(payload);
        log.info("Documents " + notification.getDetails().getDocuments());
    }

    @Test(expected = IllegalArgumentException.class)
    public void convertToJsonMissingSourceSystemKey() {
        String payload = "{\"appId\":\"10126832\",\"intakeSourceId\":\"8\",\"srcLastModTs\":\"2018-09-01T11:00:00\","
    			+ "\"details\": {\"action\": \"new\",\"documents\":[{\"documentCode\": \"CLM\",\"closed\": false}]}}";
        Notification notification = unmarshaller.convert(payload);
        log.info("SourceSystemKey " + notification.getDetails().getDocuments().get(FIRST_ELEMENT).getSourceSystemKey());
    }

    @Test(expected = IllegalArgumentException.class)
    public void convertToJsonBadPayload() {
        String payload = "test";
        unmarshaller.convert(payload);
    }

    @Test(expected = IllegalArgumentException.class)
    public void convertToJsonNullPayload() {
        String payload = null;
        unmarshaller.convert(payload);
    }

    @Test
    public void convertTopicMessageTest() {
        String payload = "{\"action\":\"start\",\"logMessage\":\"testing\"}";
        TopicMessage topicMessage = unmarshaller.convertTopicMessage(payload);
        assertEquals("start", topicMessage.getAction());
    }

    @Test(expected = IllegalArgumentException.class)
    public void convertTopicMessageBadPayloadTest() {
        String payload = "test";
        unmarshaller.convertTopicMessage(payload);
    }
}