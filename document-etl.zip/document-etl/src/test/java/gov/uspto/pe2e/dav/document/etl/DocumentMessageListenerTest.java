package gov.uspto.pe2e.dav.document.etl;

import gov.uspto.pe2e.dav.document.etl.service.ETLService;
import gov.uspto.pe2e.dav.document.etl.util.MessageSender;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpServerErrorException;

import javax.jms.JMSException;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class DocumentMessageListenerTest {

    private DocumentMessageListener documentMessageListener;

    @Mock
    private ETLService etlService;
    @Mock
    private  MessageSender messageSender;

    @Before
    public void setUp() {
        documentMessageListener = new DocumentMessageListener(etlService,messageSender);
    }

    @Test
    public void receive() throws JMSException {
        doNothing().when(etlService).processNotification(any());
        ActiveMQTextMessage activeMQTextMessage = new ActiveMQTextMessage();
        activeMQTextMessage.setText("test");
        documentMessageListener.receive(activeMQTextMessage);
        verify(etlService, times(1)).processNotification(any());
    }

    @Test
    public void receiveWithException() throws JMSException {
        doThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR)).when(etlService).processNotification(any());
        doNothing().when(messageSender).sendMessageToDocumentDlQueue(anyString(),anyInt());
        ActiveMQTextMessage activeMQTextMessage = new ActiveMQTextMessage();
        activeMQTextMessage.setText("test");
        documentMessageListener.receive(activeMQTextMessage);
        verify(etlService, times(1)).processNotification(any());
    }
}