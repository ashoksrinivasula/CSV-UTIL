package gov.uspto.pe2e.dav.document.etl.service;

import gov.uspto.pe2e.dav.document.etl.entity.JpxiLocalDms;
import gov.uspto.pe2e.dav.document.etl.entity.Package;
import gov.uspto.pe2e.dav.document.etl.entity.PackageStatus;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.DocumentMetadata;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.PackageMetadata;
import gov.uspto.pe2e.dav.document.etl.repository.JpxiLocalDmsRepository;
import gov.uspto.pe2e.dav.document.etl.repository.PackageRepository;
import gov.uspto.pe2e.dav.document.etl.repository.PackageStatusRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * @author yparambathkandy
 */
@RunWith(MockitoJUnitRunner.class)
public class PackageServiceTest {

    private PackageService packageService;

    @Mock
    private PackageRepository packageRepository;
    @Mock
    private JpxiLocalDmsRepository jpxiLocalDmsRepository;
    @Mock
    private PackageStatusRepository packageStatusRepository;
    @Mock
    private DocumentService documentService;

    @Before
    public void setUp() {
        packageService = new PackageService(packageRepository, packageStatusRepository,
                documentService, jpxiLocalDmsRepository);
        when(packageRepository.findByPckpxi(anyString())).thenReturn(Optional.of(createPackage()));
        when(packageStatusRepository.findByPstindstatus(anyInt())).thenReturn(Optional.of(createPackageStatus()));
        when(packageRepository.merge(any())).thenReturn(createPackage());
        doNothing().when(documentService).save(anyString(), any());
        when(jpxiLocalDmsRepository.merge(any())).thenReturn(null);
    }

    @Test
    public void testProcessPackagesNullInput() {
        packageService.processPackages(null, "test");
        verify(packageRepository, times(0)).findByPckpxi(anyString());
    }

    @Test
    public void testProcessPackages() {
        packageService.processPackages(packageMetadata(), "test");
        verify(packageRepository, times(1)).findByPckpxi(anyString());
        verify(packageStatusRepository, times(1)).findByPstindstatus(anyInt());
        verify(packageRepository, times(1)).merge(any());
        verify(documentService, times(1)).save(anyString(), any());
    }

    @Test
    public void testProcessPackagesNoDocuments() {
        List<PackageMetadata> packageMetadata = packageMetadata();
        packageMetadata.forEach(e -> e.setDocuments(null));
        packageService.processPackages(packageMetadata, "test");
        verify(documentService, times(0)).save(anyString(), any());
    }

    @Test
    public void testProcessPackagesJpxiLocalDmsExisting() {
        when(jpxiLocalDmsRepository.findByJpxiLocalDmsIdentityExtdocid(anyString())).thenReturn(Optional.of(new JpxiLocalDms()));
        List<PackageMetadata> packageMetadata = packageMetadata();
        packageMetadata.forEach(e -> e.setImageLoadDt("2019-04-02T00:00:00.000Z"));
        packageService.processPackages(packageMetadata, "test");

        verify(jpxiLocalDmsRepository, times(1)).findByJpxiLocalDmsIdentityExtdocid(anyString());
        verify(jpxiLocalDmsRepository, times(1)).merge(any());
    }

    @Test
    public void testProcessPackagesJpxiLocalDmsNew() {
        when(jpxiLocalDmsRepository.findByJpxiLocalDmsIdentityExtdocid(anyString())).thenReturn(Optional.empty());

        List<PackageMetadata> packageMetadata = packageMetadata();
        packageMetadata.forEach(e -> e.setImageLoadDt("2019-04-02T00:00:00.000Z"));
        packageService.processPackages(packageMetadata, "test");

        verify(jpxiLocalDmsRepository, times(1)).findByJpxiLocalDmsIdentityExtdocid(anyString());
        verify(jpxiLocalDmsRepository, times(1)).merge(any());
    }

    @Test
    public void testProcessPackagesDoesntExist() {
        when(packageRepository.findByPckpxi(anyString())).thenReturn(Optional.empty());
        packageService.processPackages(packageMetadata(), "test");
        verify(packageRepository, times(1)).findByPckpxi(anyString());
        verify(packageStatusRepository, times(1)).findByPstindstatus(anyInt());
        verify(packageRepository, times(1)).merge(any());
        verify(documentService, times(1)).save(anyString(), any());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testProcessPackagesNullStatus() {
        when(packageStatusRepository.findByPstindstatus(anyInt())).thenReturn(Optional.empty());
        packageService.processPackages(packageMetadata(), "test");
    }

    private List<PackageMetadata> packageMetadata() {
        PackageMetadata packageMetadata = new PackageMetadata();
        packageMetadata.setPackageId("test");
        packageMetadata.setPackageStatusId(10);
        packageMetadata.setMailRoomTs("2019-04-01T00:00:00.000Z");
        packageMetadata.setDocuments(Collections.singletonList(new DocumentMetadata()));
        return Collections.singletonList(packageMetadata);
    }

    private Package createPackage() {
        Package pck = new Package();
        pck.setPckkey("test");
        return pck;
    }

    private PackageStatus createPackageStatus() {
        PackageStatus status = new PackageStatus();
        status.setPstkey("test");
        return status;
    }
}