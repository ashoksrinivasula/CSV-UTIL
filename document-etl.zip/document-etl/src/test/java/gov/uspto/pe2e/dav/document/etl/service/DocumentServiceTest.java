package gov.uspto.pe2e.dav.document.etl.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.pe2e.dav.document.etl.entity.DocCode;
import gov.uspto.pe2e.dav.document.etl.entity.Document;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.DocumentMetadata;
import gov.uspto.pe2e.dav.document.etl.repository.DocumentRepository;


@RunWith(MockitoJUnitRunner.class)
public class DocumentServiceTest {

    private DocumentService documentService;

    @Mock
    private DocumentRepository documentRepository;
    @Mock
    private DocCodeService docCodeService;

    @Before
    public void setup() {
        documentService = new DocumentService(documentRepository, docCodeService);
        when(documentRepository.findById(anyString())).thenReturn(Optional.of(new Document()));
        when(docCodeService.processAndGetDocCode(any())).thenReturn(new DocCode());
        when(documentRepository.merge(any())).thenReturn(new Document());
        doNothing().when(documentRepository).deleteById(any());
    }

    @Test
    public void testSave() {
        documentService.save("test", documentMetadata());
        verify(documentRepository, times(1)).findById(anyString());
        verify(docCodeService, times(1)).processAndGetDocCode(any());
        verify(documentRepository, times(1)).merge(any());
    }

    @Test
    public void testSaveDocumentNotFound() {
        when(documentRepository.findById(anyString())).thenReturn(Optional.empty());
        documentService.save("test", documentMetadata());
        verify(documentRepository, times(1)).findById(anyString());
        verify(docCodeService, times(1)).processAndGetDocCode(any());
        verify(documentRepository, times(1)).merge(any());
    }

    @Test
    public void testDeleteDocument() {
        documentService.delete(Collections.singletonList("test"));
        verify(documentRepository, times(1)).deleteById(any());
    }

    private DocumentMetadata documentMetadata() {
        DocumentMetadata metadata = new DocumentMetadata();
        metadata.setDocumentIdentifier("test");
        return metadata;
    }


}