package gov.uspto.pe2e.dav.document.etl;

import gov.uspto.pe2e.dav.document.etl.service.ETLService;
import gov.uspto.pe2e.dav.document.etl.util.MessageSender;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpServerErrorException;

import javax.jms.JMSException;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class DocumentDlQueueMessageListenerTest {

    private DocumentDlQueueMessageListener documentDlQueueMessageListener;

    @Mock
    private ETLService etlService;

    @Mock
    private  MessageSender messageSender;

    @Before
    public void setUp() {
    	documentDlQueueMessageListener = new DocumentDlQueueMessageListener(etlService,messageSender,15);
    }

    @Test
    public void receive() throws JMSException {
    	Map<String, Object> headers = new HashMap<>();
    	headers.put(MessageSender.RETRY_COUNT, 1);
        doNothing().when(etlService).processNotification(any());
        ActiveMQTextMessage activeMQTextMessage = new ActiveMQTextMessage();
        activeMQTextMessage.setText("test");
        documentDlQueueMessageListener.receive(activeMQTextMessage,headers);
        verify(etlService, times(1)).processNotification(any());
    }

    @Test
    public void receiveWithMaxRetries() throws JMSException {
        Map<String, Object> headers = new HashMap<>();
        headers.put(MessageSender.RETRY_COUNT, 16);
        ActiveMQTextMessage activeMQTextMessage = new ActiveMQTextMessage();
        activeMQTextMessage.setText("test");
        documentDlQueueMessageListener.receive(activeMQTextMessage,headers);
        verify(etlService, times(0)).processNotification(any());
    }

    @Test
    public void receiveWithException() throws JMSException {
        Map<String, Object> headers = new HashMap<>();
        headers.put(MessageSender.RETRY_COUNT, 1);
        doThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR)).when(etlService).processNotification(any());
        doNothing().when(messageSender).sendMessageToDocumentDlQueue(anyString(),anyInt());
        ActiveMQTextMessage activeMQTextMessage = new ActiveMQTextMessage();
        activeMQTextMessage.setText("test");
        documentDlQueueMessageListener.receive(activeMQTextMessage,headers);
        verify(etlService, times(1)).processNotification(any());
    }
}