package gov.uspto.pe2e.dav.document.etl.util;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jms.core.JmsTemplate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class MessageSenderTest {

    private MessageSender messageSender;

    @Mock
    private  JmsTemplate jmsTemplate;

    @Before
    public void setup() {
        messageSender = new MessageSender(jmsTemplate,"dlq.documents.dav.queue");
    }

    @Test
    public void testsendMessageToDocumentDlQueue() {
        doNothing().when(jmsTemplate).convertAndSend(anyString(), anyString(),any());
        messageSender.sendMessageToDocumentDlQueue("test", 1);
        verify(jmsTemplate, times(1)).convertAndSend(anyString(), anyString(),any());
    }

}