package gov.uspto.pe2e.dav.document.etl.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doNothing;

import java.util.Collections;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.pe2e.dav.document.etl.entity.DocCode;
import gov.uspto.pe2e.dav.document.etl.model.message.DeletedDocCodeMetadata;
import gov.uspto.pe2e.dav.document.etl.model.message.DeletedDocCodeResponse;
import gov.uspto.pe2e.dav.document.etl.model.message.DocCodeMetadata;
import gov.uspto.pe2e.dav.document.etl.model.message.DocCodeResponse;
import gov.uspto.pe2e.dav.document.etl.repository.DocCodeRepository;
import gov.uspto.pe2e.dav.document.etl.util.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class DocCodeServiceTest {

    private DocCodeService docCodeService;
    @Mock
    private DocCodeRepository docCodeRepository;
    @Mock
    private RestServiceClient restServiceClient;

    @Before
    public void setUp() {
        docCodeService = new DocCodeService(docCodeRepository, restServiceClient);
    }

    @Test
    public void testProcessAndGetDocCodeFound() {
        when(docCodeRepository.findByDctcode(anyString())).thenReturn(new DocCode());
        DocCode result = docCodeService.processAndGetDocCode("test");
        assertNotNull(result);
    }

    @Test
    public void testProcessAndGetDocCodeNotFound() {
        when(docCodeRepository.findByDctcode(anyString())).thenReturn(null);
        when(restServiceClient.getDocCodes()).thenReturn(docCodeResponse("test"));
        when(docCodeRepository.merge(any())).thenReturn(new DocCode());
        DocCode result = docCodeService.processAndGetDocCode("test");
        assertNotNull(result);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testProcessAndGetDocCodeNotFoundAndNoMatch() {
        when(docCodeRepository.findByDctcode(anyString())).thenReturn(null);
        when(restServiceClient.getDocCodes()).thenReturn(docCodeResponse("diff"));
        docCodeService.processAndGetDocCode("test");
    }
    
    @Test
    public void testprocessDocCodeSync() {
        when(restServiceClient.getDocCodes()).thenReturn(docCodeResponse("test"));
        when(restServiceClient.getDeletedDocCodes()).thenReturn(deletedDocCodeResponse("test_deleted"));
        when(docCodeRepository.merge(any())).thenReturn(new DocCode());
        when(docCodeRepository.existsById(any())).thenReturn(true);
        doNothing().when(docCodeRepository).deleteById(any());        
        docCodeService.processDocCodeSync();
        assertNotNull(docCodeService);
    }
    
    private DocCodeResponse docCodeResponse(String docCode) {
        DocCodeMetadata docCodeMetadata = new DocCodeMetadata();
        docCodeMetadata.setCode(docCode);
        DocCodeResponse docCodeResponse = new DocCodeResponse();
        docCodeResponse.setData(Collections.singletonList(docCodeMetadata));
        return docCodeResponse;
    }
    
    private DeletedDocCodeResponse deletedDocCodeResponse(String docCode) {
    	DeletedDocCodeMetadata deletedDocCodeMetadata = new DeletedDocCodeMetadata();
    	deletedDocCodeMetadata.setDocumentCode(docCode);
        DeletedDocCodeResponse deletedDocCodeResponse = new DeletedDocCodeResponse();
        deletedDocCodeResponse.setData(Collections.singletonList(deletedDocCodeMetadata));
        return deletedDocCodeResponse;
    }
    
   

}