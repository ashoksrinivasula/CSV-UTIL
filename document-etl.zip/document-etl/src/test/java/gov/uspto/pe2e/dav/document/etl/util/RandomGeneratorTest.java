package gov.uspto.pe2e.dav.document.etl.util;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author yparambathkandy
 */
public class RandomGeneratorTest {

    @Test
    public void create() {
        String random = RandomGenerator.create();
        Assert.assertNotNull(random);
        Assert.assertEquals(15, random.length());
    }
}