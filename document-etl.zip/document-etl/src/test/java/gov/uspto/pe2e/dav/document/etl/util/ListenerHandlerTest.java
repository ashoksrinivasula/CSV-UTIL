package gov.uspto.pe2e.dav.document.etl.util;

import gov.uspto.pe2e.dav.document.etl.model.topic.TopicMessage;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jms.config.JmsListenerEndpointRegistry;
import org.springframework.jms.listener.SimpleMessageListenerContainer;

import javax.jms.JMSException;

import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ListenerHandlerTest {

    @InjectMocks
    private ListenerHandler listenerHandler;

    @Mock
    private ActiveMQTextMessage message;

    @Mock
    private SimpleMessageListenerContainer simpleMessageListenerContainer;

    @Mock
    private JmsListenerEndpointRegistry registry;

    @Mock
    private MessageDeserializer messageDeserializer;

    @Test
    public void receiveDocumentStartAction() throws JMSException {
        when(message.getText()).thenReturn("\"{\\\"action\\\":\\\"start\\\",\\\"logMessage\\\":\\\"testing\\\"}\"");
        when(messageDeserializer.convertTopicMessage(anyString())).thenReturn(new TopicMessage().setAction("start"));
        when(registry.getListenerContainer(anyString())).thenReturn(simpleMessageListenerContainer);
        listenerHandler.startOrStopDocumentJmsListener(message);
        verify(simpleMessageListenerContainer, times(1)).start();
    }

    @Test
    public void receiveDocumentStopAction() throws JMSException {
        when(message.getText()).thenReturn("\"{\\\"action\\\":\\\"stop\\\",\\\"logMessage\\\":\\\"testing\\\"}\"");
        when(messageDeserializer.convertTopicMessage(anyString())).thenReturn(new TopicMessage().setAction("stop"));
        when(registry.getListenerContainer(anyString())).thenReturn(simpleMessageListenerContainer);
        listenerHandler.startOrStopDocumentJmsListener(message);
        verify(simpleMessageListenerContainer, times(1)).stop();
    }

    @Test
    public void receiveDocCode() throws Exception {
        when(message.getText()).thenReturn("\"{\\\"action\\\":\\\"start\\\",\\\"logMessage\\\":\\\"testing\\\"}\"");
        when(messageDeserializer.convertTopicMessage(anyString())).thenReturn(new TopicMessage().setAction("start"));
        when(registry.getListenerContainer(anyString())).thenReturn(simpleMessageListenerContainer);
        listenerHandler.startOrStopDocCodeJmsListener(message);
        verify(simpleMessageListenerContainer, times(1)).start();
    }
}