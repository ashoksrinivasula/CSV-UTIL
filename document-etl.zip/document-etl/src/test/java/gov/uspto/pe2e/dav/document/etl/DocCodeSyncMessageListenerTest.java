package gov.uspto.pe2e.dav.document.etl;

import gov.uspto.pe2e.dav.document.etl.service.DocCodeService;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class DocCodeSyncMessageListenerTest {

    @InjectMocks
    private DocCodeSyncMessageListener docCodeSyncMessageListener;

    @Mock
    private DocCodeService docCodeService;


    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void receive() throws Exception {
        doNothing().when(docCodeService).processDocCodeSync();
        ActiveMQTextMessage activeMQTextMessage = new ActiveMQTextMessage();
        activeMQTextMessage.setText("test");
        docCodeSyncMessageListener.receive(activeMQTextMessage);
        verify(docCodeService, times(1)).processDocCodeSync();
    }

    @After
    public void tearDown() throws Exception {
    }

}