package gov.uspto.pe2e.dav.document.etl.util;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

import gov.uspto.pe2e.dav.document.etl.model.message.DeletedDocCodeResponse;
import gov.uspto.pe2e.dav.document.etl.model.message.DocCodeResponse;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.SdwpDocumentResponse;

@Component
@CircuitBreaker(name = "backendRest")
public class RestServiceClient {

    private RestTemplate sdwpRestTemplate;
    private RestTemplate messageRestTemplate;
    private RestTemplate messageDeletedDocCodesRestTemplate;

    private final String sdwpDocumentServiceUrl;
    private final String messageServiceUrl;
    private final String messageServiceDeletedDocCodesUrl;
    private final int restConnectionTimeout;
    private final int restReadTimeout;

    public RestServiceClient(@Value("${restclient.sdwp.document.url}") String sdwpDocumentServiceUrl,
                             @Value("${restclient.message.doccode.url}") String messageServiceUrl,
                             @Value("${restclient.message.deleted.doccode.url}") String messageServiceDeletedDocCodesUrl,
                             @Value("${restclient.connection.timeout}") int restConnectionTimeout,
                             @Value("${restclient.read.timeout}") int restReadTimeout) {
        this.sdwpDocumentServiceUrl = sdwpDocumentServiceUrl;
        this.restConnectionTimeout = restConnectionTimeout;
        this.restReadTimeout = restReadTimeout;
        this.messageServiceUrl = messageServiceUrl;
        this.messageServiceDeletedDocCodesUrl=messageServiceDeletedDocCodesUrl;
        //above values needed before creating resttemplate
        sdwpRestTemplate = createRestTemplate();
        messageRestTemplate = createRestTemplate();
        messageDeletedDocCodesRestTemplate = createRestTemplate();
    }

    public DocCodeResponse getDocCodes() {
        return messageRestTemplate.getForObject(messageServiceUrl, DocCodeResponse.class);
    }

    public SdwpDocumentResponse getSDWPDocuments(String appId, List<String> documentKeys) {
        String fullUrl = sdwpDocumentServiceUrl.concat(appId);
        return sdwpRestTemplate.postForObject(fullUrl, documentKeys.toArray(), SdwpDocumentResponse.class);
    }
    
    public DeletedDocCodeResponse getDeletedDocCodes() {
        return messageDeletedDocCodesRestTemplate.getForObject(messageServiceDeletedDocCodesUrl, DeletedDocCodeResponse.class);
    }

    private RestTemplate createRestTemplate() {
        return new RestTemplateBuilder()
                .setConnectTimeout(this.restConnectionTimeout)
                .setReadTimeout(this.restReadTimeout)
                .build();
    }

}
