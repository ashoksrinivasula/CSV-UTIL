package gov.uspto.pe2e.dav.document.etl.service;

import java.time.LocalDate;
import java.util.List;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.uspto.pe2e.dav.document.etl.entity.DocCode;
import gov.uspto.pe2e.dav.document.etl.entity.Document;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.DocumentMetadata;
import gov.uspto.pe2e.dav.document.etl.repository.DocumentRepository;

/**
 * DocumentService
 *
 * @author Ashok Srinivasula
 */
@Service
@CircuitBreaker(name = "backendDB")
public class DocumentService {

    private final DocumentRepository documentRepository;
    private final DocCodeService docCodeService;

    @Autowired
    public DocumentService(DocumentRepository documentRepository,
                           DocCodeService docCodeService) {
        this.documentRepository = documentRepository;
        this.docCodeService = docCodeService;
    }

    /**
     * @param pckkey
     * @param documentMetadata
     */
    @Transactional
    public void save(String pckkey, DocumentMetadata documentMetadata) {
        Document document = documentRepository.findById(documentMetadata.getDocumentIdentifier())
                .orElseGet(() -> createDocument(documentMetadata.getDocumentIdentifier()));
        DocCode docCode = docCodeService.processAndGetDocCode(documentMetadata.getDocumentCode());
        document.setDocdctkey(docCode.getDctkey());
        document.setDocpckkey(pckkey);
        document.setDocpages(documentMetadata.getTotalPageQuantity());
        document.setDocindpublic(documentMetadata.getPublicStatus());
        document.setDocpckseqnumber(documentMetadata.getPackageSequenceNumber());
        document.setDocuser(documentMetadata.getHandledUserName());
        document.setDocflagdel(documentMetadata.getClosedIndicator());
        document.setDocpckoffset(documentMetadata.getStartPageNumber());
        document.setDocmod(LocalDate.now());
        documentRepository.merge(document);
    }

    /**
     * @param sourceSystemKeys
     */
    @Transactional
    public void delete(List<String> sourceSystemKeys) {
        sourceSystemKeys.forEach(documentRepository::deleteById);
    }

    /**
     * @param documentIdentifier
     * @return
     */
    private Document createDocument(String documentIdentifier) {
        Document newDocument = new Document();
        newDocument.setDockey(documentIdentifier);
        return newDocument;
    }
}