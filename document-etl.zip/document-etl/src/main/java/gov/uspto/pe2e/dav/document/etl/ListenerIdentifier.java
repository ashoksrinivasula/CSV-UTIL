package gov.uspto.pe2e.dav.document.etl;

/**
 * ListenerIdentifier
 *
 * @author yparambathkandy
 */
public class ListenerIdentifier {
    public static final String DOCUMENT_LISTENER_ID = "documentListener";
    public static final String DOCCODE_LISTENER_ID = "docCodeListener";
    public static final String DOCUMENT_DLDQUEUE_LISTENER_ID = "documentDlQueueListener";

    private ListenerIdentifier() {
    }
}
