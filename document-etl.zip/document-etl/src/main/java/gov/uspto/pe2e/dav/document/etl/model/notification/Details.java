package gov.uspto.pe2e.dav.document.etl.model.notification;

import lombok.Data;

import java.util.List;
import java.util.Optional;

/**
 * Details
 *
 * @author Ashok Srinivasula
 */
@Data
public class Details {

    private Action action;


    private List<Document> documents;

    public Action getAction() {
        return Optional.ofNullable(action).orElseThrow(() -> new IllegalArgumentException("Action is mandatory"));
    }

    public List<Document> getDocuments() {
        return Optional.ofNullable(documents).orElseThrow(() -> new IllegalArgumentException("documents are mandatory"));
    }
}
