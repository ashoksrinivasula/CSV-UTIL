package gov.uspto.pe2e.dav.document.etl.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;


/**
 * The persistent class for the IFW.TPH037_PCKSTAT  table.
 *
 * @author Ashok Srinivasula
 */
@Entity
@Getter
@Setter
@Table(name = "IFW.TPH037_PCKSTAT")
public class PackageStatus implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "PSTKEY")
    private String pstkey;

    @Column(name = "PSTXX0")
    private String pstxx0;

    @Column(name = "PSTXX1")
    private String pstxx1;

    @Column(name = "PSTINDSTATUS")
    private Integer pstindstatus;

    @Column(name = "PSTPHXNAME")
    private String pstphxname;

    @Column(name = "PSTLIMITDAY1")
    private Integer pstlimitday1;

    @Column(name = "PSTLIMITDAY2")
    private Integer pstlimitday2;

    @Column(name = "PSTLIMITDAY3")
    private Integer pstlimitday3;

    @Column(name = "PSTLIMITDAY4")
    private Integer pstlimitday4;

    @Column(name = "PSTMBXID")
    private String pstmbxid;

    @Column(name = "PSTDESCSHORT")
    private String pstdescshort;

    @Column(name = "PSTMOD")
    private LocalDate pstmod;
}