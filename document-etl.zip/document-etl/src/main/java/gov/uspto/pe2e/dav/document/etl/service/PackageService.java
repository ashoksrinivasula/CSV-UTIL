package gov.uspto.pe2e.dav.document.etl.service;

import gov.uspto.pe2e.dav.document.etl.entity.JpxiLocalDms;
import gov.uspto.pe2e.dav.document.etl.entity.JpxiLocalDmsIdentity;
import gov.uspto.pe2e.dav.document.etl.entity.Package;
import gov.uspto.pe2e.dav.document.etl.entity.PackageStatus;
import gov.uspto.pe2e.dav.document.etl.model.ErrorCode;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.PackageMetadata;
import gov.uspto.pe2e.dav.document.etl.repository.JpxiLocalDmsRepository;
import gov.uspto.pe2e.dav.document.etl.repository.PackageRepository;
import gov.uspto.pe2e.dav.document.etl.repository.PackageStatusRepository;
import gov.uspto.pe2e.dav.document.etl.util.RandomGenerator;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

/**
 * PackageService
 *
 * @author yparambathkandy
 */
@Slf4j
@Service
@CircuitBreaker(name = "backendDB")
public class PackageService {

    private static final String ERROR_INVALID_PACKAGE_STATUS =
            "{0} Invalid Package Status {1} for Package {2} and  ApplicationId {3}";
    private static final DateTimeFormatter INPUT_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    private static final int AMENDMENT_TO_PERSIST = 32;

    private final PackageRepository packageRepository;
    private final JpxiLocalDmsRepository jpxiLocalDmsRepository;
    private final PackageStatusRepository packageStatusRepository;
    private final DocumentService documentService;

    @Autowired
    public PackageService(PackageRepository packageRepository,
                          PackageStatusRepository packageStatusRepository,
                          DocumentService documentService,
                          JpxiLocalDmsRepository jpxiLocalDmsRepository) {
        this.packageRepository = packageRepository;
        this.packageStatusRepository = packageStatusRepository;
        this.documentService = documentService;
        this.jpxiLocalDmsRepository = jpxiLocalDmsRepository;
    }

    /**
     * @param packages
     * @param doskey
     */
    @Transactional
    public void processPackages(List<PackageMetadata> packages, String doskey) {
        Optional.ofNullable(packages).ifPresent(e -> e.forEach(pck -> createAndSavePackage(doskey, pck)));
    }

    /**
     * @param doskey
     * @param pck
     */
    private void createAndSavePackage(String doskey, PackageMetadata pck) {
        Package packObj = packageRepository.findByPckpxi(pck.getPackageId()).orElseGet(this::createNewPackage);

        PackageStatus packageStatus = packageStatusRepository.findByPstindstatus(pck.getPackageStatusId())
                .orElseThrow(() -> new IllegalArgumentException(
                        MessageFormat.format(ERROR_INVALID_PACKAGE_STATUS,
                                ErrorCode.INVALID_PACKAGE_STATUS,
                                pck.getPackageStatusId(), pck.getPackageId(), pck.getAppId())));
        packObj.setPckpstkey(packageStatus.getPstkey());

        transformPackage(packObj, pck, doskey);
        packObj = packageRepository.merge(packObj);
        final String pckkey = packObj.getPckkey();

        //persist document data if available
        Optional.ofNullable(pck.getDocuments()).ifPresent(e -> e.forEach(doc -> documentService.save(pckkey, doc)));
        //this update is for JpxiLocalDms which sits in a different schema altogether
        createOrUpadteJpxiLocalDms(pck);
    }

    /**
     * @param pck
     */
    private void createOrUpadteJpxiLocalDms(PackageMetadata pck) {
        log.debug("package ::{}::", pck.getPackageId());
        Optional.ofNullable(pck.getImageLoadDt())
                .map(e -> LocalDate.parse(e, INPUT_DATE_FORMAT))
                .ifPresent(e -> processExtDocId(e, pck.getPackageId()));
    }

    /**
     * @param imageLoadDt
     * @param packageId
     */
    private void processExtDocId(LocalDate imageLoadDt, String packageId) {
        JpxiLocalDms jpxiLocalDms = jpxiLocalDmsRepository.findByJpxiLocalDmsIdentityExtdocid(packageId)
                .map(e -> updateScanDateAndReturnExisting(e, imageLoadDt))
                .orElseGet(() -> createJpxiLocalDms(imageLoadDt, packageId));
        jpxiLocalDmsRepository.merge(jpxiLocalDms);
    }

    /**
     * @param imageLoadDt
     * @param packageId
     * @return
     */
    private JpxiLocalDms createJpxiLocalDms(LocalDate imageLoadDt, String packageId) {
        JpxiLocalDms jpxiLocalDms = new JpxiLocalDms();
        JpxiLocalDmsIdentity jpxiLocalDmsIdentity = new JpxiLocalDmsIdentity(packageId, AMENDMENT_TO_PERSIST);
        jpxiLocalDms.setJpxiLocalDmsIdentity(jpxiLocalDmsIdentity);
        jpxiLocalDms.setScanDate(imageLoadDt);
        return jpxiLocalDms;
    }

    /**
     * @return
     */
    private Package createNewPackage() {
        Package newPackage = new Package();
        newPackage.setPckkey(generateUniquePckkey());
        return newPackage;
    }

    /**
     * @return
     */
    private String generateUniquePckkey() {
        String pckkey = null;
        do {
            pckkey = RandomGenerator.create();
        } while (packageRepository.findById(pckkey).isPresent());
        return pckkey;
    }

    /**
     * @param packObj
     * @param pck
     * @param doskey
     */
    private void transformPackage(Package packObj, PackageMetadata pck, String doskey) {
        packObj.setPckdoskey(doskey);
        packObj.setPckpxi(pck.getPackageId());
        packObj.setPckoriappnumber(pck.getOriginalAppId());
        packObj.setPckdateformal(LocalDate.parse(pck.getMailRoomTs(), INPUT_DATE_FORMAT));
        packObj.setPckpages(pck.getTotalPageQt());
        packObj.setPckseqnumber(pck.getPackageSequenceNo());
        packObj.setPcklognumber(pck.getPackageSequenceNo());
        packObj.setPcksource(pck.getSourceSystemNm());
        packObj.setPckmod(LocalDate.now());
    }

    /**
     * @param jpxiLocalDms
     * @param imageLoadDt
     * @return
     */
    private JpxiLocalDms updateScanDateAndReturnExisting(JpxiLocalDms jpxiLocalDms, LocalDate imageLoadDt) {
        jpxiLocalDms.setScanDate(imageLoadDt);
        return jpxiLocalDms;
    }
}
