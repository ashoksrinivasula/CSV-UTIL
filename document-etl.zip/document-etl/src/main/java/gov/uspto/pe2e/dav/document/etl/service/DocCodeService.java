package gov.uspto.pe2e.dav.document.etl.service;

import gov.uspto.pe2e.dav.document.etl.entity.DocCode;
import gov.uspto.pe2e.dav.document.etl.model.Direction;
import gov.uspto.pe2e.dav.document.etl.model.ErrorCode;
import gov.uspto.pe2e.dav.document.etl.model.message.DeletedDocCodeMetadata;
import gov.uspto.pe2e.dav.document.etl.model.message.DocCodeMetadata;
import gov.uspto.pe2e.dav.document.etl.repository.DocCodeRepository;
import gov.uspto.pe2e.dav.document.etl.util.RestServiceClient;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.Objects;
import java.util.Optional;

/**
 * DocCodeService
 *
 * @author yparambathkandy
 */
@Service
@Slf4j
@CircuitBreaker(name = "backendDB")
public class DocCodeService {

    private static final String ERROR_INVALID_DOC_CODE = "{0}: DocCode {1} does not exist in PE2EWI";
    private static final Integer DCMT_FLAG_ONE = 1;
    private static final Integer DCMT_FLAG_TWO = 2;
    private static final String DOCCODE_SYNC_EXCEPTON = "{0}: Exception in the Doc Code Sync Process ";

    private final DocCodeRepository docCodeRepository;
    private final RestServiceClient restServiceClient;

    @Autowired
    public DocCodeService(DocCodeRepository docCodeRepository,
                          RestServiceClient restServiceClient) {
        this.docCodeRepository = docCodeRepository;
        this.restServiceClient = restServiceClient;
    }

    /**
     * If dococde is not found error out
     * If not found, fetch from message service, construct and then save
     *
     * @param inputDocCode
     * @return
     */
    public DocCode processAndGetDocCode(String inputDocCode) {
        DocCode docCode = docCodeRepository.findByDctcode(inputDocCode);
        //avoid this structure. Java 9 has Optional ifPresentOrElse
        if (Objects.nonNull(docCode)) {
            return docCode;
        } else {
            return restServiceClient.getDocCodes().getData().stream()
                    .filter(e -> e.getCode().equalsIgnoreCase(inputDocCode))
                    .findFirst()
                    .map(this::saveAndGetDoccode)
                    .orElseThrow(() -> new IllegalArgumentException(
                            MessageFormat.format(ERROR_INVALID_DOC_CODE,
                                    ErrorCode.INVALID_DOCCODE_FOUND,
                                    inputDocCode)));
        }
    }


    /**
     * Perform Doc Code Sync operations Insert, Update and Delete
     * If not found, fetch from message service, construct and then save
     */
    @Transactional
    public void processDocCodeSync() {
        try {
            restServiceClient.getDocCodes().getData().forEach(this::saveAndGetDoccode);
            restServiceClient.getDeletedDocCodes().getData().forEach(this::deleteDoccode);
        } catch (Exception e) {
            log.error(MessageFormat.format(DOCCODE_SYNC_EXCEPTON, ErrorCode.DOCCODE_SYNC_ERROR), e);
        }
    }


    /**
     * @param docCodeMetadata
     * @return
     */
    private DocCode saveAndGetDoccode(DocCodeMetadata docCodeMetadata) {
        DocCode docCode = new DocCode();
        docCode.setDctkey(docCodeMetadata.getLegacyKey());
        docCode.setDctcode(docCodeMetadata.getCode());
        docCode.setDctprckey(docCodeMetadata.getProcedure());
        docCode.setDctdescen(docCodeMetadata.getDescription());
        docCode.setDctindpublic(docCodeMetadata.getPublicFlag());
        docCode.setDctindsource(
                Optional.ofNullable(docCodeMetadata.getDirection())
                        .map(e -> Direction.valueOf(e).getValue()).orElse(null));
        docCode.setDctflagmsg(docCodeMetadata.isGenerateMessage() ? DCMT_FLAG_ONE : DCMT_FLAG_TWO);
        docCode.setDctmod(LocalDate.now());
        return docCodeRepository.merge(docCode);
    }


    /**
     * @param docCodeMetadata
     */
    private void deleteDoccode(DeletedDocCodeMetadata deletedDocCodeMetadata) {
        if (docCodeRepository.existsById(deletedDocCodeMetadata.getLegacyKey())) {
            docCodeRepository.deleteById(deletedDocCodeMetadata.getLegacyKey());
        }
    }

}
