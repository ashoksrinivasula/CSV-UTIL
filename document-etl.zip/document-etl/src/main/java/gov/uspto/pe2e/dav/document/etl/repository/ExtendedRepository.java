package gov.uspto.pe2e.dav.document.etl.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

import java.io.Serializable;

/**
 * ExtendedRepository
 *
 * @author yparambathkandy
 */
@NoRepositoryBean
public interface ExtendedRepository<T, I extends Serializable> extends JpaRepository<T, I> {
    T merge(T object);
}
