package gov.uspto.pe2e.dav.document.etl.model.notification;

import lombok.Data;

import java.util.Optional;

/**
 * Notification
 *
 * @author Ashok Srinivasula
 */
@Data
public class Notification {
    private String appId;
    private Details details;

    public String getAppId() {
        return Optional.ofNullable(appId).orElseThrow(() -> new IllegalArgumentException("Application Id is mandatory"));
    }

    public Details getDetails() {
        return Optional.ofNullable(details).orElseThrow(() -> new IllegalArgumentException("Details field is mandatory"));
    }
}
