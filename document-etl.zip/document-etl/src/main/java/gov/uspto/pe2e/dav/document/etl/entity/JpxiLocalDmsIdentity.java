package gov.uspto.pe2e.dav.document.etl.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Getter
@Setter
@Embeddable
public class JpxiLocalDmsIdentity implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @NotNull
    private String extdocid;

    @NotNull
    private Integer amendment;

    public JpxiLocalDmsIdentity() {

    }

    public JpxiLocalDmsIdentity(String extdocid, Integer amendment) {
        this.extdocid = extdocid;
        this.amendment = amendment;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        JpxiLocalDmsIdentity that = (JpxiLocalDmsIdentity) o;

        return extdocid.equals(that.extdocid) && amendment.equals(that.amendment);
    }

    @Override
    public int hashCode() {
        int result = extdocid.hashCode();
        result = result + amendment.hashCode();
        return result;
    }
}