package gov.uspto.pe2e.dav.document.etl.model.notification;

import java.util.Optional;

import lombok.Data;

/**
 * Document Details
 *
 * @author Ashok Srinivasula
 */
@Data
public class Document {

    private String documentCode;

    private boolean closedIndicator;

    private String sourceSystemKey;
    
    public String getSourceSystemKey() {
        return Optional.ofNullable(sourceSystemKey).orElseThrow(() -> new IllegalArgumentException("Dmskey is mandatory"));
    }

}
