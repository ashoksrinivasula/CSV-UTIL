package gov.uspto.pe2e.dav.document.etl.config;

import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;

import javax.jms.ConnectionFactory;

/**
 * There are two listener factory configured. one for  queues and other one for the topic
 * If the setPubSubDomain is set in a common connectionFacxtory, then all listeners tend to listen to topics
 * Th requirement is to listen to both topic and queue and so two different factories a must
 */
@Configuration
@EnableJms
public class JmsConfig {

    /**
     * topic connection factory
     *
     * @param connectionFactory
     * @param configurer
     * @return
     */
    @Bean
    public JmsListenerContainerFactory topicListenerFactory(ConnectionFactory connectionFactory,
                                                            DefaultJmsListenerContainerFactoryConfigurer configurer) {
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        configurer.configure(factory, connectionFactory);
        //the placement of this line is important because the setPubSubDomain is set in the above confgire method
        //overriding any declaration before that line
        factory.setPubSubDomain(true);
        return factory;
    }

    /**
     * queue connection factory
     *
     * @param connectionFactory
     * @param configurer
     * @return
     */
    @Bean
    public JmsListenerContainerFactory queueListenerFactory(ConnectionFactory connectionFactory,
                                                            DefaultJmsListenerContainerFactoryConfigurer configurer) {
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        configurer.configure(factory, connectionFactory);
        //the placement of this line is important because the setPubSubDomain is set in the above confgire method
        //overriding any declaration before that line
        factory.setPubSubDomain(false);
        return factory;
    }

}
