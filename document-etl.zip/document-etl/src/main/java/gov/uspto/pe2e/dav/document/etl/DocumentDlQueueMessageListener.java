package gov.uspto.pe2e.dav.document.etl;

import gov.uspto.pe2e.dav.document.etl.service.ETLService;
import gov.uspto.pe2e.dav.document.etl.util.MessageSender;
import lombok.extern.slf4j.Slf4j;
import org.apache.activemq.Message;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.stereotype.Component;

import javax.jms.JMSException;
import java.util.Map;

/**
 * Listens to  dlq.documents.dav.queue notification from upstream system,
 * processes and persists the data to SIRDEV database.
 * This is the entry point to this application
 *
 * @author Ashok Srinivasula
 */

@Component
@Slf4j
public class DocumentDlQueueMessageListener extends AbstractMessageListener {


    public static final int INCREMENT_RETRY_COUNT = 1;
    private final  int retryLimit;


    /**
     * Constructor
     *
     * @param etlService
     */
    @Autowired
    public DocumentDlQueueMessageListener(ETLService etlService,
                                          MessageSender messageSender,
                                          @Value("${sirdev.dlqueue.retry.limit}") int retryLimit) {
        super(etlService,messageSender);
        this.retryLimit=retryLimit;
    }

    /**
     * receive and process message. this method expects a json payload
     *
     * @param message
     * @throws JMSException
     */
    @JmsListener(id = ListenerIdentifier.DOCUMENT_DLDQUEUE_LISTENER_ID, destination = "${jms.queue.document.dlqueue.name}",
            concurrency = "${jms.queue.document.dlqueue.concurrency}", containerFactory = "queueListenerFactory")
    public void receive(final Message message,@Headers Map<String, Object> headers) {
        int retryCount = 0;
        String payload = null;
        try {
            ActiveMQTextMessage amqMessage = (ActiveMQTextMessage) message;
            log.debug("Received message {}", amqMessage.getText());
            retryCount = (Integer) headers.get(MessageSender.RETRY_COUNT);
            payload = amqMessage.getText();
            if (retryLimit > retryCount) {
                etlService.processNotification(payload);
            }
        } catch (Exception e) {
            sendMessageToDlQueue(payload, retryCount + INCREMENT_RETRY_COUNT);
            log.error("Error in Processing payload {}", payload, e);
        }
    }

}
