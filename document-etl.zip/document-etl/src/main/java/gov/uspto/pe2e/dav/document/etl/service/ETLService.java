package gov.uspto.pe2e.dav.document.etl.service;

import gov.uspto.pe2e.dav.document.etl.model.notification.Action;
import gov.uspto.pe2e.dav.document.etl.model.notification.Document;
import gov.uspto.pe2e.dav.document.etl.model.notification.Notification;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.ApplicationMetadata;
import gov.uspto.pe2e.dav.document.etl.model.sdwp.SdwpDocumentResponse;
import gov.uspto.pe2e.dav.document.etl.util.MessageDeserializer;
import gov.uspto.pe2e.dav.document.etl.util.RestServiceClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * ETLService
 *
 * @author yparambathkandy
 */
@Slf4j
@Service
public class ETLService {

    private final MessageDeserializer messageDeserializer;
    private final DossierService dossierService;
    private final PackageService packageService;
    private final DocumentService documentService;
    private final RestServiceClient restServiceClient;

    @Autowired
    public ETLService(PackageService packageService, RestServiceClient restServiceClient,
                      DossierService dossierService, DocumentService documentService,
                      MessageDeserializer messageDeserializer){
        this.packageService = packageService;
        this.restServiceClient = restServiceClient;
        this.dossierService = dossierService;
        this.documentService = documentService;
        this.messageDeserializer = messageDeserializer;
    }

    /**
     * The main processing start here
     *
     * @param payload
     */
    @Transactional
    public void processNotification(String payload) {
        process(messageDeserializer.convert(payload));
    }

    /**
     * processing for new, update and delete CRUD
     *
     * @param notification
     */
    private void process(Notification notification) {
        Action action = notification.getDetails().getAction();
        List<Document> documents = notification.getDetails().getDocuments();
        List<String> sourceSystemKeys = documents.stream()
                .map(Document::getSourceSystemKey)
                .collect(Collectors.toList());
        if (Action.NEW.equals(action) || Action.UPDATE.equals(action)) {
            //step 1: get document metadata
            SdwpDocumentResponse sdwpDocumentResponse = restServiceClient.getSDWPDocuments(
                    notification.getAppId(),sourceSystemKeys );
            if (Objects.nonNull(sdwpDocumentResponse) && Objects.nonNull(sdwpDocumentResponse.getResultBag())
                    && !sdwpDocumentResponse.getResultBag().isEmpty()) {
                ApplicationMetadata applicationMetadata = sdwpDocumentResponse.getResultBag().get(0);
                log.debug(" application ID {}", applicationMetadata.getApplicationId());
                //step 2: create or update application data
                String doskey = dossierService.saveAndGetDosKey(applicationMetadata.getApplicationId());
                log.debug("doskey {}", doskey);
                //step 3: create or update package data. Package will further persist document data
                packageService.processPackages(applicationMetadata.getPackages(), doskey);
            }
        } else if (Action.DELETE.equals(action)) {
            documentService.delete(sourceSystemKeys);
        }
    }
}
