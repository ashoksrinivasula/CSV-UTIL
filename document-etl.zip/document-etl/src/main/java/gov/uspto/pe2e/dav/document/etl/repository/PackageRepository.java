package gov.uspto.pe2e.dav.document.etl.repository;

import gov.uspto.pe2e.dav.document.etl.entity.Package;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * PackageRepository
 *
 * @author yparambathkandy
 */
@Repository
public interface PackageRepository extends ExtendedRepository<Package, String> {
    Optional<Package> findByPckpxi(String pckpxi);
}
