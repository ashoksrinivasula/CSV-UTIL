package gov.uspto.pe2e.dav.document.etl.model.message;

import lombok.Data;

/**
 * @author Ashok Srinivasula
 */
@Data
public class DocCodeMetadata {
    private String id;
    private String legacyKey;
    private String code;
    private String description;
    private boolean generateMessage;
    private String direction;
    private Integer publicFlag;
    private String procedure;
    private String rank;
    private String status;
    private String comments;
    private String source;
}
