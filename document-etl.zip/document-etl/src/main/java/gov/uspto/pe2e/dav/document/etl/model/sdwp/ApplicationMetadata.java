package gov.uspto.pe2e.dav.document.etl.model.sdwp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * ApplicationMetadata
 *
 * @author Ashok Srinivasula
 */
@Data
public class ApplicationMetadata {
    private String applicationId;
    @JsonProperty("packages")
    private List<PackageMetadata> packages;
}
