package gov.uspto.pe2e.dav.document.etl.model.topic;


import lombok.Data;
import lombok.experimental.Accessors;

@Accessors(chain = true)
@Data
public class TopicMessage {

    private String action;

    private String logMessage;

}
