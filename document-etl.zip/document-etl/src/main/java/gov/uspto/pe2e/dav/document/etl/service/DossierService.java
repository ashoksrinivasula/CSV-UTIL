package gov.uspto.pe2e.dav.document.etl.service;

import gov.uspto.pe2e.dav.document.etl.entity.Dossier;
import gov.uspto.pe2e.dav.document.etl.repository.DossierRepository;
import gov.uspto.pe2e.dav.document.etl.util.RandomGenerator;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

/**
 * DossierService
 *
 * @author yparambathkandy
 */
@Service
@CircuitBreaker(name = "backendDB")
public class DossierService {

    private final DossierRepository dossierRepository;

    @Autowired
    public DossierService(DossierRepository dossierRepository) {
        this.dossierRepository = dossierRepository;
    }

    /**
     * @param applicationId
     * @return
     */
    @Transactional
    public String saveAndGetDosKey(String applicationId) {
        return dossierRepository.findByDosorinumber(applicationId)
                .map(Dossier::getDoskey)
                .orElseGet(() -> saveAndGetDossier(applicationId).getDoskey());
    }

    /**
     * @param applicationId
     * @return
     */
    private Dossier saveAndGetDossier(String applicationId) {
        Dossier dossier = new Dossier();
        dossier.setDoskey(generateUniqueDosKey());
        dossier.setDosmod(LocalDate.now());
        dossier.setDosorinumber(applicationId);
        return dossierRepository.merge(dossier);
    }

    /**
     * @return
     */
    private String generateUniqueDosKey() {
        String doskey = null;
        do {
            doskey = RandomGenerator.create();
        } while (dossierRepository.findById(doskey).isPresent());
        return doskey;
    }
}
