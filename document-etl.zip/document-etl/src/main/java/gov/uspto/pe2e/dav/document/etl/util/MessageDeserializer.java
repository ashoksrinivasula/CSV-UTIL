package gov.uspto.pe2e.dav.document.etl.util;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import gov.uspto.pe2e.dav.document.etl.model.ErrorCode;
import gov.uspto.pe2e.dav.document.etl.model.notification.Notification;
import gov.uspto.pe2e.dav.document.etl.model.topic.TopicMessage;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.text.MessageFormat;

/**
 * Unmarshaller
 *
 * @author yparambathkandy
 */
@Component
public class MessageDeserializer {

    private static final String PAYLOAD_PARSE_ERROR_MESSAGE_TEMPLATE = "{0}: Invalid payload - {1}";
    private ObjectMapper objectMapper;

    public Notification convert(String payload) {
        try {
            return objectMapper.readValue(payload, Notification.class);
        } catch (Exception e) {
            //Log Splunk error key value formatted for payload formatting issue
            throw new IllegalArgumentException(
                    MessageFormat.format(PAYLOAD_PARSE_ERROR_MESSAGE_TEMPLATE,
                            ErrorCode.DOCUMENT_ETL_PAYLOAD_PARSE_ERROR, payload), e);
        }
    }

    public TopicMessage convertTopicMessage(String payload) {
        try {
            return objectMapper.readValue(payload, TopicMessage.class);
        } catch (Exception e) {
            //Log Splunk error key value formatted for payload formatting issue
            throw new IllegalArgumentException(
                    MessageFormat.format(PAYLOAD_PARSE_ERROR_MESSAGE_TEMPLATE,
                            ErrorCode.DOCUMENT_ETL_PAYLOAD_PARSE_ERROR, payload), e);
        }
    }

    @PostConstruct
    public void init() {
        objectMapper = new ObjectMapper();
        //this is enabled to allow action field mapping to enum Action
        objectMapper.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
        //this is to ignore elements that we dont need from the message like intakeSourceId
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }
}
