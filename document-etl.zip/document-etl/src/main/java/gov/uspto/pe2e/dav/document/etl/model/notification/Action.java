package gov.uspto.pe2e.dav.document.etl.model.notification;

/**
 * Action
 *
 * @author yparambathkandy
 */
public enum Action {
    NEW,
    UPDATE,
    DELETE
}
