package gov.uspto.pe2e.dav.document.etl.model;

/**
 * Direction
 *
 * @author yparambathkandy
 */
public enum Direction {
    INCOMING(0),
    OUTGOING(1),
    INTERNAL(2);

    private int value;

    Direction(int direction) {
        this.value = direction;
    }

    public int getValue() {
        return value;
    }}
