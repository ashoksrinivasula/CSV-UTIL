package gov.uspto.pe2e.dav.document.etl.repository;

import gov.uspto.pe2e.dav.document.etl.entity.Document;
import org.springframework.stereotype.Repository;

/**
 * DocumentRepository
 *
 * @author yparambathkandy
 */
@Repository
public interface DocumentRepository extends ExtendedRepository<Document, String> {

}
