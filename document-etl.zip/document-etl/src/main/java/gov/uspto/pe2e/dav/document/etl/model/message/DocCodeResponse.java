package gov.uspto.pe2e.dav.document.etl.model.message;

import lombok.Data;

import java.util.List;

/**
 * This class gets list of Document codes as response from PE2EWI.
 *
 * @author Ashok Srinivasula
 */
@Data
public class DocCodeResponse {
    private boolean success;
    private List<DocCodeMetadata> data;
}
