package gov.uspto.pe2e.dav.document.etl.util;

import gov.uspto.pe2e.dav.document.etl.ListenerIdentifier;
import gov.uspto.pe2e.dav.document.etl.model.topic.TopicMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.config.JmsListenerEndpointRegistry;
import org.springframework.jms.listener.MessageListenerContainer;
import org.springframework.stereotype.Component;

import javax.jms.JMSException;
import javax.jms.Message;

/**
 * Class to listen to the topic which controls the
 * start and stop of the listeners
 * to the queues
 */
@Slf4j
@Component
public class ListenerHandler {

    private final MessageDeserializer messageDeserializer;
    private final JmsListenerEndpointRegistry registry;

    @Autowired
    public ListenerHandler(JmsListenerEndpointRegistry registry, MessageDeserializer messageDeserializer) {
        this.registry = registry;
        this.messageDeserializer = messageDeserializer;
    }

    /**
     * @param message
     * @throws JMSException
     */
    @JmsListener(destination = "${documents.destination.topic}", containerFactory = "topicListenerFactory")
    public void startOrStopDocumentJmsListener(final Message message) throws JMSException {
        startOrStopListener(message, ListenerIdentifier.DOCUMENT_LISTENER_ID);
    }

    /**
     * @param message
     * @throws JMSException
     */
    @JmsListener(destination = "${docCode.destination.topic}", containerFactory = "topicListenerFactory")
    public void startOrStopDocCodeJmsListener(final Message message) throws JMSException {
        startOrStopListener(message, ListenerIdentifier.DOCCODE_LISTENER_ID);
    }


    private void startOrStopListener(final Message message, String listenerId) throws JMSException {
        ActiveMQTextMessage amqMessage = (ActiveMQTextMessage) message;
        log.info("Received message {}", amqMessage.getText());
        TopicMessage topicMessage = messageDeserializer.convertTopicMessage(amqMessage.getText());
        startOrStopListener(listenerId, "start".equalsIgnoreCase(topicMessage.getAction().trim()));
    }

    public void startAllListeners() {
        startOrStopListener(ListenerIdentifier.DOCCODE_LISTENER_ID, true);
        startOrStopListener(ListenerIdentifier.DOCUMENT_LISTENER_ID, true);
        startOrStopListener(ListenerIdentifier.DOCUMENT_DLDQUEUE_LISTENER_ID, true);
    }

    public void stopAllListeners() {
        startOrStopListener(ListenerIdentifier.DOCCODE_LISTENER_ID, false);
        startOrStopListener(ListenerIdentifier.DOCUMENT_LISTENER_ID, false);
        startOrStopListener(ListenerIdentifier.DOCUMENT_DLDQUEUE_LISTENER_ID, false);
    }

    private void startOrStopListener(String listenerId, boolean startFlag) {
        MessageListenerContainer listenerContainer = registry.getListenerContainer(listenerId);
        if (listenerContainer != null && startFlag) {
            listenerContainer.start();
        } else if (listenerContainer != null) {
            listenerContainer.stop();
        }
    }

}
