package gov.uspto.pe2e.dav.document.etl.repository;

import gov.uspto.pe2e.dav.document.etl.entity.Dossier;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
/**
 * DossierRepository
 *
 * @author yparambathkandy
 */
@Repository
public interface DossierRepository extends ExtendedRepository<Dossier, String> {
    Optional<Dossier> findByDosorinumber(@Param("dosorinumber") String dosorinumber);
}
