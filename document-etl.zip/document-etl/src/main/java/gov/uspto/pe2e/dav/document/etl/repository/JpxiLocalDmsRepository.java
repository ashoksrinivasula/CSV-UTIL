package gov.uspto.pe2e.dav.document.etl.repository;

import gov.uspto.pe2e.dav.document.etl.entity.JpxiLocalDms;
import gov.uspto.pe2e.dav.document.etl.entity.JpxiLocalDmsIdentity;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * JpxiLocalDmsRepository
 *
 * @author yparambathkandy
 */
@Repository
public interface JpxiLocalDmsRepository extends ExtendedRepository<JpxiLocalDms, JpxiLocalDmsIdentity> {
    Optional<JpxiLocalDms> findByJpxiLocalDmsIdentityExtdocid(String extdocid);
}
