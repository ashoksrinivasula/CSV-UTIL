package gov.uspto.pe2e.dav.document.etl;

import gov.uspto.pe2e.dav.document.etl.service.ETLService;
import gov.uspto.pe2e.dav.document.etl.util.MessageSender;

import java.util.Objects;

public abstract class AbstractMessageListener {

    protected final  ETLService etlService;
    protected final  MessageSender messageSender;

    AbstractMessageListener (ETLService etlService,MessageSender messageSender){
        this.etlService = etlService;
        this.messageSender = messageSender;
    }

    protected void sendMessageToDlQueue(String payload, int retryCount ) {
        if(Objects.nonNull(payload)) {
            messageSender.sendMessageToDocumentDlQueue(payload, retryCount);
        }
    }
}