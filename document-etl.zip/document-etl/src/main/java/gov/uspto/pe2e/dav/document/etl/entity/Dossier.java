package gov.uspto.pe2e.dav.document.etl.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;


/**
 * The persistent class for the IFW.TPH019_DOSSIER  table.
 *
 * @author Ashok Srinivasula
 */
@Entity
@Getter
@Setter
@Table(name = "IFW.TPH019_DOSSIER")
public class Dossier implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "doskey")
    private String doskey;

    @Column(name = "dosxx0")
    private String dctxx0 = " ";

    @Column(name = "dosxx1")
    private String dosxx1 = " ";

    @Column(name = "doscoverflags")
    private String doscoverflags = " ";

    @Column(name = "dosoritype")
    private String dosoritype = " ";

    @Column(name = "dosorinumber")
    private String dosorinumber;

    @Column(name = "dosmod")
    private LocalDate dosmod;

}