package gov.uspto.pe2e.dav.document.etl;

import gov.uspto.pe2e.dav.document.etl.service.ETLService;
import gov.uspto.pe2e.dav.document.etl.util.MessageSender;
import lombok.extern.slf4j.Slf4j;
import org.apache.activemq.Message;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import javax.jms.JMSException;

/**
 * Listens to document queue notification from upstream system,
 * processes and persists the data to SIRDEV database.
 * This is the entry point to this application
 *
 * @author Ashok Srinivasula
 */

@Component
@Slf4j
public class DocumentMessageListener extends AbstractMessageListener{

    public static final int STARTING_RETRY_COUNT = 0;

    /**
     * Constructor
     *
     * @param etlService
     */
    @Autowired
    public DocumentMessageListener(ETLService etlService,
                                   MessageSender messageSender) {
        super(etlService,messageSender);
    }

    /**
     * receive and process message. this method expects a json payload
     *
     * @param message
     * @throws JMSException
     */
    @JmsListener(id = ListenerIdentifier.DOCUMENT_LISTENER_ID, destination = "${jms.queue.document.name}",
            concurrency = "${jms.queue.document.concurrency}", containerFactory = "queueListenerFactory")
    public void receive(final Message message){
        String payload = null;
        try {
            ActiveMQTextMessage amqMessage = (ActiveMQTextMessage) message;
            payload = amqMessage.getText();
            log.debug("Received message {}", payload);
            etlService.processNotification(payload);
        }catch (Exception e) {
            sendMessageToDlQueue(payload, STARTING_RETRY_COUNT);
            log.error("Error in Processing payload {}", payload, e);
        }
    }


}