package gov.uspto.pe2e.dav.document.etl.config.db;

import org.hibernate.jpa.HibernatePersistenceProvider;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaDialect;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Properties;

/**
 * @author skannegundla
 */
public interface DBConfig {

    /**
     * Generic JNDI based datasource creation
     *
     * @param jndiName
     * @return
     */
    default DataSource dataSource(String jndiName) {
        return new JndiDataSourceLookup().getDataSource(jndiName);
    }

    /**
     * Generic local development based datasource creation
     *
     * @param jdbcUrl
     * @param userName
     * @param password
     * @return
     */
    default DataSource localDataSource(String jdbcUrl, String userName, String password, String driverName) {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(driverName);
        dataSource.setUrl(jdbcUrl);
        dataSource.setUsername(userName);
        dataSource.setPassword(password);
        return dataSource;
    }

    default DataSource jndiDataSource(String jndiName) {
        return dataSource(jndiName);
    }

    /**
     * Generic JPA configuration
     *
     * @param dataSource
     * @param packagesToScan
     * @return
     */
    default LocalContainerEntityManagerFactoryBean entityManager(DataSource dataSource,
                                                                 String packagesToScan,
                                                                 String persistenceUnitName) {
        LocalContainerEntityManagerFactoryBean emf = new LocalContainerEntityManagerFactoryBean();
        emf.setDataSource(dataSource);
        emf.setJpaVendorAdapter(vendorAdaptor());
        emf.setPersistenceProviderClass(HibernatePersistenceProvider.class);
        emf.setPackagesToScan(packagesToScan);
        emf.setJpaProperties(jpaHibernateProperties());
        emf.setPersistenceUnitName(persistenceUnitName);
        return emf;
    }

    default Properties jpaHibernateProperties() {
        Properties properties = new Properties();
        properties.put("hibernate.show_sql", "true");
        properties.put("hibernate.current_session_context_class", "thread");
        properties.put("hibernate.order_inserts", "true");
        properties.put("hibernate.order_updates", "true");
        properties.put("hibernate.versioned_data", "true");
        properties.put("hibernate.jdbc.batch_size", "2000");
        return properties;
    }

    default HibernateJpaVendorAdapter vendorAdaptor() {
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setShowSql(false);
        vendorAdapter.setDatabasePlatform("org.hibernate.dialect.Oracle10gDialect");
        return vendorAdapter;
    }

    /**
     * Generic transaction manager
     *
     * @param entityManagerFactory
     * @return
     */
    default PlatformTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory);
        transactionManager.setJpaDialect(new HibernateJpaDialect());
        return transactionManager;
    }
}
