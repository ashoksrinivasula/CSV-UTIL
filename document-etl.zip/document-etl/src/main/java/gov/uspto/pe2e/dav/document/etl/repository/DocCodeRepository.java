package gov.uspto.pe2e.dav.document.etl.repository;

import gov.uspto.pe2e.dav.document.etl.entity.DocCode;
import org.springframework.stereotype.Repository;

/**
 * DocCodeRepository
 *
 * @author yparambathkandy
 */
@Repository
public interface DocCodeRepository extends ExtendedRepository<DocCode, String> {
    DocCode findByDctcode(String dctcode);
}
