package gov.uspto.pe2e.dav.document.etl.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;


/**
 * The persistent class for the IFW.TPH035_PACKAGE  table.
 *
 * @author Ashok Srinivasula
 */
@Entity
@Getter
@Setter
@Table(name = "IFW.TPH035_PACKAGE")
public class Package implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "pckkey")
    private String pckkey;

    @Column(name = "pckxx0")
    private String pckxx0 = " ";

    @Column(name = "pckxx1")
    private String pckxx1 = " ";

    @Column(name = "pckbchkey")
    private String pckbchkey = " ";

    @Column(name = "pckcdrkey")
    private String pckcdrkey = " ";

    @Column(name = "pcklcpkey")
    private String pcklcpkey = " ";

    @Column(name = "pckmsgkey")
    private String pckmsgkey = " ";

    @Column(name = "pckpstkey")
    private String pckpstkey;

    @Column(name = "pcksftkey")
    private String pcksftkey = " ";

    @Column(name = "pckdoskey")
    private String pckdoskey;

    @Column(name = "pckpxi")
    private String pckpxi;

    @Column(name = "pckoriappnumber")
    private String pckoriappnumber;

    @Column(name = "pckdateformal")
    private LocalDate pckdateformal;

    @Column(name = "pckannotation")
    private String pckannotation = " ";

    @Column(name = "pckmsgtext")
    private String pckmsgtext = " ";

    @Column(name = "pckmsgdoccode")
    private String pckmsgdoccode = " ";

    @Column(name = "pckpages")
    private Integer pckpages;

    @Column(name = "pckurgency")
    private Integer pckurgency = 0;

    @Column(name = "pckflagtransl")
    private Integer pckflagtransl = 0;

    @Column(name = "pckflagmsg")
    private Integer pckflagmsg = 0;

    @Column(name = "pckflagdel")
    private Integer pckflagdel = 0;

    @Column(name = "pckflagerror")
    private Integer pckflagerror = 0;

    @Column(name = "pckseqnumber")
    private Integer pckseqnumber;

    @Column(name = "pckbchseqnumber")
    private Integer pckbchseqnumber = 0;

    @Column(name = "pckusertarget")
    private String pckusertarget = " ";

    @Column(name = "pcksource")
    private String pcksource;

    @Column(name = "pcklognumber")
    private Integer pcklognumber;

    @Column(name = "pckmbxtarget")
    private String pckmbxtarget = " ";

    @Column(name = "pckindsublogic")
    private Integer pckindsublogic = 0;

    @Column(name = "pckmod")
    private LocalDate pckmod;
}