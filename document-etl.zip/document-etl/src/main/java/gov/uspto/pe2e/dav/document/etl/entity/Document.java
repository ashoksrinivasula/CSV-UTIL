package gov.uspto.pe2e.dav.document.etl.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;


/**
 * The persistent class for the IFW.TPH014_DOCUMENT  table.
 *
 * @author Ashok Srinivasula
 */
@Entity
@Getter
@Setter
@Table(name = "IFW.TPH014_DOCUMENT")
public class Document implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "dockey")
    private String dockey;

    @Column(name = "docxx0")
    private String docxx0 = " ";

    @Column(name = "docxx1")
    private String docxx1 = " ";

    @Column(name = "docdctkey")
    private String docdctkey;

    @Column(name = "docparkey")
    private String docparkey = " ";

    @Column(name = "docpckkey")
    private String docpckkey;

    @Column(name = "docpages")
    private Integer docpages;

    @Column(name = "docindpublic")
    private Integer docindpublic;

    @Column(name = "docpckseqnumber")
    private Integer docpckseqnumber;

    @Column(name = "docuser")
    private String docuser;

    @Column(name = "docindstatus")
    private Integer docindstatus = 0;

    @Column(name = "docflagdel")
    private Integer docflagdel;

    @Column(name = "docpckoffset")
    private Integer docpckoffset;

    @Column(name = "docflagindex")
    private Integer docflagindex = 0;

    @Column(name = "docindpuba")
    private Integer docindpuba = 0;

    @Column(name = "docindpubb")
    private Integer docindpubb = 0;

    @Column(name = "docdatepuba")
    private LocalDate docdatepuba = null;

    @Column(name = "docdatepubb")
    private LocalDate docdatepubb = null;

    @Column(name = "docflagmodel")
    private Integer docflagmodel = 0;

    @Column(name = "docmodelseqnum")
    private Integer docmodelseqnum = 0;

    @Column(name = "docmodelroom")
    private String docmodelroom = " ";

    @Column(name = "docmodelbox")
    private String docmodelbox = " ";

    @Column(name = "doccountryabbr")
    private String doccountryabbr = " ";

    @Column(name = "docflagextra1")
    private Integer docflagextra1 = 0;

    @Column(name = "docflagextra2")
    private Integer docflagextra2 = 0;

    @Column(name = "docflagextra3")
    private Integer docflagextra3 = 0;

    @Column(name = "docflagextra4")
    private Integer docflagextra4 = 0;

    @Column(name = "docflagextra5")
    private Integer docflagextra5 = 0;

    @Column(name = "docflagextra6")
    private Integer docflagextra6 = 0;

    @Column(name = "docflagextra7")
    private Integer docflagextra7 = 0;

    @Column(name = "docflagextra8")
    private Integer docflagextra8 = 0;

    @Column(name = "docfrmidcode")
    private String docfrmidcode = " ";

    @Column(name = "docfrmlang")
    private String docfrmlang = " ";

    @Column(name = "docmod")
    private LocalDate docmod;

}