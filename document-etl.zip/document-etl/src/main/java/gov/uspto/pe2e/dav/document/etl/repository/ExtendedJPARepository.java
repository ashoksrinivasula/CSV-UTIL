package gov.uspto.pe2e.dav.document.etl.repository;

import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;

import javax.persistence.EntityManager;
import java.io.Serializable;

/**
 * ExtendedJPARepository
 *
 * @author yparambathkandy
 */
public class ExtendedJPARepository<T, I extends Serializable>
        extends SimpleJpaRepository<T, I> implements ExtendedRepository<T, I> {

    private EntityManager entityManager;

    public ExtendedJPARepository(JpaEntityInformation<T, ?> entityInformation, EntityManager entityManager) {
        super(entityInformation, entityManager);
        this.entityManager = entityManager;
    }

    @Override
    public T merge(T object) {
        return this.entityManager.merge(object);
    }

}