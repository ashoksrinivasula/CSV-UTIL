package gov.uspto.pe2e.dav.document.etl.model.sdwp;

import lombok.Data;

/**
 * DocumentMetadata
 *
 * @author Ashok Srinivasula
 */
@Data
public class DocumentMetadata {
    private String documentIdentifier;
    private Integer publicStatus;
    private Integer packageSequenceNumber;
    private Integer startPageNumber;
    private Integer totalPageQuantity;
    private Integer closedIndicator;
    private String documentCode;
    private String procedureName;
    private Integer documentCategory;
    private String handledUserName;
    private String documentDescription;

}
