package gov.uspto.pe2e.dav.document.etl.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;


/**
 * The persistent class for the IFW.TPH013_DOCCTL  table.
 *
 * @author Ashok Srinivasula
 */
@Entity
@Getter
@Setter
@Table(name = "IFW.TPH013_DOCCTL")
public class DocCode implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "dctkey")
    private String dctkey;

    @Column(name = "dctxx0")
    private String dctxx0 = " ";

    @Column(name = "dctxx1")
    private String dctxx1 = " ";

    @Column(name = "dctalgkey")
    private String dctalgkey = " ";

    @Column(name = "dctprckey")
    private String dctprckey;

    @Column(name = "dctorgkey")
    private String dctorgkey = " ";

    @Column(name = "dctcode")
    private String dctcode;

    @Column(name = "dctdescen")
    private String dctdescen;

    @Column(name = "dctdescfr")
    private String dctdescfr = " ";

    @Column(name = "dctdescde")
    private String dctdescde = " ";

    @Column(name = "dctindpub")
    private Integer dctindpub = 0;

    @Column(name = "dctflagmsg")
    private Integer dctflagmsg;

    @Column(name = "dctindpublic")
    private Integer dctindpublic;

    @Column(name = "dctindsource")
    private Integer dctindsource;

    @Column(name = "dctflagcover")
    private Integer dctflagcover = 0;

    @Column(name = "dctflagannex")
    private Integer dctflagannex = 0;

    @Column(name = "dcturgency")
    private Integer dcturgency = 0;

    @Column(name = "dctflagfinalidx")
    private Integer dctflagfinalidx = 0;

    @Column(name = "dctindregister")
    private Integer dctindregister = 0;

    @Column(name = "dctflagretrieve")
    private Integer dctflagretrieve = 0;

    @Column(name = "dctpmuse")
    private Integer dctpmuse = 0;

    @Column(name = "dctflagsuppress")
    private Integer dctflagsuppress = 0;

    @Column(name = "dctindsublogic")
    private Integer dctindsublogic = 0;

    @Column(name = "dctmod")
    private LocalDate dctmod;


}