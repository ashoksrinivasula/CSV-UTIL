package gov.uspto.pe2e.dav.document.etl.util;

import org.apache.commons.lang3.RandomStringUtils;

/**
 * RandomGenerator
 *
 * @author yparambathkandy
 */
public class RandomGenerator {

    private static final Integer KEY_LENGTH = 15;

    private RandomGenerator() {
    }

    public static String create() {
        return RandomStringUtils.randomAlphabetic(KEY_LENGTH).toUpperCase();
    }

}
