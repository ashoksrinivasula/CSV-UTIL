package gov.uspto.pe2e.dav.document.etl;

import gov.uspto.pe2e.dav.document.etl.service.DocCodeService;
import lombok.extern.slf4j.Slf4j;
import org.apache.activemq.Message;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import javax.jms.JMSException;

/**
 * Listens to document code queue notification from AMQ document code sync cron,
 * processes document codes to SIRDEV database.
 * This is the entry point to Doc Code Sync Process
 *
 * @author Ashok Srinivasula
 */

@Component
@Slf4j
public class DocCodeSyncMessageListener {

    private final DocCodeService docCodeService;


    /**
     * Constructor
     *
     * @param DocCodeService
     */
    @Autowired
    public DocCodeSyncMessageListener(DocCodeService docCodeService) {
        this.docCodeService = docCodeService;
    }

    /**
     * receive document code sync cron  message and process Document
     *
     * @param message
     * @throws JMSException
     */
    @JmsListener(id = ListenerIdentifier.DOCCODE_LISTENER_ID, destination = "${jms.queue.doccode.name}",
            concurrency = "${jms.queue.doccode.concurrency}", containerFactory = "queueListenerFactory")
    public void receive(final Message message) throws JMSException {
        ActiveMQTextMessage amqMessage = (ActiveMQTextMessage) message;
        log.info("Received message {}", amqMessage.getText());
        docCodeService.processDocCodeSync();
        log.info("DocCode Sync Completed");
    }
}