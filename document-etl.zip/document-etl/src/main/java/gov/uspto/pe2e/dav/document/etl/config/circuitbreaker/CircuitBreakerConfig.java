package gov.uspto.pe2e.dav.document.etl.config.circuitbreaker;

import gov.uspto.pe2e.dav.document.etl.util.ListenerHandler;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.circuitbreaker.event.CircuitBreakerOnStateTransitionEvent;
import io.github.resilience4j.core.EventConsumer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import static io.github.resilience4j.circuitbreaker.CircuitBreaker.State.HALF_OPEN;
import static io.github.resilience4j.circuitbreaker.CircuitBreaker.State.OPEN;

@Configuration
public class CircuitBreakerConfig {

    /**
     * CircuitBreakerConfig class Constructor
     *
     * @param circuitBreakerRegistry
     * @param listenerHandler
     */

    @Autowired
    public CircuitBreakerConfig(CircuitBreakerRegistry circuitBreakerRegistry, ListenerHandler listenerHandler) {
        circuitBreakerRegistry.circuitBreaker("backendRest").getEventPublisher()
                .onStateTransition(handleStateTransition(listenerHandler));
        circuitBreakerRegistry.circuitBreaker("backendDB").getEventPublisher()
                .onStateTransition(handleStateTransition(listenerHandler));
    }


    private EventConsumer<CircuitBreakerOnStateTransitionEvent> handleStateTransition(ListenerHandler listenerHandler) {
        return event -> {
            if (HALF_OPEN == event.getStateTransition().getToState()) {
                listenerHandler.startAllListeners();
            } else if (OPEN == event.getStateTransition().getToState()) {
                listenerHandler.stopAllListeners();
            }
        };
    }

}
