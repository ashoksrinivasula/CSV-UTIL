package gov.uspto.pe2e.dav.document.etl.model.sdwp;

import lombok.Data;

import java.util.List;

/**
 * This class gets list of document keys as response from pe2e.
 *
 * @author Ashok Srinivasula
 */
@Data
public class SdwpDocumentResponse {
    private List<ApplicationMetadata> resultBag;
}
