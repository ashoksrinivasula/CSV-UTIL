package gov.uspto.pe2e.dav.document.etl.repository;

import gov.uspto.pe2e.dav.document.etl.entity.PackageStatus;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * PackageStatusRepository
 *
 * @author yparambathkandy
 */
@Repository
public interface PackageStatusRepository extends ExtendedRepository<PackageStatus, String> {

    Optional<PackageStatus> findByPstindstatus(Integer pstindstatus);
}
