package gov.uspto.pe2e.dav.document.etl.model;

/**
 * ErrorCode
 *
 * @author yparambathkandy
 */
public enum ErrorCode {
    DOCUMENT_ETL_PAYLOAD_PARSE_ERROR,
    INVALID_DOCCODE_FOUND,
    INVALID_PACKAGE_STATUS,
    DOCCODE_SYNC_ERROR
}
