package gov.uspto.pe2e.dav.document.etl.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;


/**
 * The persistent class for the IFW.JPXI_LOCAL_DMS table.
 *
 * @author Ashok Srinivasula
 */
@Entity
@Getter
@Setter
@Table(name = "IFW.JPXI_LOCAL_DMS")
public class JpxiLocalDms implements Serializable {
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private JpxiLocalDmsIdentity jpxiLocalDmsIdentity;

    @Column(name = "OBJECTID")
    private Integer objectId = 0;

    @Column(name = "SCANDATE")
    private LocalDate scanDate;

    @Column(name = "XMLDEF")
    private String xmlDef = " ";

}