package gov.uspto.pe2e.dav.document.etl.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:document-etl-${spring.profiles.active}.properties")
public class AppConfiguration {

}
