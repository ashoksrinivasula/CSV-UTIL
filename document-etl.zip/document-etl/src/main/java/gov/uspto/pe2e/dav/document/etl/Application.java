package gov.uspto.pe2e.dav.document.etl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import java.util.Collections;

/**
 * Spring boot initializer. Used as a standalone app for local development and
 * web artifact for a web container
 *
 * @author Ashok Srinivasula
 */
@SpringBootApplication
public class Application extends SpringBootServletInitializer {

    private static final String SPRING_PROFILE_SERVER = "server";
    private static final String SPRING_PROFILE_LOCAL = "local";
    private static final String PROFILE_SETTING = "spring.profiles.active";

    /**
     * Default spring context loader
     *
     * @param application
     * @return Spring context builder
     */
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.properties(Collections.singletonMap(PROFILE_SETTING, SPRING_PROFILE_SERVER))
                .sources(Application.class);
    }

    /**
     * This is used for local development to start and test using an embedded
     * tomcat container
     *
     * @param args program args none to be provided
     */
    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(Application.class);
        application.setDefaultProperties(Collections.singletonMap(PROFILE_SETTING, SPRING_PROFILE_LOCAL));
        application.run(args);
    }
}
