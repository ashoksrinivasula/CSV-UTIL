package gov.uspto.pe2e.dav.document.etl.model.message;

import lombok.Data;

/**
 * This class have Deleted Document codes meta data.
 *  
 * @author Ashok Srinivasula
 */
@Data
public class DeletedDocCodeMetadata {
    private String legacyKey;
    private String documentCode;
    private String lastUpdated;
   
}
