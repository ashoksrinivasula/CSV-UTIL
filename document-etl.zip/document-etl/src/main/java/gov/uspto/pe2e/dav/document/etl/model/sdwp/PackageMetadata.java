package gov.uspto.pe2e.dav.document.etl.model.sdwp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * PackageMetadata
 * @author Ashok Srinivasula
 */
@Data
public class PackageMetadata {
    private String packageId;
    private String mailRoomTs;
    private Integer packageSequenceNo;
    private String sourceSystemNm;
    private String originalAppId;
    private Integer totalPageQt;
    private String imageLoadDt;
    private Integer packageStatusId;
    private String appId;
    private Integer createMessageIn;
    private Integer cmsMigrateIn;
    private String messageTx;
    private String messageCd;
    @JsonProperty("documents")
    private List<DocumentMetadata> documents;

}
