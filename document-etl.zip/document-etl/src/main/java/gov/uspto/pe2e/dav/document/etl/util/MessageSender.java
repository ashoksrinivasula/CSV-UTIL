package gov.uspto.pe2e.dav.document.etl.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class MessageSender {

    public static final String RETRY_COUNT = "retryCount";
    private final JmsTemplate jmsTemplate;
    private final String documentDlQueueName;

    /**
     * MessageSender class Constructor
     *
     * @param jmsTemplate
     * @param documentDlQueueName
     */
    @Autowired
    public MessageSender(JmsTemplate jmsTemplate,
                         @Value("${jms.queue.document.dlqueue.name}") String documentDlQueueName) {
        this.jmsTemplate = jmsTemplate;
        this.documentDlQueueName = documentDlQueueName;
    }

    /**
     *
     * @param payload
     */
    public void sendMessageToDocumentDlQueue(String payload, int retryCount) {
        jmsTemplate.convertAndSend(documentDlQueueName, payload, m -> {
            m.setIntProperty(RETRY_COUNT, retryCount);
           return m;
        });
    }
}
