package gov.uspto.pe2e.dav.document.etl.config.db;

import gov.uspto.pe2e.dav.document.etl.repository.ExtendedJPARepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

/**
 * @author Ashok Srinivasula
 *
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "gov.uspto.pe2e.dav.document.etl.repository",
repositoryBaseClass = ExtendedJPARepository.class,
entityManagerFactoryRef = "sirdevPatrpt",
transactionManagerRef = "sirdevPatrptTxManager")
public class SIRDEVDBConfig  implements DBConfig {
    
    private static final String SIRDEV_DATASOURCE_BEAN_IDENTIFIER = "sirdevDataSource";
    
    @Resource
    private ApplicationContext ctx;
    
    /**
     * JNDI based datasource will be used in higher environment server deployments.
     * Method marked with spring profiles to not run in local development which uses
     * default spring-boot injected datasource from local properties file
     * <p>
     * An alias datasource is defined because sirdev-config project requires the
     * a datasource by that name
     * </p>
     *
     * @return datasource
     */
    @Profile("!local")
    @Bean(name = SIRDEV_DATASOURCE_BEAN_IDENTIFIER)
    public DataSource serverDataSource(@Value("${sirdev.datasource.jndi-name}") String jndiName) {
        return jndiDataSource(jndiName);
    }
    
    /**
     * Used to create tomcat managed datasource  for local development.
     * By default profile local is active when running in local machine.
     * see <code>Application</code> for more details
     *
     * @param jdbcUrl
     * @param userName
     * @param password
     * @return
     */
    @Profile("local")
    @Bean(name = SIRDEV_DATASOURCE_BEAN_IDENTIFIER)
    public DataSource localDevDataSource(@Value("${sirdev.datasource.url}") String jdbcUrl,
                                         @Value("${sirdev.datasource.username}") String userName,
                                         @Value("${sirdev.datasource.password}") String password,
                                         @Value("${sirdev.datasource.driverClassName}") String driverName) {
        return localDataSource(jdbcUrl, userName, password, driverName);
    }
    
    @Bean("sirdevJdbcTemplate")
    public JdbcTemplate getLdaJdbcTemplate(@Qualifier(SIRDEV_DATASOURCE_BEAN_IDENTIFIER) DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
    
    /**
     * Entity manager.
     *
     * @return
     */
    @Bean(name = { "sirdevPatrpt" })
    public LocalContainerEntityManagerFactoryBean entityManager() {
        return entityManager(ctx.getBean(SIRDEV_DATASOURCE_BEAN_IDENTIFIER, DataSource.class), 
                "gov.uspto.pe2e.dav.document.etl.entity", "sirdevPatrpt");
    }

    /**
     * tx manager.
     * 
     * @return
     */
    @Bean(name = { "sirdevPatrptTxManager" })
    public PlatformTransactionManager sirdevTxManager(EntityManagerFactory emf) {
        return transactionManager(emf);
    }

    /**
     * exception transl.
     *
     * @return
     */
    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
        return new PersistenceExceptionTranslationPostProcessor();
    }
}
