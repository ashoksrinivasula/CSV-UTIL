package gov.uspto.pe2e.intake.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import gov.uspto.pe2e.intake.util.StaasMigrationConstants;
import gov.uspto.pe2e.lda.model.entity.DocumentResourcePatiResultset;
import gov.uspto.pe2e.lda.model.entity.DocumentResourceResultset;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author asrinivasula
 * 
 */
@Slf4j
@Component
public class DocumentResourceDao  {

	private static final String TIME_TAKEN_IN_MILLISECONDS = " Time Taken in MILLISECONDS ";

	public static final String RESOURCE_STORAGE_DOMAIN_CD = "resource_storage_domain_cd";

	public static final String LAST_MOD_TS = "last_mod_ts";

	public static final String CREATE_TS = "create_ts";

	public static final String LAST_MOD_USER_ID = "last_mod_user_id";

	public static final String CREATE_USER_ID = "create_user_id";

	public static final String RESOURCE_STORAGE_ID = "resource_storage_id";

	public static final String FK_DOC_RESOURCE_ID = "fk_document_resource_id";

	public static final String DOC_RESOURCE_ID = "doc_resource_id";

	@Autowired
	private JdbcTemplate pe2eJdbcTemplate;
	
	@Autowired
	private JdbcTemplate pe2eReadJdbcTemplate;
	
	@Autowired
	private NamedParameterJdbcTemplate pe2eWriteNamedJdbcTemplate;
	
	@Autowired
	private NamedParameterJdbcTemplate pe2eReadNamedJdbcTemplate;

	
	public DocumentResourceResultset getDocReourceById(final Long docResourceId){
		long startTime = System.nanoTime();
		DocumentResourceResultset documentResourceResultset = null;
		try{
			MapSqlParameterSource namedParameters =  new MapSqlParameterSource();            
			namedParameters.addValue(DOC_RESOURCE_ID, docResourceId);
			namedParameters.addValue(FK_DOC_RESOURCE_ID, docResourceId);            
			List<DocumentResourceResultset> documentResourceResultsetList = pe2eReadNamedJdbcTemplate.query(StaasMigrationConstants.DOC_RESOURCE_QUERY,
					namedParameters, new dbResultsetRowMapper());
			if(documentResourceResultsetList!=null && documentResourceResultsetList.size()>StaasMigrationConstants.ZERO){
				documentResourceResultset = documentResourceResultsetList.get(StaasMigrationConstants.ZERO);
			}
		} catch (EmptyResultDataAccessException e) {
			log.warn("getDocReourceById: No documents found");
		}
		log.info("Time Taken to DB_Fetch record document Resource-ID " +docResourceId + TIME_TAKEN_IN_MILLISECONDS +
				TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS)+" "+documentResourceResultset);
		return documentResourceResultset;
	}

	
	public List<Long> validateDocReourceIds(final Long startDocResourceId,final Long endDocResourceId){
		long startTime = System.nanoTime();
		 List<Long> documentResourceList = null;
		try{
			MapSqlParameterSource namedParameters =  new MapSqlParameterSource();            
			namedParameters.addValue("str_document_resource_id", startDocResourceId);
			namedParameters.addValue("end_document_resource_id", endDocResourceId);    
			documentResourceList=pe2eReadNamedJdbcTemplate.query(StaasMigrationConstants.DOC_RESOURCE_VALIDATION_QUERY,
					namedParameters, new docResourceResultsetRowMapper());		
		} catch (EmptyResultDataAccessException e) {
			log.warn("getDocReourceById: No documents found");
		}
		log.info("Time Taken to Validate documentResourceIds  from " +startDocResourceId + " to "+endDocResourceId+TIME_TAKEN_IN_MILLISECONDS +
				TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS));
		return documentResourceList;
	}
	
	
	public List<DocumentResourcePatiResultset> getPatiDocumentSourceSystemKeys(final String appId) {
	        // Get StartTime
	        long startTime = System.nanoTime();
	        List<DocumentResourcePatiResultset> lstDocResourcePatiResultset = pe2eReadJdbcTemplate.query(new PreparedStatementCreator() {
	            @Override
	            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
	                return con.prepareStatement(StaasMigrationConstants.GET_PATIDOCS_SOURCESYSTEM_KEYS_ONETIME_STAAS_MIG);
	            }
	        }, new PreparedStatementSetter() {
	            @Override
	            public void setValues(PreparedStatement ps) throws SQLException {
	                ps.setString(1, appId);
	            }
	        }, new ResultSetExtractor<List<DocumentResourcePatiResultset>>() {
	            @Override
	            public List<DocumentResourcePatiResultset> extractData(ResultSet rs) throws SQLException  {
	                List<DocumentResourcePatiResultset> lstDocResPatiResultsetResults = new LinkedList<>();
	                while (rs.next()) {
	                    DocumentResourcePatiResultset objDocResPatiResultset = new DocumentResourcePatiResultset();
	                    
	                    objDocResPatiResultset.setApplicationId(rs.getString("application_id"));
	                    objDocResPatiResultset.setDocumentId(rs.getLong("DOCUMENT_ID"));
	                    objDocResPatiResultset.setSourceSystemsKey(rs.getString("SOURCE_SYSTEM_KEY_TX"));
	                    objDocResPatiResultset.setDocResourceId(rs.getLong("DOCUMENT_RESOURCE_ID"));	                    
	                    
	                    lstDocResPatiResultsetResults.add(objDocResPatiResultset);
	                }
	                rs.close();	                
	                return lstDocResPatiResultsetResults;
	            }
	        });
	        long estimatedTime = System.nanoTime() - startTime; 
	        // Calculate the  total time taken     
	        log.info("Time Taken to DB_Fetch record with appId  :" +appId + "Time Taken in MILLISECONDS " +
	                TimeUnit.MILLISECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS)+lstDocResourcePatiResultset);
	        return lstDocResourcePatiResultset;
	}
	
	
	public List<DocumentResourcePatiResultset> getBulkPatiDocumentSourceSystemKeys(final List<String> lstAppiDs) {
        // Get StartTime
        long startTime = System.nanoTime();
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("BulkAppIds", lstAppiDs);     
        List<DocumentResourcePatiResultset> lstDocResourcePatiResultset = pe2eReadNamedJdbcTemplate.query(StaasMigrationConstants.GET_BULK_PATIDOCS_SOURCESYSTEM_KEYS_STAAS_MIG,
                parameters,
                 new ResultSetExtractor<List<DocumentResourcePatiResultset>>() {
                    @Override
                    public List<DocumentResourcePatiResultset> extractData(ResultSet rs) throws SQLException  {
                        List<DocumentResourcePatiResultset> lstDocResPatiResultsetResults = new LinkedList<>();
                        while (rs.next()) {
                            DocumentResourcePatiResultset objDocResPatiResultset = new DocumentResourcePatiResultset();
                            
                            objDocResPatiResultset.setApplicationId(rs.getString("application_id"));
                            objDocResPatiResultset.setDocumentId(rs.getLong("DOCUMENT_ID"));
                            objDocResPatiResultset.setSourceSystemsKey(rs.getString("SOURCE_SYSTEM_KEY_TX"));
                            objDocResPatiResultset.setDocResourceId(rs.getLong("DOCUMENT_RESOURCE_ID"));	                    
                            
                            lstDocResPatiResultsetResults.add(objDocResPatiResultset);
                        }
                        rs.close();	                
                        return lstDocResPatiResultsetResults;
                    }
                });           
        
        long estimatedTime = System.nanoTime() - startTime; 
        log.info("End of getBulkPatiDocumentSourceSystemKeys method");
        return lstDocResourcePatiResultset;
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void saveDocumentResourceStorage(Long docResourceId, String fileId, String nameSpace){
		long startTime = System.nanoTime();
		Map namedParameters = new HashMap();   
		namedParameters.put(FK_DOC_RESOURCE_ID, docResourceId);   
		namedParameters.put(RESOURCE_STORAGE_ID, fileId);
		namedParameters.put(CREATE_USER_ID, StaasMigrationConstants.LONG_ONE);
		namedParameters.put(LAST_MOD_USER_ID, StaasMigrationConstants.LONG_ONE);		
		namedParameters.put(RESOURCE_STORAGE_DOMAIN_CD, nameSpace);   
		pe2eWriteNamedJdbcTemplate.update(StaasMigrationConstants.INSERT_DOC_RESOURCE_STORAGE, namedParameters);
		log.info("SaveDocumentResourceStorage for docResourceId "+docResourceId+" and fileId "+fileId+" and nameSpace "+nameSpace+
				TIME_TAKEN_IN_MILLISECONDS +	TimeUnit.MILLISECONDS.convert( System.nanoTime() - startTime, TimeUnit.NANOSECONDS));
	}
	
	@Transactional
	public void createDocumentSVG(DocumentResourcePatiResultset documentResource, final String fileIdSVG,
			final String strNameSpace, final long fileSize) {		
		long startTime = System.nanoTime();
		final long docuemntId = documentResource.getDocumentId();
		long docSvgDocResourceIdKey = 0L;
				
		try
		{					
			//Insert into document_rendition
			GeneratedKeyHolder holderDocRendition = new GeneratedKeyHolder();
			pe2eJdbcTemplate.update(new PreparedStatementCreator() {
			    @Override
			    public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
			        //PreparedStatement ps = con.prepareStatement(StaasMigrationConstants.INSERT_DOC_RENDITION, Statement.RETURN_GENERATED_KEYS);
			    	PreparedStatement ps = con.prepareStatement(StaasMigrationConstants.INSERT_DOC_RENDITION, new String[] {"DOCUMENT_RENDITION_ID"});
			        ps.setObject(1, docuemntId);	// FK_DOCUMENT_ID
			        ps.setObject(2,12);	// FK_STND_RENDITION_TYPE_ID
			        ps.setObject(3, 0 ); // lock_control_no
			        ps.setObject(4, 0);	// DELETE_IN
			        ps.setObject(5, 0);	// CREATE_USER_ID
			        ps.setObject(6, 0);	// LAST_MOD_USER_ID
			        return ps;
			    }
			}, holderDocRendition);	
			final long docRenditionIdKey = holderDocRendition.getKey().longValue();
						
			//Insert into document_resource	
			GeneratedKeyHolder holderSvgDocRerourceId = new GeneratedKeyHolder();
			pe2eJdbcTemplate.update(new PreparedStatementCreator() {
			    @Override
			    public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
			    	PreparedStatement ps = con.prepareStatement(StaasMigrationConstants.INSERT_DOC_RESOURCE, new String[] {"DOCUMENT_RESOURCE_ID"});
			    	ps.setObject(1, docRenditionIdKey); //FK_DOCUMENT_RENDITION_ID
		    		ps.setObject(2, 639); //FK_STND_MIME_TYPE_ID
			        ps.setObject(3, 1);  //PAGE_NO
			        ps.setObject(4, StaasMigrationConstants.STAAS_ONLY); //DOCUMENT_LOCATION_TX
			        ps.setObject(5, null); //NOMINAL_LOCATION_TX
			        ps.setObject(6, fileSize); // FILE_SIZE_NO
			        ps.setObject(7, null); //ALIAS_NM
			        ps.setObject(8, 0); //lock_control_no
			        ps.setObject(9, 0); //DELETE_IN
			        ps.setObject(10, 0); //CREATE_USER_ID
			        ps.setObject(11, 0); //LAST_MOD_USER_ID
			        ps.setObject(12, null); //original_filename_tx
			        ps.setObject(13, 0); //ocr_text_in
			        ps.setObject(14, 0); //ocr_pdf_in
			        return ps;
			    }
			}, holderSvgDocRerourceId);	
			docSvgDocResourceIdKey = holderSvgDocRerourceId.getKey().longValue();
			
			// insert into document_resource_storage
			if (fileIdSVG != null) {
				String[] fileStringArray = fileIdSVG.split(StaasMigrationConstants.SLASH, StaasMigrationConstants.TWO);
				if (fileStringArray.length > StaasMigrationConstants.ONE) {
					saveDocumentResourceStorage(docSvgDocResourceIdKey, fileStringArray[StaasMigrationConstants.ONE], fileStringArray[StaasMigrationConstants.ZERO]);
				} else {
					saveDocumentResourceStorage(docSvgDocResourceIdKey, fileIdSVG, strNameSpace);
				}

			} else {
				log.error("Exception in STAAS Pati Upload. File_Id return as Null for docResourceId " + docSvgDocResourceIdKey);
			}
		}
		catch(Exception ex)
		{
			log.info("  Exception raised in createDocumentSVG method :"+ ex);
		}
		
		log.info("SVG relation created for SVG file Id :"+ fileIdSVG +"of documentResourceId: "+ String.valueOf(docSvgDocResourceIdKey) + TIME_TAKEN_IN_MILLISECONDS +
					TimeUnit.MILLISECONDS.convert( System.nanoTime() - startTime, TimeUnit.NANOSECONDS));
	}
	
	
    
    /**
     * 
     * The pe2eDatabaseCheck method checks the connectivity to PE2E database and
     * returns a boolean value
     * 
     * @return boolean
     * 
     */
	public boolean pe2eDatabaseCheck() {
		return 	pe2eJdbcTemplate.queryForObject(StaasMigrationConstants.HEALTH_CHECK_QUERY,String.class)!=null;
	}
	

	class dbResultsetRowMapper implements RowMapper<DocumentResourceResultset> {
		public DocumentResourceResultset mapRow(ResultSet rs, int rowNum) throws SQLException {
			DocumentResourceResultset result = new DocumentResourceResultset();
			result.setDocResourceId(rs.getLong(StaasMigrationConstants.ONE));
			result.setFilePath(rs.getString(StaasMigrationConstants.TWO));
			result.setFileName(rs.getString(StaasMigrationConstants.THREE));
			result.setSourceSystemId(rs.getLong(StaasMigrationConstants.FOUR));
			result.setDocRenditionTypeId(rs.getLong(StaasMigrationConstants.FIVE));
			result.setDocumentCodeId(rs.getLong(StaasMigrationConstants.SIX));
			return result;
		}
	}
	
	class docResourceResultsetRowMapper implements RowMapper<Long> {
		public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
			Long result =rs.getLong(StaasMigrationConstants.ONE);			
			return result;
		}
	}

}

