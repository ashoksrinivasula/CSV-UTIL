package gov.uspto.pe2e.intake;

import org.apache.camel.CamelContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class StaasMigrationSpringBoot {
    @Autowired
    CamelContext camelContext;

    @Bean
    String status() {
        return "Staas Migration started...";
    }
}
