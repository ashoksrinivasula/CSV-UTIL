package gov.uspto.pe2e.intake.rest;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

import org.apache.commons.io.IOUtils;
import org.apache.commons.vfs2.FileNotFolderException;
import org.springframework.core.io.PathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.intake.util.StaasMigrationConstants;

@Component
public class RestClient {

	private static final String URL_PREFIX = "http://pelp-staas.fqt.uspto.gov/api/";
	private static final String FILE_PATH_PREFIX = "C:\\DATA\\DAV_CW\\atlas\\11\\656\\635\\EXDGJKQNPPOPPY2\\pages\\";
	private static final String FILE_NAME = "00000002.tif";
	private static final String OUTPUT_FILE_NAME = "some.tif";
	
	//private static final String PATI_URL="http://dav-svcs.uspto.gov/IFWDataService/services/rest/PatiService/patidoc/59000101/29768197.xml";

	public static void main(String args[]) throws Exception {		
		String fileId = RestClient.postFile();
		 System.out.println("fileId:" + fileId);
	}

	public static void getFileAndWriteToFS(String fileId) {
		String url = URL_PREFIX + fileId;

		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));

		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<byte[]> response = restTemplate.exchange(url, HttpMethod.GET, entity, byte[].class);

		if (response.getStatusCode() == HttpStatus.OK) {
			try {
				Files.write(Paths.get(FILE_PATH_PREFIX + OUTPUT_FILE_NAME), response.getBody());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void deleteFile(String fileId) throws Exception {
        String url = URL_PREFIX + fileId;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.DELETE, entity, String.class);
        if (response.getStatusCode() == HttpStatus.NO_CONTENT) {
        	System.out.println("File Deleted Sucessfully for the File ID:" + fileId);
        } else {
        	System.out.println("File Deleted failed for the File ID:" + fileId);
        }
    }
	
	public static String postFile() throws IOException {
		String url = URL_PREFIX + "PD-TEXT3";
		PathResource pathResource = new PathResource(FILE_PATH_PREFIX + FILE_NAME);
		try {
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<String> result = restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(pathResource),
					String.class);

			ObjectMapper mapper = new ObjectMapper();
			JsonNode actualObj = mapper.readTree(result.getBody().toString());
			System.out.println(actualObj);
			return actualObj.get("location").textValue();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return null;

	}

	public static String staasHealthCheck() {
		RestTemplate restTemplate = new RestTemplate();
		try {
			ResponseEntity<String> response = restTemplate.getForEntity(URL_PREFIX, String.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				return StaasMigrationConstants.SERVICE_SUCCESS_STATUS;
			} else {
				return StaasMigrationConstants.SERVICE_FAILURE_STATUS;
			}

		} catch (Exception e) {
			return StaasMigrationConstants.SERVICE_FAILURE_STATUS;
		}

	}
	
	
	  public static byte[] getPatiDocStreamByUrl(String url) throws Exception {
	        byte[] bytes = null;
	        RestTemplate restTemplate = new RestTemplate();
	        HttpHeaders headers = new HttpHeaders();
	        headers.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
	        HttpEntity<String> entity = new HttpEntity<>(headers);
	        ResponseEntity<byte[]> response = restTemplate.exchange(url, HttpMethod.GET, entity, byte[].class);
	        if (response.getStatusCode() == HttpStatus.OK) {
	            bytes = response.getBody();
	        }
	        return bytes;
	    }

	
	 public static String postDocument(byte[] bytes, String nameSpace) throws Exception {
	        String url = URL_PREFIX + nameSpace;
	        RestTemplate restTemplate = new RestTemplate();
	        ResponseEntity<String> result = restTemplate.exchange(url, HttpMethod.POST,  new HttpEntity<>(bytes), String.class);
	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode actualObj = mapper.readTree(result.getBody());
	        return actualObj.get(StaasMigrationConstants.LOCATION).textValue();
	    }
	
	

}
