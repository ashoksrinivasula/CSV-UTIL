package gov.uspto.pe2e.lda.model.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.ToString;

/**
 * 
 * @author asrinivasula
 * 
 */

@ToString
public class StaasReprocessPayloadResultSet implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;	
	
	private String srndSreverName;
	
	private Long docResourceId;
	
	private String details; 
	
	private Integer retryActualNo;
	
	private Integer softDeleted = 0;
	
	private Integer lockCtrlNo;
	
	private Timestamp startTs;
	
	private Timestamp endTs;
	
	private String fileId;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the srndSreverName
	 */
	public String getSrndSreverName() {
		return srndSreverName;
	}

	/**
	 * @param srndSreverName the srndSreverName to set
	 */
	public void setSrndSreverName(String srndSreverName) {
		this.srndSreverName = srndSreverName;
	}

	/**
	 * @return the docResourceId
	 */
	public Long getDocResourceId() {
		return docResourceId;
	}

	/**
	 * @param docResourceId the docResourceId to set
	 */
	public void setDocResourceId(Long docResourceId) {
		this.docResourceId = docResourceId;
	}

	/**
	 * @return the details
	 */
	public String getDetails() {
		return details;
	}

	/**
	 * @param details the details to set
	 */
	public void setDetails(String details) {
		this.details = details;
	}

	/**
	 * @return the retryActualNo
	 */
	public Integer getRetryActualNo() {
		return retryActualNo;
	}

	/**
	 * @param retryActualNo the retryActualNo to set
	 */
	public void setRetryActualNo(Integer retryActualNo) {
		this.retryActualNo = retryActualNo;
	}

	/**
	 * @return the softDeleted
	 */
	public Integer getSoftDeleted() {
		return softDeleted;
	}

	/**
	 * @param softDeleted the softDeleted to set
	 */
	public void setSoftDeleted(Integer softDeleted) {
		this.softDeleted = softDeleted;
	}

	/**
	 * @return the lockCtrlNo
	 */
	public Integer getLockCtrlNo() {
		return lockCtrlNo;
	}

	/**
	 * @param lockCtrlNo the lockCtrlNo to set
	 */
	public void setLockCtrlNo(Integer lockCtrlNo) {
		this.lockCtrlNo = lockCtrlNo;
	}

	/**
	 * @return the startTs
	 */
	public Timestamp getStartTs() {
		return startTs;
	}

	/**
	 * @param startTs the startTs to set
	 */
	public void setStartTs(Timestamp startTs) {
		this.startTs = startTs;
	}

	/**
	 * @return the endTs
	 */
	public Timestamp getEndTs() {
		return endTs;
	}

	/**
	 * @param endTs the endTs to set
	 */
	public void setEndTs(Timestamp endTs) {
		this.endTs = endTs;
	}

	/**
	 * @return the fileId
	 */
	public String getFileId() {
		return fileId;
	}

	/**
	 * @param fileId the fileId to set
	 */
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

}
