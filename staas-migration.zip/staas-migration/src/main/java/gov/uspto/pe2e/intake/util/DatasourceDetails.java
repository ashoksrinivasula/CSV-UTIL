package gov.uspto.pe2e.intake.util;

import java.sql.DatabaseMetaData;
import java.sql.SQLException;

import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Ashok Srinivasula
 *
 * 
 */
@Slf4j
public class DatasourceDetails {

    public static final String LDA_DATABASE = "LDA_DATABASE";
    public static final String PE2E_WRITE_DATABASE = "PE2E_WRITE_DATABASE";
    public static final String PE2E_READ_DATABASE = "PE2E_READ_DATABASE";

    public void fetchDatasourceInfo(DataSource ldaDatasource, DataSource pe2eDataWriteSource,DataSource pe2eDataReadSource) throws SQLException {
        printInfo(LDA_DATABASE, ldaDatasource);
        printInfo(PE2E_WRITE_DATABASE, pe2eDataWriteSource);
        printInfo(PE2E_READ_DATABASE, pe2eDataReadSource);
    }

    public void printInfo(String databaseName, DataSource datasource) throws SQLException {
        DatabaseMetaData metaData = datasource.getConnection().getMetaData();
        log.info("Database Name :" + databaseName + " url :"
                + metaData.getURL()
                + " username :" + metaData.getUserName()
                + " productName :" + metaData.getDatabaseProductName()
                + " productVersion :" + metaData.getDatabaseProductVersion()
                + " driverName :" + metaData.getDriverName()
                + " driverVersion :" + metaData.getDriverVersion()
        );
    }
}
