package gov.uspto.pe2e.lda.model.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.ToString;

/**
 * 
 * @author asrinivasula
 * 
 */

@ToString
public class StaasMigrationPayloadResultSet implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	
	private String srndSreverName;

	
	private Long startDocResourceId;

	
	private Long endDocResourceId;

	
	private Integer retryActualNo;

	
	private Integer softDeleted = 0;

	
	private Integer lockCtrlNo;

	
	private Timestamp startTs;

	
	private Timestamp endTs;

	
	private Long count;
	
	
	private String applicationId;

	
	/**
	 * @return the startDocResourceId
	 */
	public Long getStartDocResourceId() {
		return startDocResourceId;
	}

	/**
	 * @param startDocResourceId the startDocResourceId to set
	 */
	public void setStartDocResourceId(Long startDocResourceId) {
		this.startDocResourceId = startDocResourceId;
	}

	/**
	 * @return the endDocResourceId
	 */
	public Long getEndDocResourceId() {
		return endDocResourceId;
	}

	/**
	 * @param endDocResourceId the endDocResourceId to set
	 */
	public void setEndDocResourceId(Long endDocResourceId) {
		this.endDocResourceId = endDocResourceId;
	}

	/**
	 * @return the retryActualNo
	 */
	public Integer getRetryActualNo() {
		return retryActualNo;
	}

	/**
	 * @param retryActualNo the retryActualNo to set
	 */
	public void setRetryActualNo(Integer retryActualNo) {
		this.retryActualNo = retryActualNo;
	}


	/**
	 * @return the startTs
	 */
	public Timestamp getStartTs() {
		return startTs;
	}

	/**
	 * @param startTs the startTs to set
	 */
	public void setStartTs(Timestamp startTs) {
		this.startTs = startTs;
	}

	/**
	 * @return the endTs
	 */
	public Timestamp getEndTs() {
		return endTs;
	}

	/**
	 * @param endTs the endTs to set
	 */
	public void setEndTs(Timestamp endTs) {
		this.endTs = endTs;
	}

	/**
	 * @return the count
	 */
	public Long getCount() {
		return count;
	}

	/**
	 * @param count the count to set
	 */
	public void setCount(Long count) {
		this.count = count;
	}


	/**
	 * @return the lockCtrlNo
	 */
	public Integer getLockCtrlNo() {
		return lockCtrlNo;
	}

	/**
	 * @param lockCtrlNo the lockCtrlNo to set
	 */
	public void setLockCtrlNo(Integer lockCtrlNo) {
		this.lockCtrlNo = lockCtrlNo;
	}

	/**
	 * @return the srndSreverName
	 */
	public String getSrndSreverName() {
		return srndSreverName;
	}

	/**
	 * @param srndSreverName the srndSreverName to set
	 */
	public void setSrndSreverName(String srndSreverName) {
		this.srndSreverName = srndSreverName;
	}

	/**
	 * @return the softDeleted
	 */
	public Integer getSoftDeleted() {
		return softDeleted;
	}

	/**
	 * @param softDeleted the softDeleted to set
	 */
	public void setSoftDeleted(Integer softDeleted) {
		this.softDeleted = softDeleted;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
     * @return the applicationId
     */
    public String getApplicationId() {
        return applicationId;
    }

    /**
     * @param applicationId the applicationId to set
     */
    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }
	
	
}
