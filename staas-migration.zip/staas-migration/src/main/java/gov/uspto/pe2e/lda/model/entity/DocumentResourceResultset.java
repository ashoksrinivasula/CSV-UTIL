package gov.uspto.pe2e.lda.model.entity;

import lombok.ToString;

/**
 * 
 * @author asrinivasula
 * 
 */

@ToString
public class DocumentResourceResultset {

	private Long docResourceId;

	private String filePath;

	private String fileName;

	private Long sourceSystemId;

	private Long docRenditionTypeId;
	
	private Long documentCodeId;
	
	

	/**
	 * @return the docResourceId
	 */
	public Long getDocResourceId() {
		return docResourceId;
	}

	/**
	 * @param docResourceId the docResourceId to set
	 */
	public void setDocResourceId(Long docResourceId) {
		this.docResourceId = docResourceId;
	}

	/**
	 * @return the filePath
	 */
	public String getFilePath() {
		return filePath;
	}

	/**
	 * @param filePath the filePath to set
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the sourceSystemId
	 */
	public Long getSourceSystemId() {
		return sourceSystemId;
	}

	/**
	 * @param sourceSystemId the sourceSystemId to set
	 */
	public void setSourceSystemId(Long sourceSystemId) {
		this.sourceSystemId = sourceSystemId;
	}

	/**
	 * @return the docRenditionTypeId
	 */
	public Long getDocRenditionTypeId() {
		return docRenditionTypeId;
	}

	/**
	 * @param docRenditionTypeId the docRenditionTypeId to set
	 */
	public void setDocRenditionTypeId(Long docRenditionTypeId) {
		this.docRenditionTypeId = docRenditionTypeId;
	}

	/**
	 * @return the documentCodeId
	 */
	public Long getDocumentCodeId() {
		return documentCodeId;
	}

	/**
	 * @param documentCodeId the documentCodeId to set
	 */
	public void setDocumentCodeId(Long documentCodeId) {
		this.documentCodeId = documentCodeId;
	}
	
}
