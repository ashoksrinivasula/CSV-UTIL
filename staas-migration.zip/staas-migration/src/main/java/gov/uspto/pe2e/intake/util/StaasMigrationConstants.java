package gov.uspto.pe2e.intake.util;

public class StaasMigrationConstants {

    public static final int ZERO = 0;
    public static final int ONE = 1;
    public static final int TWO = 2;
    public static final int THREE = 3;
    public static final int FOUR = 4;
    public static final int FIVE = 5;
    public static final int SIX = 6;
    public static final int SEVEN = 7;
    public static final int EIGHT = 8;
    public static final int NINE = 9;
    public static final int TEN = 10;
    public static final int DURATION_CONSTANT = 64;
    public static final int SLEEP_INTERVAL=300000;
    public static final Long SEQLISTING_DOC_CODE = 3446l;
    public static final Long LONG_ZERO = 0l;
    public static final Long LONG_ONE = 1l;
    public static final Long LONG_TWO = 2l;
    public static final Long LONG_THREE = 3l;
    public static final Long LONG_FOUR = 4l;
    public static final Long LONG_FIVE = 5l;
    public static final Long LONG_SIX = 6l;
    public static final Long LONG_SEVEN = 7l;
    public static final int PATI_PALYLOAD_LIMIT = 20;
    public static final String PAYLOAD_ID = "PAYLOAD_ID";
    public static final String PAYLOAD_IDS = "PAYLOAD_IDS";
    public static final String SLASH = "/";
    public static final String LOCATION = "location";
    public static final String TIF = ".tif";
    public static final String SERVICE_SUCCESS_STATUS="Success";
    public static final String SERVICE_FAILURE_STATUS="Failure";
    public static final String STRING_BRACKETS = "']";
    public static final String DOCUMENT_URI_DOCUMENT_KEY_ID = "//DocumentURI[../DocumentKeyID='";    
    public static final String STAAS_ONLY = "STAAS_ONLY";
    
    
 // Camel Split Thread Pool
    public static final int SPLIT_THREAD_POOL_SIZE = 700;
    public static final int SPLIT_THREAD_MAX_POOL_SIZE = 700;
    public static final int SPLIT_THREAD_MAX_QUEUE_SIZE = 50000;
    public static final Long SPLIT_THREAD_KEEP_ALIVE_TIME = 600L;
    
	public static final int PATI_APPID_EXECUTOR_POOL_SIZE = 20;
	public static final int PATI_APPID_EXECUTOR_POOL_MAX_SIZE = 20;
	public static final int PATI_APPID_EXECUTOR_QUEUE_SIZE = 20;

	public static final int PATI_DOC_EXECUTOR_POOL_SIZE = 10;
	public static final int PATI_DOC_EXECUTOR_POOL_MAX_SIZE = 10;
	public static final int PATI_DOC_EXECUTOR_QUEUE_SIZE = 5000;

    public static final String DOC_RESOURCE_QUERY = " select drsc.DOCUMENT_RESOURCE_ID as docResourceId,"
    		+ " drsc.DOCUMENT_LOCATION_TX as filePath, "
    		+ " drsc.original_filename_tx  as fileName, "
    		+ "	CASE "
    		+ " WHEN doc.FK_STND_SOURCE_SYSTEM_ID is null "
    		+ " THEN 1 "
    		+ " ELSE doc.FK_STND_SOURCE_SYSTEM_ID "
    		+ " END "
    		+ " as sourceSystemId, "
    		+ " dren.FK_STND_RENDITION_TYPE_ID as docRenditionTypeId, "
    		+ " doc.FK_STND_DOCUMENT_CODE_ID as doc_code "
    		+ " from  document_resource drsc "
    		+ " inner join document_rendition dren on dren.DOCUMENT_RENDITION_ID = drsc.FK_DOCUMENT_RENDITION_ID and dren.DELETE_IN=0 "
    		+ " inner join document doc on doc.DOCUMENT_ID = dren.FK_DOCUMENT_ID and doc.DELETE_IN =0 "
    		+ " where drsc.DOCUMENT_RESOURCE_ID = :doc_resource_id and drsc.DELETE_IN =0 "
    		+ " and drsc.DOCUMENT_RESOURCE_ID not in (select fk_document_resource_id "
    		+ " from document_resource_storage where fk_document_resource_id  = :fk_document_resource_id ) "
    		+ "	limit 1 ";

    public static final String DOC_RESOURCE_VALIDATION_QUERY = "select DOCUMENT_RESOURCE_ID from document_resource where delete_in=0 and DOCUMENT_RESOURCE_ID between :str_document_resource_id and :end_document_resource_id ";
    		
	public static final String INSERT_DOC_RESOURCE_STORAGE = " insert into document_resource_storage"
			+ " (fk_document_resource_id,resource_storage_id,"
			+ " create_user_id, last_mod_user_id,create_ts,last_mod_ts,resource_storage_domain_cd)"
			+ " values(:fk_document_resource_id, :resource_storage_id, :create_user_id,"
			+ " :last_mod_user_id, now(), now(), :resource_storage_domain_cd)";
	
	
	
	public static final String GET_PAYLOAD_QUERY = "select smp.staas_migration_payload_id as id, smp.start_doc_resource_id as startDocResourceId,smp.end_doc_resource_id as endDocResourceId, "
			+ " ss.SERVER_CD as srndSrever, smp.retry_actual_no as retryActualNo, smp.lock_control_no as lockCtrlNo, "
			+ " smp.delete_in as softDeleted, smp.start_ts as startTs, smp.end_ts as endTs , smp.count as count "
			+ " from staas_migration_payload smp "
			+ " inner join STND_SERVER ss on ss.STND_SERVER_ID = smp.FK_STND_SERVER_ID "
			+ " where smp.delete_in = 0 and smp.lock_control_no = 0 and smp.retry_actual_no <= 2 and ss.SERVER_CD = :server_name limit 1";
	
	
	public static final String GET_REPROCESS_PAYLOAD_QUERY = "select smp.staas_reprocess_id as id, smp.doc_resource_id as docResourceId, smp.details as details, "
			+ " ss.SERVER_CD as srndSrever, smp.retry_actual_no as retryActualNo, smp.lock_control_no as lockCtrlNo, "
			+ " smp.delete_in as softDeleted, smp.start_ts as startTs, smp.end_ts as endTs, smp.storage_file_id as fileId "
			+ " from staas_reprocess smp "
			+ " inner join STND_SERVER ss on ss.STND_SERVER_ID = smp.FK_STND_SERVER_ID "
			+ " where smp.delete_in = 0 and smp.lock_control_no = 0 and smp.retry_actual_no <= 2 and smp.FK_STND_SERVER_ID = :server_id	limit 50000 ";
	
	public static final String UPDATE_LOCK = "update staas_migration_payload set lock_control_no = ?, last_mod_ts = now(), start_ts = ? where staas_migration_payload_id = ? ";
	
	public static final String UPDATE_COUNT = "update staas_migration_payload set  last_mod_ts = now(), count = ? where staas_migration_payload_id = ? ";
	
	public static final String UPDATE_REPROCESS_LOCK = "update staas_reprocess set lock_control_no = ?, last_mod_ts = now(), start_ts = ? where staas_reprocess_id = ? ";
	
	public static final String UPDATE_DELETE_IN = "update staas_migration_payload set delete_in = 1, last_mod_ts = now(), end_ts = ? where staas_migration_payload_id = ? ";
	
	public static final String UPDATE_REPROCESS_DELETE_IN = "update staas_reprocess set delete_in = 1, last_mod_ts = now(), end_ts = ? where staas_reprocess_id = ? ";
	
	public static final String INSERT_QUERY = "INSERT INTO staas_migration_payload (start_doc_resource_id, end_doc_resource_id, "
			+ "create_user_id, last_mod_user_id,lock_control_no,delete_in) VALUES (?, ?, ?, ?, ?, ?)  ON DUPLICATE KEY UPDATE retry_actual_no = retry_actual_no+1 ";
	
	public static final String REPROCESS_INSERT_QUERY = "INSERT INTO staas_reprocess (doc_resource_id, details, create_user_id, last_mod_user_id,lock_control_no,delete_in,storage_file_id,error_cd) "
			+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?)  ON DUPLICATE KEY UPDATE retry_actual_no = retry_actual_no+1 ";
	
	public static final String UPDATE_DOC_RESOURCE = "update document_resource set original_filename_tx = ?, last_mod_ts = now() where document_resource_id = ? ";
	
	public static final String GET_SERVER_DELETE = "select delete_in from STND_SERVER where SERVER_CD = :server_name";
	
	public static final String GET_SERVER_ID = "select STND_SERVER_ID from STND_SERVER where SERVER_CD = :server_name";
	
	
	public static final String GET_PATIDOCS_SOURCESYSTEM_KEYS_ONETIME_STAAS_MIG ="select id.application_id application_id, child.DOCUMENT_ID DOCUMENT_ID,  "
	         + "child.SOURCE_SYSTEM_KEY_TX SOURCE_SYSTEM_KEY_TX, childres.DOCUMENT_RESOURCE_ID DOCUMENT_RESOURCE_ID "
             + "from invention_disclosure id inner join invention_disclosure_doc idd on "
             + "id.invention_disclosure_id = idd.fk_invention_disclosure_id and idd.delete_in=0 "
             + "inner join document folder on idd.fk_document_id = folder.DOCUMENT_ID and folder.delete_in=0 "
             + "inner join stnd_document_code dcd on folder.FK_STND_DOCUMENT_CODE_ID = dcd.STND_DOCUMENT_CODE_ID "
             + "inner join related_document rel on folder.document_id = rel.FK_PARENT_DOCUMENT_ID and rel.delete_in=0 "
             + "inner join document child on rel.FK_DOCUMENT_ID = child.DOCUMENT_ID and child.delete_in=0 "
             + "inner join document_rendition childrend on child.document_id = childrend.FK_DOCUMENT_ID and childrend.delete_in=0 "
             + "inner join document_resource childres on childrend.DOCUMENT_RENDITION_ID = childres.FK_DOCUMENT_RENDITION_ID and childres.delete_in=0 "
             + "left join document_resource_storage drs on childres.document_resource_id = drs.fk_document_resource_id "
             + "where dcd.document_cd = 'FOLDER.TOC' and childrend.FK_STND_RENDITION_TYPE_id=6 and id.delete_in=0 and id.application_id =? and drs.fk_document_resource_id is null";
	
	public static final String GET_BULK_PATIDOCS_SOURCESYSTEM_KEYS_STAAS_MIG ="select id.application_id application_id, child.DOCUMENT_ID DOCUMENT_ID,  "
	         + "child.SOURCE_SYSTEM_KEY_TX SOURCE_SYSTEM_KEY_TX, childres.DOCUMENT_RESOURCE_ID DOCUMENT_RESOURCE_ID "
            + "from invention_disclosure id inner join invention_disclosure_doc idd on "
            + "id.invention_disclosure_id = idd.fk_invention_disclosure_id and idd.delete_in=0 "
            + "inner join document folder on idd.fk_document_id = folder.DOCUMENT_ID and folder.delete_in=0 "
            + "inner join stnd_document_code dcd on folder.FK_STND_DOCUMENT_CODE_ID = dcd.STND_DOCUMENT_CODE_ID "
            + "inner join related_document rel on folder.document_id = rel.FK_PARENT_DOCUMENT_ID and rel.delete_in=0 "
            + "inner join document child on rel.FK_DOCUMENT_ID = child.DOCUMENT_ID and child.delete_in=0 "
            + "inner join document_rendition childrend on child.document_id = childrend.FK_DOCUMENT_ID and childrend.delete_in=0 "
            + "inner join document_resource childres on childrend.DOCUMENT_RENDITION_ID = childres.FK_DOCUMENT_RENDITION_ID and childres.delete_in=0 "
            + "left join document_resource_storage drs on childres.document_resource_id = drs.fk_document_resource_id "
            + "where dcd.document_cd = 'FOLDER.TOC' and childrend.FK_STND_RENDITION_TYPE_id=6 and id.delete_in=0 and id.application_id in (:BulkAppIds) and drs.fk_document_resource_id is null";
            //+ "where dcd.document_cd = 'FOLDER.TOC' and childrend.FK_STND_RENDITION_TYPE_id=6 and id.delete_in=0 and id.application_id in (:BulkAppIds) and drs.fk_document_resource_id is null";
	
   public static final String GET_ONETIME_PATI_MIG_PATI_PAYLOAD_APPID = "select spmp.staas_pati_mig_payload_id as id, spmp.application_id as appId, ss.SERVER_CD as srndSrever,"
               + " spmp.retry_actual_no as retryActualNo, "
               + "spmp.lock_control_no as lockCtrlNo, " 
	           + "spmp.delete_in as softDeleted, spmp.start_ts as startTs, spmp.end_ts as endTs , spmp.count as count "
	           + "from staas_pati_mig_payload spmp inner join STND_SERVER ss on ss.STND_SERVER_ID = spmp.FK_STND_SERVER_ID "
               + "where spmp.delete_in = 0 and spmp.lock_control_no = 0 and spmp.retry_actual_no <= 2 "
               + "and ss.SERVER_CD = ? limit 1";
   			   //+ "and ss.SERVER_CD = ? and spmp.application_id in ('13479597','13479602') limit 1";
   
   public static final String GET_BULK_PATI_MIG_PAYLOAD_APPIDS = "select spmp.staas_pati_mig_payload_id as id, spmp.application_id as appId, ss.SERVER_CD as srndSrever,"
           + " spmp.retry_actual_no as retryActualNo, "
           + "spmp.lock_control_no as lockCtrlNo, " 
           + "spmp.delete_in as softDeleted, spmp.start_ts as startTs, spmp.end_ts as endTs , spmp.count as count "
           + "from staas_pati_mig_payload spmp inner join STND_SERVER ss on ss.STND_SERVER_ID = spmp.FK_STND_SERVER_ID "
           + "where spmp.delete_in = 0 and spmp.lock_control_no = 0 and spmp.retry_actual_no <= 2 "
           + "and ss.SERVER_CD = :server_name limit :patiPayLoadLimit";
   			
   
    public static final String UPDATE_LOCK_PATI = "update staas_pati_mig_payload set lock_control_no = ?, last_mod_ts = now(), start_ts = ? where staas_pati_mig_payload_id = ? ";
    
    public static final String UPDATE_DELETE_INDICATOR_FOR_PATI = "update staas_pati_mig_payload set delete_in = 1, last_mod_ts =now(), end_ts=now() where staas_pati_mig_payload_id in(:patiBulkPayloadIds)";
    
	public static final String UPDATE_DELETE_IN_PATI = "update staas_pati_mig_payload set delete_in = 1, last_mod_ts = now(), end_ts = ? where staas_pati_mig_payload_id = ? ";
	
	public static final String UPDATE_NULL_PAYLOAD_COUNT_PATI = "update staas_pati_mig_payload set delete_in = 1,lock_control_no=1,count=0, last_mod_ts = now(), end_ts = ? where staas_pati_mig_payload_id = ? ";
	
	public static final String UPDATE_COUNT_PATI = "update staas_pati_mig_payload set last_mod_ts = now(), count = ? where staas_pati_mig_payload_id = ? ";
	
	public static final String UPDATE_RETRYCOUNT_PATI = "update staas_pati_mig_payload set last_mod_ts = now(), retry_actual_no = retry_actual_no+ 1 where staas_pati_mig_payload_id = ? ";
	
	//Pati new Rendition relation queries 
	public static final String INSERT_DOC_RENDITION = 	"INSERT INTO document_rendition (FK_DOCUMENT_ID,FK_STND_RENDITION_TYPE_ID,lock_control_no,DELETE_IN,CREATE_TS,CREATE_USER_ID,LAST_MOD_TS,LAST_MOD_USER_ID) "
					+ "VALUES (?,?,?,?,now(),?,now(),?) ";
	
	public static final String INSERT_DOC_RESOURCE =  "INSERT INTO document_resource (FK_DOCUMENT_RENDITION_ID,FK_STND_MIME_TYPE_ID,PAGE_NO,"
			+ "DOCUMENT_LOCATION_TX,NOMINAL_LOCATION_TX,FILE_SIZE_NO,ALIAS_NM,lock_control_no,DELETE_IN,CREATE_TS,CREATE_USER_ID,LAST_MOD_TS,LAST_MOD_USER_ID,original_filename_tx,ocr_text_in,ocr_pdf_in) "
			+ "VALUES (?,?,?,?,?,?,?,?,?,now(),?,now(),?,?,?,?) ";
	
	public static final String UPDATE_PATI_PAYLOAD_FAILOVER = "update staas_pati_mig_payload set last_mod_ts = now(), lock_control_no = 2 where application_id = ? ";
	
	public static final String UPDATE_PATI_DOC_UPLOADED = "update staas_pati_mig_payload set  count = count+1, end_ts = now(), last_mod_ts = now() where application_id = ? ";
	
	public static final String HEALTH_CHECK_QUERY = "select 1"; 
	
	
    StaasMigrationConstants(){}
}
