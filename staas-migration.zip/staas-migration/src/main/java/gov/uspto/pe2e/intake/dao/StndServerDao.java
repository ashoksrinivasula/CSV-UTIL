package gov.uspto.pe2e.intake.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.uspto.pe2e.lda.model.entity.StndServer;

@Slf4j
@Repository
@Transactional("ldaTransactionManager")
public class StndServerDao {

	@PersistenceContext(unitName = "lda-ingest")
	private EntityManager ldaEntityManager;

	
	private static final String QUERY_GET_SERVER = "select ss from stnd_server ss "
			+ "where ss.delete_in = 0  and ss.SERVER_CD = :serverName limit 1";

	public StndServer getStndServerinfoByServerName(String serverName){
		StndServer  result = null;
		try {
			Query query = ldaEntityManager.createQuery(
					QUERY_GET_SERVER, StndServer.class);
			query.setParameter("serverName", serverName);
			result = (StndServer) query.getSingleResult();
		} catch (Exception e) {
			log.error("getStndServerinfoByServerName: Exception caught - " + e);
		}
		return result;
	}
	
	
	public void persistStndServer(StndServer stndServer){
        try {
            ldaEntityManager.persist(stndServer);
        } catch (Exception e) {
        	log.error("persistStndServer: Exception caught - " + e);
        }
    }
}
