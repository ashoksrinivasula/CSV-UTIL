package gov.uspto.pe2e.lda.model.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.NoArgsConstructor;

/**
 * 
 * @author asrinivasula
 * 
 */

@Entity
@Table(name = "stnd_server")
@NoArgsConstructor
public class StndServer implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "STND_SERVER_ID")
    private Long id;
  
    @Column(name = "SERVER_CD")
    private String servercd;
  
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Timestamp beginEffectiveDate;
	
	@Column(name = "DESCRIPTION_TX")
    private String desc;

    @Column(name = "LOCATION_TX")
    private String locationTxt;

    @Column(name = "END_EFFECTIVE_DT")
    private Timestamp endEffectiveDate ;

    @Column(name = "LAST_MOD_USER_ID")
    private String lastModUserID = "0";
    
    @Column(name = "DELETE_IN")
    private Boolean softDeleted = false;
    
    @Column(name = "LOCK_CONTROL_NO")
    private Long lockCtrlNo;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the servercd
	 */
	public String getServercd() {
		return servercd;
	}

	/**
	 * @param servercd the servercd to set
	 */
	public void setServercd(String servercd) {
		this.servercd = servercd;
	}

	/**
	 * @return the beginEffectiveDate
	 */
	public Timestamp getBeginEffectiveDate() {
		return beginEffectiveDate;
	}

	/**
	 * @param beginEffectiveDate the beginEffectiveDate to set
	 */
	public void setBeginEffectiveDate(Timestamp beginEffectiveDate) {
		this.beginEffectiveDate = beginEffectiveDate;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * @return the locationTxt
	 */
	public String getLocationTxt() {
		return locationTxt;
	}

	/**
	 * @param locationTxt the locationTxt to set
	 */
	public void setLocationTxt(String locationTxt) {
		this.locationTxt = locationTxt;
	}

	/**
	 * @return the endEffectiveDate
	 */
	public Timestamp getEndEffectiveDate() {
		return endEffectiveDate;
	}

	/**
	 * @param endEffectiveDate the endEffectiveDate to set
	 */
	public void setEndEffectiveDate(Timestamp endEffectiveDate) {
		this.endEffectiveDate = endEffectiveDate;
	}

	/**
	 * @return the lastModUserID
	 */
	public String getLastModUserID() {
		return lastModUserID;
	}

	/**
	 * @param lastModUserID the lastModUserID to set
	 */
	public void setLastModUserID(String lastModUserID) {
		this.lastModUserID = lastModUserID;
	}

	/**
	 * @return the softDeleted
	 */
	public Boolean getSoftDeleted() {
		return softDeleted;
	}

	/**
	 * @param softDeleted the softDeleted to set
	 */
	public void setSoftDeleted(Boolean softDeleted) {
		this.softDeleted = softDeleted;
	}

	/**
	 * @return the lockCtrlNo
	 */
	public Long getLockCtrlNo() {
		return lockCtrlNo;
	}

	/**
	 * @param lockCtrlNo the lockCtrlNo to set
	 */
	public void setLockCtrlNo(Long lockCtrlNo) {
		this.lockCtrlNo = lockCtrlNo;
	}
    
}
