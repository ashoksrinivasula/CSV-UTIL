package gov.uspto.pe2e.intake.rest;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import lombok.Setter;

@Component
public class PatiRestClient {

    
    @Setter
    @Value("${pati.toc.url}")
    private String patiURL;
    

    public String getPATIUrls(String applicationId) throws Exception {
        String url = patiURL + applicationId;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<byte[]> response = restTemplate.exchange(url, HttpMethod.GET, entity, byte[].class);
        String str = "";
        if (response.getStatusCode() == HttpStatus.OK) {
            str = new String(response.getBody());
        }
        return str;
    }

    public byte[] getPatiDocStreamByUrl(String url) throws Exception {
    	byte[] bytes = null;
    	RestTemplate restTemplate = new RestTemplate();
    	HttpHeaders headers = new HttpHeaders();
    	headers.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
    	HttpEntity<String> entity = new HttpEntity<>(headers);
    	ResponseEntity<byte[]> response = restTemplate.exchange(url, HttpMethod.GET, entity, byte[].class);
    	if (response.getStatusCode() == HttpStatus.OK) {
    		bytes = response.getBody();
    	}
    	return bytes;
    }
    
    
    public byte[] getPatiSVGDocStreamByUrl(String url) throws Exception {
    	byte[] bytes = null;
    	RestTemplate restTemplate = new RestTemplate();
    	HttpHeaders headers = new HttpHeaders();
    	headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
    	HttpEntity<String> entity = new HttpEntity<>(headers);
    	ResponseEntity<byte[]> response = restTemplate.exchange(url, HttpMethod.GET, entity, byte[].class);
    	if (response.getStatusCode() == HttpStatus.OK) {
    		bytes = response.getBody();
    	}
    	return bytes;
    }


  


}
