package gov.uspto.pe2e.lda.model.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.NoArgsConstructor;

/**
 * 
 * @author asrinivasula
 * 
 */

@Entity
@Table(name = "staas_migration_payload")
@NoArgsConstructor
public class StaasMigrationPayload implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "staas_migration_payload_id")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_STND_SERVER_ID")
	private StndServer srndSrever;

	@Column(name = "start_doc_resource_id")
	private Long startDocResourceId;

	@Column(name = "end_doc_resource_id")
	private Long endDocResourceId;

	@Column(name = "retry_actual_no")
	private Integer retryActualNo;

	@Column(name = "CREATE_USER_ID")
	private String createUserID = "0";

	@Column(name = "LAST_MOD_USER_ID")
	private String lastModUserID = "0";

	@Column(name = "CREATE_TS")
	private Timestamp createTs;

	@Column(name = "LAST_MOD_TS")
	private Timestamp lastModTs = new Timestamp(System.currentTimeMillis());

	@Column(name = "DELETE_IN")
	private Boolean softDeleted = false;

	@Column(name = "LOCK_CONTROL_NO")
	private Long lockCtrlNo;

	@Column(name = "start_ts")
	private Timestamp startTs;

	@Column(name = "end_ts")
	private Timestamp endTs;

	@Column(name = "count")
	private Long count;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the startDocResourceId
	 */
	public Long getStartDocResourceId() {
		return startDocResourceId;
	}

	/**
	 * @param startDocResourceId the startDocResourceId to set
	 */
	public void setStartDocResourceId(Long startDocResourceId) {
		this.startDocResourceId = startDocResourceId;
	}

	/**
	 * @return the endDocResourceId
	 */
	public Long getEndDocResourceId() {
		return endDocResourceId;
	}

	/**
	 * @param endDocResourceId the endDocResourceId to set
	 */
	public void setEndDocResourceId(Long endDocResourceId) {
		this.endDocResourceId = endDocResourceId;
	}

	/**
	 * @return the retryActualNo
	 */
	public Integer getRetryActualNo() {
		return retryActualNo;
	}

	/**
	 * @param retryActualNo the retryActualNo to set
	 */
	public void setRetryActualNo(Integer retryActualNo) {
		this.retryActualNo = retryActualNo;
	}

	/**
	 * @return the createUserID
	 */
	public String getCreateUserID() {
		return createUserID;
	}

	/**
	 * @param createUserID the createUserID to set
	 */
	public void setCreateUserID(String createUserID) {
		this.createUserID = createUserID;
	}

	/**
	 * @return the lastModUserID
	 */
	public String getLastModUserID() {
		return lastModUserID;
	}

	/**
	 * @param lastModUserID the lastModUserID to set
	 */
	public void setLastModUserID(String lastModUserID) {
		this.lastModUserID = lastModUserID;
	}

	/**
	 * @return the createTs
	 */
	public Timestamp getCreateTs() {
		return createTs;
	}

	/**
	 * @param createTs the createTs to set
	 */
	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	/**
	 * @return the lastModTs
	 */
	public Timestamp getLastModTs() {
		return lastModTs;
	}

	/**
	 * @param lastModTs the lastModTs to set
	 */
	public void setLastModTs(Timestamp lastModTs) {
		this.lastModTs = lastModTs;
	}

	/**
	 * @return the softDeleted
	 */
	public Boolean getSoftDeleted() {
		return softDeleted;
	}

	/**
	 * @param softDeleted the softDeleted to set
	 */
	public void setSoftDeleted(Boolean softDeleted) {
		this.softDeleted = softDeleted;
	}

	/**
	 * @return the startTs
	 */
	public Timestamp getStartTs() {
		return startTs;
	}

	/**
	 * @param startTs the startTs to set
	 */
	public void setStartTs(Timestamp startTs) {
		this.startTs = startTs;
	}

	/**
	 * @return the endTs
	 */
	public Timestamp getEndTs() {
		return endTs;
	}

	/**
	 * @param endTs the endTs to set
	 */
	public void setEndTs(Timestamp endTs) {
		this.endTs = endTs;
	}

	/**
	 * @return the lockCtrlNo
	 */
	public Long getLockCtrlNo() {
		return lockCtrlNo;
	}

	/**
	 * @param lockCtrlNo the lockCtrlNo to set
	 */
	public void setLockCtrlNo(Long lockCtrlNo) {
		this.lockCtrlNo = lockCtrlNo;
	}

	/**
	 * @return the srndSrever
	 */
	public StndServer getSrndSrever() {
		return srndSrever;
	}

	/**
	 * @param srndSrever the srndSrever to set
	 */
	public void setSrndSrever(StndServer srndSrever) {
		this.srndSrever = srndSrever;
	}

	/**
	 * @return the count
	 */
	public Long getCount() {
		return count;
	}

	/**
	 * @param count the count to set
	 */
	public void setCount(Long count) {
		this.count = count;
	}
}
