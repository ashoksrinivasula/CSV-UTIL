package gov.uspto.pe2e.lda.model.entity;

import lombok.ToString;

/**
 * 
 * @author asrinivasula
 * 
 */

@ToString
public class DocumentResourcePatiResultset {

	private String applicationId;
	
	private Long documentId;
	
	private Long docResourceId;
	
	private String sourceSystemsKey;	
	
	private String patiUrl;
	
	private Long docResourceStorageForeignKey;

	/**
	 * @return the documentId
	 */
	public Long getDocumentId() {
		return documentId;
	}

	/**
	 * @param documentId the documentId to set
	 */
	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}

	/**
	 * @return the docResourceId
	 */
	public Long getDocResourceId() {
		return docResourceId;
	}

	/**
	 * @param docResourceId the docResourceId to set
	 */
	public void setDocResourceId(Long docResourceId) {
		this.docResourceId = docResourceId;
	}

	/**
	 * @return the sourceSystemsKey
	 */
	public String getSourceSystemsKey() {
		return sourceSystemsKey;
	}

	/**
	 * @param sourceSystemsKey the sourceSystemsKey to set
	 */
	public void setSourceSystemsKey(String sourceSystemsKey) {
		this.sourceSystemsKey = sourceSystemsKey;
	}

	/**
	 * @return the patiUrl
	 */
	public String getPatiUrl() {
		return patiUrl;
	}

	/**
	 * @param patiUrl the patiUrl to set
	 */
	public void setPatiUrl(String patiUrl) {
		this.patiUrl = patiUrl;
	}

	/**
	 * @return the applicationId
	 */
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	
	/**
	 * @return the docResourceStorageForeignKey
	 */
	public Long getDocResourceStorageForeignKey() {
		return docResourceStorageForeignKey;
	}
	
	/**
	 * @param docResourceStorageForeignKey the docResourceStorageForeignKey to set
	 */
	public void setDocResourceStorageForeignKey(Long docResourceStorageForeignKey) {
		this.docResourceStorageForeignKey = docResourceStorageForeignKey;
	}

	
}
