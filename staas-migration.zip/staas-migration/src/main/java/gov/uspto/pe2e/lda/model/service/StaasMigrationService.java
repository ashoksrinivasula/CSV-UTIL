package gov.uspto.pe2e.lda.model.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.xml.sax.InputSource;

import com.fasterxml.jackson.core.JsonProcessingException;

import gov.uspto.pe2e.intake.dao.DocumentResourceDao;
import gov.uspto.pe2e.intake.dao.StaasMigrationPayloadJDBCTemplateDao;
import gov.uspto.pe2e.intake.rest.PatiRestClient;
import gov.uspto.pe2e.intake.rest.StaasRestClient;
import gov.uspto.pe2e.intake.util.StaasMigrationConstants;
import gov.uspto.pe2e.lda.model.entity.DocumentResourcePatiResultset;
import gov.uspto.pe2e.lda.model.entity.DocumentResourceResultset;
import gov.uspto.pe2e.lda.model.entity.StaasReprocessPayloadResultSet;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class StaasMigrationService {

	@Autowired
	private DocumentResourceDao dcumentResourceDao;

	@Autowired
	private StaasRestClient staasRestClient;
	
	@Autowired
	private PatiRestClient patiRestClient;

	@Autowired
	private StaasMigrationPayloadJDBCTemplateDao staasMigrationPayloadJDBCTemplateDao;

	@Setter
	@Value("${staas.score.nameSpace}")
	private String staasScoreNameSpace;

	@Setter
	@Value("${staas.ifw.nameSpace}")
	private String staasIfwNameSpace;

	@Setter
	@Value("${staas.pati.nameSpace}")
	private String staasPatiNameSpace;
	
	@Setter
    @Value("${lda.final.data.dir}")
    private String basePath;
    
	
	public void processMigration(Long documentResourceId) {	
		if(documentResourceId!=null){
			try {
				processMigration(validDocumentResourcestoProcess(documentResourceId));
			} catch (Exception e) {		            
				log.error("Exception in processMigration - " + e.getMessage());
			}
		}
	}

	public void processMigration(DocumentResourceResultset documentResource)  {	
		if (documentResource != null && documentResource.getDocResourceId() != null
				&& documentResource.getFilePath() != null) {
			String fileId = null;
			Long docResourceId = documentResource.getDocResourceId();
			try {
				if (documentResource.getSourceSystemId().equals(StaasMigrationConstants.LONG_TWO)) {
					if (documentResource.getDocumentCodeId().equals(StaasMigrationConstants.SEQLISTING_DOC_CODE)) {
						fileId = staasRestClient.postFile(documentResource.getFilePath() + StaasMigrationConstants.SLASH
								+ documentResource.getFileName(), staasScoreNameSpace);
						saveDocumentResourceStorage(docResourceId, fileId, staasScoreNameSpace);
					} else {
						fileId = staasRestClient.postFile(documentResource.getFilePath(), staasScoreNameSpace);
						saveDocumentResourceStorage(docResourceId, fileId, staasScoreNameSpace);
					}
				} else {
					fileId = ifwFileUpload(documentResource.getFilePath(),System.nanoTime());
					saveDocumentResourceStorage(docResourceId, fileId, staasIfwNameSpace);
				}
			} catch (FileNotFoundException | NoSuchFileException e) {
				staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId,"FILE NOT FOUND IN CW",null,StaasMigrationConstants.LONG_ONE);				
				log.error("FileNotFoundException in processing docResourceId" + docResourceId, e.getMessage());
			} catch (ResourceAccessException e) {	
				staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId,"FILE NOT FOUND IN CW",null,StaasMigrationConstants.LONG_ONE);				
				log.error("ResourceAccessException in processing docResourceId" + docResourceId, e.getMessage());
			} catch (HttpServerErrorException e) {
				staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId,e.getMessage(),null,StaasMigrationConstants.LONG_TWO);
				log.error("HttpServerErrorException in processing docResourceId" + docResourceId, e.getMessage());
			} catch (RestClientException e) {
				staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId, e.getMessage(),null,StaasMigrationConstants.LONG_TWO);
				log.error("RestClientException in processing docResourceId" + docResourceId, e.getMessage());
			} catch (Exception e) {
				staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId, e.getMessage(),null,StaasMigrationConstants.LONG_THREE);
				log.error("Exception in processing docResourceId" + docResourceId, e.getMessage());
			}
		}
	}
	
	public void reprocessMigration(StaasReprocessPayloadResultSet staasReprocessPayload)  {	
		try{
			Timestamp startTime = new Timestamp(System.currentTimeMillis());
			if (staasReprocessPayload != null && staasReprocessPayload.getDocResourceId() != null 
					&& staasReprocessPayload.getId()!=null) {
				staasMigrationPayloadJDBCTemplateDao.updateStaasReProcessPayloadLock(staasReprocessPayload.getId(),
						StaasMigrationConstants.LONG_ONE, startTime);
				
					if(staasReprocessPayload.getFileId()!=null){
						saveDocumentResourceStorage(staasReprocessPayload.getDocResourceId(), staasReprocessPayload.getFileId(),null);
					}else {
						reprocessMigration(validDocumentResourcestoProcess(staasReprocessPayload.getDocResourceId()));
					}
					Timestamp endTime = new Timestamp(System.currentTimeMillis());
					staasMigrationPayloadJDBCTemplateDao.updateStaasReProcessPayloadDeletein(staasReprocessPayload.getId(),endTime);	
			}
		} catch (Exception e) {
			staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(staasReprocessPayload.getDocResourceId(),e.getMessage(),null,StaasMigrationConstants.LONG_FOUR);				
			log.error("Exception in reprocessMigration for docResourceId" + staasReprocessPayload.getDocResourceId(), e.getMessage());
		}
	}
	
	public void reprocessMigration(DocumentResourceResultset documentResource)  {	
		if (documentResource != null && documentResource.getDocResourceId() != null && documentResource.getFilePath() != null ) {
			String fileId = null;
			Long docResourceId = documentResource.getDocResourceId();
			try {
				if (documentResource.getSourceSystemId().equals(StaasMigrationConstants.LONG_TWO)) {
					if (documentResource.getDocumentCodeId().equals(StaasMigrationConstants.SEQLISTING_DOC_CODE)) {
						fileId = staasRestClient.postFile(documentResource.getFilePath() + StaasMigrationConstants.SLASH
								+ documentResource.getFileName(), staasScoreNameSpace);
						saveDocumentResourceStorage(docResourceId, fileId, staasScoreNameSpace);
					} else {
						fileId = staasRestClient.postFile(documentResource.getFilePath(), staasScoreNameSpace);
						saveDocumentResourceStorage(docResourceId, fileId, staasScoreNameSpace);
					}
				} else {
					fileId = ifwFileUpload(documentResource.getFilePath(),System.nanoTime());
					saveDocumentResourceStorage(docResourceId, fileId, staasIfwNameSpace);
				}
			} catch (FileNotFoundException | NoSuchFileException e) {
				staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId,"FILE NOT FOUND IN CW",null,StaasMigrationConstants.LONG_ONE);				
				log.error("FileNotFoundException in processing docResourceId" + docResourceId, e.getMessage());
			} catch (ResourceAccessException e) {	
				staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId,"FILE NOT FOUND IN CW",null,StaasMigrationConstants.LONG_ONE);				
				log.error("ResourceAccessException in processing docResourceId" + docResourceId, e.getMessage());
			} catch (HttpServerErrorException e) {
				staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId, e.getMessage(),null,StaasMigrationConstants.LONG_TWO);
				log.error("HttpServerErrorException in processing docResourceId" + docResourceId, e.getMessage());
			} catch (RestClientException e) {
				staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId, e.getMessage(),null,StaasMigrationConstants.LONG_TWO);
				log.error("RestClientException in processing docResourceId" + docResourceId, e.getMessage());
			} catch (Exception e) {
				staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId, e.getMessage(),null,StaasMigrationConstants.LONG_THREE);
				log.error("Exception in processing docResourceId" + docResourceId, e.getMessage());
			}
		}
	}
	
	private String ifwFileUpload(String filePath, long startTime) throws JsonProcessingException, IOException  {
		String fileId=null;
		Path path = Paths.get(basePath+ StaasMigrationConstants.SLASH +filePath);					
		byte[] fileInBytes = java.nio.file.Files.readAllBytes(path);	
		long estimatedTime = System.nanoTime() - startTime;					  
		log.info(" Time Taken in MILLISECONDS " +
				TimeUnit.MILLISECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS)+ 
				" to crate byteArry for File " +filePath);
		Long stTime = System.nanoTime();	        
		fileId = staasRestClient.postDocument(fileInBytes, staasIfwNameSpace);			
		estimatedTime = System.nanoTime() - stTime;					  
		log.info(" Time Taken in MILLISECONDS " +
				TimeUnit.MILLISECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS)+ 
				" for upload byteArry to STAAS for File " +filePath);
		return fileId;
	}

	private void saveDocumentResourceStorage(Long docResourceId, String fileId, String nameSpace) {
		try{
		if (fileId != null) {
			String[] fileStringArray = fileId.split(StaasMigrationConstants.SLASH, StaasMigrationConstants.TWO);
			if (fileStringArray.length > StaasMigrationConstants.ONE) {
				dcumentResourceDao.saveDocumentResourceStorage(docResourceId,
						fileStringArray[StaasMigrationConstants.ONE], fileStringArray[StaasMigrationConstants.ZERO]);
			} else if (nameSpace != null){
				dcumentResourceDao.saveDocumentResourceStorage(docResourceId, fileId, nameSpace);
			}

		} else {
			log.error("Exception in STAAS Upload. File_Id return as Null for docResourceId " + docResourceId);
			staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId, "STAAS FILEID NULL",null,StaasMigrationConstants.LONG_FIVE);
		}
		}catch(Exception e){
			log.error("Exception saveDocumentResourceStorage for FileId = " + fileId + " and docResourceId = "+docResourceId);
			staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId, e.getMessage(),fileId,StaasMigrationConstants.LONG_SIX);
		}
	}

	public DocumentResourceResultset validDocumentResourcestoProcess(Long docResourceId) {
		try {
			DocumentResourceResultset documentResource = dcumentResourceDao.getDocReourceById(docResourceId);
			if (documentResource != null && documentResource.getDocRenditionTypeId() != null
					&& documentResource.getFilePath() != null) {
				if (!documentResource.getSourceSystemId().equals(StaasMigrationConstants.LONG_TWO)
						&& documentResource.getDocRenditionTypeId().equals(StaasMigrationConstants.LONG_SIX)) {
					log.warn("This is PATI docResourceId # " + docResourceId);
					return null;

				} else {
					return documentResource;
				}
			} else {
				log.warn("Can't find docResource record for docResourceId # " + docResourceId);
				return null;
			}
		} catch (Exception e) {
			staasMigrationPayloadJDBCTemplateDao.persistStaasReprocessPayload(docResourceId, e.getMessage(),null,StaasMigrationConstants.LONG_SEVEN);
			log.error("Exception in validDocumentResourcestoProcess for docResourceId" + docResourceId, e);
			return null;
		}
	}

	
	public boolean isMigrationHealthCheck() throws Exception{
		boolean result = false;
		if(staasRestClient.isStaasHealthCheck() && dcumentResourceDao.pe2eDatabaseCheck()
				&& staasMigrationPayloadJDBCTemplateDao.ldaDatabaseCheck()){
			result = true;
		}
		return result;
	}
	
	/* Pati migration methods */
	public List<DocumentResourcePatiResultset> getPatiDocumentSourceSystemKeys(String appId) {
		log.info("Start of getPatiDocumentSourceSystemKeys for appId # " + appId);
		List<DocumentResourcePatiResultset> lstResult = null;
		try {

			lstResult = dcumentResourceDao.getPatiDocumentSourceSystemKeys(appId);
		} catch (Exception e) {
			log.error("Exception in getPatiDocumentSourceSystemKeys for appId" + appId);
			log.debug("StackTrace = "+ e);
		}
		return lstResult;
	}

	public List<DocumentResourcePatiResultset> getPATIUrlsforDocId(
			List<DocumentResourcePatiResultset> docResPatiResultsetList, String applicationId) {
		List<DocumentResourcePatiResultset> resultSet = new ArrayList<>();
		String xmlString = null;
		String sourceSystemsKey = null;
		try {
			xmlString = patiRestClient.getPATIUrls(applicationId);
			XPathFactory xpathFactory = XPathFactory.newInstance();
			XPath xpath = xpathFactory.newXPath();
			for (DocumentResourcePatiResultset documentResourcePatiResultset : docResPatiResultsetList) {
				if (documentResourcePatiResultset.getSourceSystemsKey() != null) {
					sourceSystemsKey = documentResourcePatiResultset.getSourceSystemsKey();
					String documentURI = null;
					documentURI = xpath.evaluate(
							StaasMigrationConstants.DOCUMENT_URI_DOCUMENT_KEY_ID + sourceSystemsKey
									+ StaasMigrationConstants.STRING_BRACKETS,
							new InputSource(new StringReader(xmlString)));
					documentResourcePatiResultset.setPatiUrl(documentURI);
				}
				String patiUrl = documentResourcePatiResultset.getPatiUrl();
				if (patiUrl != null && StringUtils.isNotBlank(patiUrl)){
					resultSet.add(documentResourcePatiResultset);
				}
			}
		} catch (XPathExpressionException e) {
			log.error("XPathExpressionException in getPATIUrlsforDocId with SourceSystemsKey" + sourceSystemsKey, e);
		} catch (Exception e) {
			log.error("Exception in StaasRestClient.getPATIUrls for Application Id " + applicationId, e);
		}
		return resultSet;
	}

	public void processMigrationPati(DocumentResourcePatiResultset documentResource) {
		log.info("start of processPatiMigration");
		String fileId = null;
		String fileIdSVG = null;
		byte[] patiSVGFileStream = null;

		try {

			//Migrate Pati Xml files
			final Long docResourceId = documentResource.getDocResourceId();
			String strUrl = documentResource.getPatiUrl();
			byte[] patiDocStream = patiRestClient.getPatiDocStreamByUrl(strUrl);
			fileId = staasRestClient.postDocument(patiDocStream, staasPatiNameSpace);
			saveDocumentResourceStorage(docResourceId, fileId, staasPatiNameSpace);

			log.info("PATI XML file Successfully uploaded for docResourceId : "+docResourceId +" FileID : "+fileId );

			// Migrate SVG document if exists for the Pati XML; if not, just continue;
			String strSVGUrl = strUrl.replaceAll(".xml", "_svg.zip");
			// Get the byte stream and Upload the SVG file
			if (IsRemoteFileExists(strSVGUrl)) {
				patiSVGFileStream = patiRestClient.getPatiSVGDocStreamByUrl(strSVGUrl);
				final long svgFileSize = patiSVGFileStream.length;
				fileIdSVG = staasRestClient.postDocument(patiSVGFileStream, staasPatiNameSpace);
				// create the rendition relation for SVG
				dcumentResourceDao.createDocumentSVG(documentResource, fileIdSVG, staasPatiNameSpace,
						svgFileSize);
				log.info("SVG files Successfully uploaded for DocResourceId: "+docResourceId + " File Id :"+fileIdSVG);
			}

		} catch (FileNotFoundException e) {
			log.error("FileNotFoundException in processing ApplicaitonId:"+documentResource.getApplicationId() +"  docResourceId: " + documentResource.getDocResourceId(), e);
			staasMigrationPayloadJDBCTemplateDao.updatePatiPayloadFailOverFlag(documentResource.getApplicationId());
		} catch (ResourceAccessException e) {
			log.error("ResourceAccessException in processing ApplicaitonId:"+documentResource.getApplicationId() +"  docResourceId: " + documentResource.getDocResourceId(), e);
			staasMigrationPayloadJDBCTemplateDao.updatePatiPayloadFailOverFlag(documentResource.getApplicationId());
		} catch (HttpServerErrorException e) {
			log.error("HttpServerErrorException in processing ApplicaitonId:"+documentResource.getApplicationId() +"  docResourceId: " + documentResource.getDocResourceId(), e);
			staasMigrationPayloadJDBCTemplateDao.updatePatiPayloadFailOverFlag(documentResource.getApplicationId());

		} catch (RestClientException e) {
			log.error("RestClientException in processing ApplicaitonId:"+documentResource.getApplicationId() +"  docResourceId: " + documentResource.getDocResourceId(), e);
			staasMigrationPayloadJDBCTemplateDao.updatePatiPayloadFailOverFlag(documentResource.getApplicationId());

		}  catch (DuplicateKeyException e) {
			log.error("DuplicateKeyException in processing ApplicaitonId:"+documentResource.getApplicationId() +"  docResourceId: " + documentResource.getDocResourceId(), e);
			staasMigrationPayloadJDBCTemplateDao.updatePatiPayloadFailOverFlag(documentResource.getApplicationId());
		}
		catch (Exception e) {
			log.error("Exception in processing ApplicaitonId:"+documentResource.getApplicationId() +"  docResourceId: " + documentResource.getDocResourceId(), e);
			staasMigrationPayloadJDBCTemplateDao.updatePatiPayloadFailOverFlag(documentResource.getApplicationId());
		}

	}
	
	public  boolean IsRemoteFileExists(String strFileURLName){
	    try {
	      HttpURLConnection.setFollowRedirects(false);
	      HttpURLConnection con = (HttpURLConnection) new URL(strFileURLName).openConnection();
	      con.setRequestMethod("HEAD");
	      return (con.getResponseCode() == HttpURLConnection.HTTP_OK);
	    }
	    catch (Exception e) {
	       e.printStackTrace();
	       return false;
	    }
	  }  

	/* End of Pati migration methods */

}
