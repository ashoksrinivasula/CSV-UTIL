package gov.uspto.pe2e.lda.model.service;

import gov.uspto.pe2e.intake.dao.DocumentResourceDao;
import gov.uspto.pe2e.intake.dao.StaasMigrationPayloadJDBCTemplateDao;
import gov.uspto.pe2e.intake.util.StaasMigrationConstants;
import gov.uspto.pe2e.lda.model.entity.DocumentResourcePatiResultset;
import gov.uspto.pe2e.lda.model.entity.DocumentResourceResultset;
import gov.uspto.pe2e.lda.model.entity.StaasMigrationPayloadResultSet;
import gov.uspto.pe2e.lda.model.entity.StaasReprocessPayloadResultSet;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Header;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class StaasMigrationPayloadService {

    @Setter
    @Getter
    @Value("${legacy.process.data.dir}")
    private String legacyProcessPath;

    @Autowired
    private StaasMigrationPayloadJDBCTemplateDao staasMigrationPayloadJDBCTemplateDao;

    @Autowired
    private StaasMigrationService staasMigrationService;

    private String hostName;
    private Long serverId;

    @Autowired
    private DocumentResourceDao dcumentResourceDao;

    @PostConstruct
    void init() throws UnknownHostException {
        InetAddress addr = InetAddress.getLocalHost();
        hostName = addr.getHostName();
        serverId = staasMigrationPayloadJDBCTemplateDao.getStndServerIdbyName(hostName);
    }

    public List<DocumentResourceResultset> getdocResourceIdsToProcess(Exchange exchange) {
        Timestamp startTime = new Timestamp(System.currentTimeMillis());
        log.info("Start of getdocResourceIdsToProcess " + startTime);
        List<DocumentResourceResultset> result = null;
        StaasMigrationPayloadResultSet staasMigrationPayload = null;
        try {
            if (staasMigrationService.isMigrationHealthCheck()) {
                staasMigrationPayload = staasMigrationPayloadJDBCTemplateDao.getStaasMigrationPayload(hostName);
                if (staasMigrationPayload != null && staasMigrationPayload.getStartDocResourceId() != null
                        && staasMigrationPayload.getEndDocResourceId() != null) {

                    staasMigrationPayloadJDBCTemplateDao.updateStaasMigrationPayloadLock(staasMigrationPayload.getId(),
                            StaasMigrationConstants.LONG_ONE, startTime);

                    Long tempDocResourceId = staasMigrationPayload.getStartDocResourceId();
                    result = new ArrayList<>();
                    do {
                        DocumentResourceResultset documentResourceResultset = staasMigrationService
                                .validDocumentResourcestoProcess(tempDocResourceId);
                        if (documentResourceResultset != null) {
                            result.add(documentResourceResultset);
                        }
                        tempDocResourceId = tempDocResourceId + 1;
                    } while (tempDocResourceId <= staasMigrationPayload.getEndDocResourceId());

                    staasMigrationPayloadJDBCTemplateDao.updateStaasMigrationPayloadCount(staasMigrationPayload.getId(),
                            Long.valueOf(result.size()));
                    exchange.getIn().setHeader(StaasMigrationConstants.PAYLOAD_ID, staasMigrationPayload.getId());
                } else {
                    log.warn("Migration Pay load Empty for Host Name " + hostName);
                    Thread.sleep(StaasMigrationConstants.SLEEP_INTERVAL);
                }
                healthCheck();
            } else {
                log.error("Migration Process Stopped due to STAAS Service Down");
                Thread.sleep(StaasMigrationConstants.SLEEP_INTERVAL);
            }
        } catch (Exception e) {
            if (staasMigrationPayload != null) {
                insertdocResourceIdsToProcess(staasMigrationPayload.getStartDocResourceId(),
                        staasMigrationPayload.getEndDocResourceId());
            }
            log.error("Exception in getdocResourceIdsToProcess - " + e.getMessage());
        }
        return result;
    }

    public List<Long> getStaasPayloadToProcess(Exchange exchange) {
        Timestamp startTime = new Timestamp(System.currentTimeMillis());
        log.info("Start of getStaasPayloadToProcess " + startTime);
        List<Long> docresourceIdList = null;
        try {
            if (staasMigrationService.isMigrationHealthCheck()) {
                InetAddress addr = InetAddress.getLocalHost();
                StaasMigrationPayloadResultSet staasMigrationPayload = staasMigrationPayloadJDBCTemplateDao
                        .getStaasMigrationPayload(addr.getHostName());
                if (staasMigrationPayload != null && staasMigrationPayload.getStartDocResourceId() != null
                        && staasMigrationPayload.getEndDocResourceId() != null) {
                    staasMigrationPayloadJDBCTemplateDao.updateStaasMigrationPayloadLock(staasMigrationPayload.getId(),
                            StaasMigrationConstants.LONG_ONE, startTime);
                    docresourceIdList = dcumentResourceDao.validateDocReourceIds(staasMigrationPayload.getStartDocResourceId(),
                            staasMigrationPayload.getEndDocResourceId());
                    exchange.getIn().setHeader(StaasMigrationConstants.PAYLOAD_ID, staasMigrationPayload.getId());
                } else {
                    log.warn("Migration Pay load Empty for Host Name " + addr.getHostName());
                    Thread.sleep(StaasMigrationConstants.SLEEP_INTERVAL);
                }
                healthCheck();
            } else {
                log.error("Migration Process Stopped due to HealthCheck Failure");
                Thread.sleep(StaasMigrationConstants.SLEEP_INTERVAL);
            }
        } catch (Exception e) {
            log.error("Exception in getStaasPayloadToProcess - " + e.getMessage());
        }
        return docresourceIdList;
    }

    public List<StaasReprocessPayloadResultSet> getdocResourceIdsToReProcess(Exchange exchange) {
        List<StaasReprocessPayloadResultSet> staasReprocessPayloadResultSetList = null;
        try {
            if (staasMigrationService.isMigrationHealthCheck()) {
                staasReprocessPayloadResultSetList = staasMigrationPayloadJDBCTemplateDao.getStaasReProcessPayload(serverId);
                if (staasReprocessPayloadResultSetList == null || staasReprocessPayloadResultSetList.isEmpty()) {
                    log.warn("Reprocess Pay load Empty for Host Name " + hostName);
                    Thread.sleep(StaasMigrationConstants.SLEEP_INTERVAL);
                }
            } else {
                log.error("Reprocess Process Stopped due to HealthCheck Failure");
                Thread.sleep(StaasMigrationConstants.SLEEP_INTERVAL);
            }
        } catch (Exception e) {
            log.error("Exception in getdocResourceIdsToReProcess - " + e);
        }
        return staasReprocessPayloadResultSetList;
    }

    public void updateReProcessEnd(List<StaasReprocessPayloadResultSet> result) {
        if (result != null) {
            log.info("End of the ReProcessRoute");
        } else {
            log.info("End of the ReProcessRoute Payload Empty");
        }
    }

    /* Begin Pati Migration methods */
    public List<StaasMigrationPayloadResultSet> preProcessBulkPatiMigrationPayLoad(Exchange exchange) {
        log.info("<--Start of processPatiMigration-->");
        List<StaasMigrationPayloadResultSet> lstBulkStaasPatiMigrationPayload = null;
        try {
            if (staasMigrationService.isMigrationHealthCheck()) {
                InetAddress addr = InetAddress.getLocalHost();
                lstBulkStaasPatiMigrationPayload = staasMigrationPayloadJDBCTemplateDao
                        .getBulkPaatiPayloadAppIdsByServer(addr.getHostName());

                if (lstBulkStaasPatiMigrationPayload == null || lstBulkStaasPatiMigrationPayload.size() == 0) {
                    log.warn("Migration of PATI Bulk Pay load Empty for Host Name " + addr.getHostName());
                    Thread.sleep(StaasMigrationConstants.SLEEP_INTERVAL);
                }
                healthCheck();

            } else {
                log.warn("StaasRest Client is not avaiabale. Thread is set to sleep");
                Thread.sleep(StaasMigrationConstants.SLEEP_INTERVAL);
            }
            healthCheck();
        } catch (Exception e) {
            log.error("preProcessBulkPatiMigrationPayLoad Method:  Exception in processPatiMigration - " + e);
        }
        return lstBulkStaasPatiMigrationPayload;
    }

    public List<DocumentResourcePatiResultset> preProcessPatiMigrationPayLoad(
            StaasMigrationPayloadResultSet staasPatiMigrationPayload) {
        log.info("<--Start of processPatiMigration-->");
        Timestamp startTime = new Timestamp(System.currentTimeMillis());
        List<DocumentResourcePatiResultset> lstDocumentResourcePatiResultset = null;
        try {
            if (staasPatiMigrationPayload != null && staasPatiMigrationPayload.getApplicationId() != null) {

                staasMigrationPayloadJDBCTemplateDao.updateStaasOneTimeMigrationPayloadLock(staasPatiMigrationPayload.getId(),
                        StaasMigrationConstants.LONG_ONE, startTime);

                List<DocumentResourcePatiResultset> lstDocResourcePatiResultset = staasMigrationService
                        .getPatiDocumentSourceSystemKeys(staasPatiMigrationPayload.getApplicationId());

                if (lstDocResourcePatiResultset != null && !lstDocResourcePatiResultset.isEmpty()) {

                    lstDocumentResourcePatiResultset = staasMigrationService.getPATIUrlsforDocId(lstDocResourcePatiResultset,
                            staasPatiMigrationPayload.getApplicationId());

                    // update migration count
                    staasMigrationPayloadJDBCTemplateDao.updatePatiStaasMigrationCount(staasPatiMigrationPayload.getId(),
                            Long.valueOf(lstDocumentResourcePatiResultset.size()));

                } else {
                    staasMigrationPayloadJDBCTemplateDao
                            .updateNullPayloadCountPatiStaasMigration(staasPatiMigrationPayload.getId(), startTime);
                    log.info("The Applicaiton Id : " + staasPatiMigrationPayload.getApplicationId()
                            + "does not have any PatiDocumnets to upload");
                }
            }
        } catch (Exception e) {
            log.error("Exception in processPatiMigration - " + e);
        }
        return lstDocumentResourcePatiResultset;

    }

    public void updatePatiProcessEnd(List<StaasMigrationPayloadResultSet> result) {
        if (result != null && !result.isEmpty()) {
            staasMigrationPayloadJDBCTemplateDao.updatePatiDeleteIndicator(result);
        } else {
            log.info("End of the Migration Route Payload Empty");
        }
    }

    /* End Pati Migration methods */

    public void updateProcessEnd(List<DocumentResourceResultset> result,
            @Header(StaasMigrationConstants.PAYLOAD_ID) Long recordId) {
        if (result != null) {
            Timestamp startTime = new Timestamp(System.currentTimeMillis());
            staasMigrationPayloadJDBCTemplateDao.updateStaasMigrationPayloadDeletein(recordId, startTime);
        } else {
            log.info("End of the Migration Route Payload Empty");
        }
    }

    public void updateStaasProcessEnd(List<Long> result,
            @Header(StaasMigrationConstants.PAYLOAD_ID) Long recordId) {
        Timestamp startTime = new Timestamp(System.currentTimeMillis());
        if (result != null) {
            staasMigrationPayloadJDBCTemplateDao.updateStaasMigrationPayloadDeletein(recordId, startTime);
        } else {
            log.info("End of the Migration Route Payload Empty");
        }
        log.info("End of updateStaasProcessEnd " + startTime);
    }

    public void insertdocResourceIdsToProcess(Long startDocResourceId, Long endDocResourceId) {
        try {
            staasMigrationPayloadJDBCTemplateDao.persistStaasMigrationPayload(startDocResourceId, endDocResourceId);
        } catch (Exception e) {
            log.error("Exception in processFiles method of MessagePersistenceLogReProcessService - "
                    + e.getMessage());
        }
    }

    public void healthCheck() {
        try {
            String hostName = InetAddress.getLocalHost().getHostName();
            String filePath = System.getProperty("logFileName");
            String processName = filePath.substring(filePath.lastIndexOf('/'));
            String directoryPath = legacyProcessPath + File.separator + hostName
                    + processName;

            log.info("Health Check directory path : " + directoryPath);
            File processFile = new File(directoryPath);

            FileUtils.touch(processFile);
        } catch (Exception e) {
            log.error("Error in creating a file  and cause is :" + e.getCause());
        }
    }

    /**
     * @return the hostName
     */
    public String getHostName() {
        return hostName;
    }

}
