package gov.uspto.pe2e.intake.util;

import java.sql.Timestamp;
import java.util.concurrent.TimeUnit;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;

/**
 * @author Ashok Srinivasula
 *
 * 
 */ 
public class ApplicationUtils {
    
    ApplicationUtils(){        
    }

    /**
     * Convert a millisecond duration to a string format
     * 
     * @param millis A duration to convert to a string form
     * @return A string of the form "X Days Y Hours Z Minutes A Seconds".
     */
    public static String getDurationBreakdown(long millis) {
        long localMillis = millis;
        if(millis < 0) {
          throw new IllegalArgumentException("Duration must be greater than zero!");
        }

        long days = TimeUnit.MILLISECONDS.toDays(localMillis);
        localMillis -= TimeUnit.DAYS.toMillis(days);
        long hours = TimeUnit.MILLISECONDS.toHours(localMillis);
        localMillis -= TimeUnit.HOURS.toMillis(hours);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(localMillis);
        localMillis -= TimeUnit.MINUTES.toMillis(minutes);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(localMillis);

        StringBuilder sb = new StringBuilder(StaasMigrationConstants.DURATION_CONSTANT);
        sb.append(days);
        sb.append(" Days ");
        sb.append(hours);
        sb.append(" Hours ");
        sb.append(minutes);
        sb.append(" Minutes ");
        sb.append(seconds);
        sb.append(" Seconds");

        return sb.toString();
    }
    
    
    public static java.sql.Timestamp getCurrentTimeStamp() {
        java.util.Date today = new java.util.Date();
        return new java.sql.Timestamp(today.getTime());
    }

    public static java.sql.Timestamp getUTCCurrentTimeStamp() {
        LocalDateTime localDate = new DateTime(DateTimeZone.UTC).toLocalDateTime();
        return new Timestamp(localDate.toDateTime().getMillis());
    }

}
