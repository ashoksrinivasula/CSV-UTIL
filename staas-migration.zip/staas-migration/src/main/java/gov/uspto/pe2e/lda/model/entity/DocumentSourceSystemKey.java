package gov.uspto.pe2e.lda.model.entity;

import java.io.Serializable;

import lombok.ToString;


@ToString
public class DocumentSourceSystemKey implements Serializable {
       
    private String dmskey;
    
    private Long docResourceId;

    public String getDmskey() {
        return dmskey;
    }

    public void setDmskey(String dmskey) {
        this.dmskey = dmskey;
    }

    public Long getDocResourceId() {
        return docResourceId;
    }

    public void setDocResourceId(Long docResourceId) {
        this.docResourceId = docResourceId;
    }

}
