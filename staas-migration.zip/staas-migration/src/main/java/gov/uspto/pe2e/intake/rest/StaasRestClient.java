package gov.uspto.pe2e.intake.rest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.PathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.intake.util.StaasMigrationConstants;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class StaasRestClient {

    @Setter
    @Value("${staas.url}")
    private String staasURL;

    @Setter
    @Value("${lda.final.data.dir}")
    private String basePath;
    
    

    
    public void getFileAndWriteToFS(String fileId, String filePath) throws Exception {
        String url = staasURL + fileId;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<byte[]> response = restTemplate.exchange(url, HttpMethod.GET, entity, byte[].class);
        if (response.getStatusCode() == HttpStatus.OK) {
            try {
                Files.write(Paths.get(filePath), response.getBody());
            } catch (IOException e) {
                log.error("Exception in getFileAndWriteToFS" + e);
            }
        }
    }

    public String postFile(String filePath, String nameSpace) throws HttpServerErrorException, 
							   ResourceAccessException, JsonProcessingException,IOException, RestClientException {
        String url = staasURL + nameSpace;
        String realPath = basePath + StaasMigrationConstants.SLASH + filePath;
        PathResource pathResource = new PathResource(realPath);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> result = null;        
        result = restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(pathResource), String.class);        
        ObjectMapper mapper = new ObjectMapper();
        JsonNode actualObj = mapper.readTree(result.getBody());
        return actualObj.get(StaasMigrationConstants.LOCATION).textValue();
    }

    public void deleteFile(String fileId) throws Exception {
        String url = staasURL + fileId;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.DELETE, entity, String.class);
        if (response.getStatusCode() == HttpStatus.NO_CONTENT) {
            log.info("File Deleted Sucessfully for the File ID:" + fileId);
        } else {
            log.info("File Deleted failed for the File ID:" + fileId);
        }
    }

    public boolean isStaasHealthCheck() throws Exception {
        RestTemplate restTemplate = new RestTemplate();
        try {
            ResponseEntity<String> response = restTemplate.getForEntity(staasURL, String.class);
            return response.getStatusCode() == HttpStatus.OK;
        } catch (Exception e) {
            return false;
        }
    }
    
    public String postDocument(byte[] bytes, String nameSpace) throws JsonProcessingException, IOException {
    	String url = staasURL + nameSpace;
    	RestTemplate restTemplate = new RestTemplate();
    	ResponseEntity<String> result = restTemplate.exchange(url, HttpMethod.POST,  new HttpEntity<>(bytes), String.class);
    	ObjectMapper mapper = new ObjectMapper();
    	JsonNode actualObj = mapper.readTree(result.getBody());
    	return actualObj.get(StaasMigrationConstants.LOCATION).textValue();
    }

}
