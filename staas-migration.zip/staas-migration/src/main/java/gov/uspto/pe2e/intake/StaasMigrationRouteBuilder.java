package gov.uspto.pe2e.intake;

import java.util.concurrent.ExecutorService;

import org.apache.camel.builder.ThreadPoolBuilder;
import org.apache.camel.spring.SpringRouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.uspto.pe2e.intake.util.StaasMigrationConstants;
import gov.uspto.pe2e.lda.model.service.StaasMigrationPayloadService;
import gov.uspto.pe2e.lda.model.service.StaasMigrationService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class StaasMigrationRouteBuilder extends SpringRouteBuilder {


    @Autowired
    private StaasMigrationPayloadService staasMigrationPayloadService;

    @Autowired
    private StaasMigrationService staasMigrationService;

    @Override
    public void configure() throws Exception {
    	
    	log.info("<--StaasMigrationRouteBuilder Start -->");
        ThreadPoolBuilder poolBuilder = new ThreadPoolBuilder(getContext());
        ExecutorService splitThreadPool = poolBuilder.poolSize(StaasMigrationConstants.SPLIT_THREAD_POOL_SIZE)
                .maxPoolSize(StaasMigrationConstants.SPLIT_THREAD_MAX_POOL_SIZE)
                .maxQueueSize(StaasMigrationConstants.SPLIT_THREAD_MAX_QUEUE_SIZE)
                .keepAliveTime(StaasMigrationConstants.SPLIT_THREAD_KEEP_ALIVE_TIME)
                .build("splitterPool");
        
        /* STAAS Migration */ 
        ExecutorService appIdExecutorService = poolBuilder.poolSize(StaasMigrationConstants.PATI_APPID_EXECUTOR_POOL_SIZE)
                .maxPoolSize(StaasMigrationConstants.PATI_APPID_EXECUTOR_POOL_MAX_SIZE)
                .maxQueueSize(StaasMigrationConstants.PATI_APPID_EXECUTOR_QUEUE_SIZE)
                .keepAliveTime(StaasMigrationConstants.SPLIT_THREAD_KEEP_ALIVE_TIME)
                .build("splitterPool");

        ExecutorService patiDocProcessExecutorService = poolBuilder.poolSize(StaasMigrationConstants.PATI_DOC_EXECUTOR_POOL_SIZE)
                .maxPoolSize(StaasMigrationConstants.PATI_DOC_EXECUTOR_POOL_MAX_SIZE)
                .maxQueueSize(StaasMigrationConstants.PATI_DOC_EXECUTOR_QUEUE_SIZE)
                .keepAliveTime(StaasMigrationConstants.SPLIT_THREAD_KEEP_ALIVE_TIME)
                .build("splitterPool");


        from("timer://startTrigger?fixedRate=true&repeatCount=0&period=-1s").routeId("timerRoute")
                .to("direct:start")
                .end();

        from("direct:start").routeId("startRoute")
                .log("HEADER->[ ${headers} ] BODY->[${body}]")
                .bean(staasMigrationPayloadService, "getStaasPayloadToProcess")
                .log("HEADER->[ ${headers} ]")

                .split(body()).executorService(splitThreadPool)
                .to("direct:uploadProcess")
                .end()
                .to("direct:end")
                .end();

        from("direct:uploadProcess").routeId("uploadRoute")
                .bean(staasMigrationService, "processMigration")
                .end();

        from("direct:end").routeId("endRoute")
                .bean(staasMigrationPayloadService, "updateStaasProcessEnd")
                .log("HEADER->[ ${headers} ]")
                .end();
        
        /* STAAS Reprocess */ 
        from("timer://startReprocessTrigger?fixedRate=true&repeatCount=0&period=-1s").routeId("reprocessTimerRoute")
                .to("direct:reprocess")
                .end();

        from("direct:reprocess").routeId("reprocessRoute")
        .log("HEADER->[ ${headers} ] BODY->[${body}]")
        .bean(staasMigrationPayloadService, "getdocResourceIdsToReProcess")
        .log("HEADER->[ ${headers} ]")        
       
        .split(body()).executorService(splitThreadPool)
        .to("direct:reProcessUpload")
        .end()
        .to("direct:reProcessend")
        .end();
        
        from("direct:reProcessUpload").routeId("reProcessUploadRoute")
        .bean(staasMigrationService, "reprocessMigration")
        .end();

         from("direct:reProcessend").routeId("reProcessendRoute")
        .bean(staasMigrationPayloadService, "updateReProcessEnd")
        .log("HEADER->[ ${headers} ]")
        .end();
        
       //PATI Migration routes
         from("timer://startPatiTrigger?fixedRate=true&repeatCount=0&period=-1s").routeId("timerRoutePati")
                 .to("direct:startPati")
                 .end();

         //Begin New pati optimization route defintion        
         from("direct:startPati").routeId("startRoutePati")
                 .log("HEADER->[ ${headers} ] BODY->[${body}]")
                 .bean(staasMigrationPayloadService, "preProcessBulkPatiMigrationPayLoad")
                 .log("HEADER->[ ${headers} ]")
                 .split(body()).executorService(appIdExecutorService)
                 .to("direct:processPatiIndividualApp")
                 .end()
                 .to("direct:endPati")
                 .end();

         from("direct:processPatiIndividualApp").routeId("routePatiIndividualApp")
                 .log("HEADER->[ ${headers} ] BODY->[${body}]")
                 .bean(staasMigrationPayloadService, "preProcessPatiMigrationPayLoad")
                 .log("HEADER->[ ${headers} ]")
                 .split(body()).executorService(patiDocProcessExecutorService)
                 .to("direct:uploadProcessPati")
                 .end();

         from("direct:uploadProcessPati").routeId("uploadRoutePati")
                 .bean(staasMigrationService, "processMigrationPati")
                 .end();

         from("direct:endPati").routeId("endRoutePati")
                 .bean(staasMigrationPayloadService, "updatePatiProcessEnd")
                 .end();
         /* end Pati Migration */
    }

}
