package gov.uspto.pe2e.intake.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import gov.uspto.pe2e.intake.util.StaasMigrationConstants;
import gov.uspto.pe2e.lda.model.entity.StaasMigrationPayloadResultSet;
import gov.uspto.pe2e.lda.model.entity.StaasReprocessPayloadResultSet;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author asrinivasula
 * 
 */
@Slf4j
@Component
public class StaasMigrationPayloadJDBCTemplateDao {

	public static final String TIME_TAKEN_TO_DB_FETCH_RECORD_DOCUMENT_RESOURCE_ID = "Time Taken to DB_Fetch record document Resource-IDs for Server_Id ";

	public static final String SERVER_NAME = "server_name";
	
	public static final String SERVER_ID = "server_id";
	
    public static final String TXT_PATIPAYLOADLIMIT = "patiPayLoadLimit";

    public static final String PATI_PAYLOADIDS = "patiBulkPayloadIds";

	@Autowired
	private JdbcTemplate ldaJdbcTemplate;
	
	@Autowired
	private NamedParameterJdbcTemplate ldaNamedJdbcTemplate;

	public StaasMigrationPayloadResultSet getStaasMigrationPayload (final String serverName){
		long startTime = System.nanoTime();
		StaasMigrationPayloadResultSet staasMigrationPayloadResultSet = null;
		try{
			MapSqlParameterSource namedParameters =  new MapSqlParameterSource();            
			namedParameters.addValue(SERVER_NAME, serverName);
			List<StaasMigrationPayloadResultSet> staasMigrationPayloadResultSetList = ldaNamedJdbcTemplate.query(StaasMigrationConstants.GET_PAYLOAD_QUERY,
					namedParameters, new DbResultsetRowMapper());
			if(staasMigrationPayloadResultSetList!=null && staasMigrationPayloadResultSetList.size()>StaasMigrationConstants.ZERO){
				staasMigrationPayloadResultSet = staasMigrationPayloadResultSetList.get(StaasMigrationConstants.ZERO);
			}
		} catch (EmptyResultDataAccessException e) {
			log.warn("getDocRgetStaasMigrationPayloadeourceById: No getStaasMigrationPayload found");
		}
		log.info(TIME_TAKEN_TO_DB_FETCH_RECORD_DOCUMENT_RESOURCE_ID +serverName + " Time Taken in MILLISECONDS " +
				TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS)+" "+staasMigrationPayloadResultSet);
		return staasMigrationPayloadResultSet;
	}
		
	public int updateStaasMigrationPayloadLock(Long id, Long lockNo,Timestamp startTime) {
		int result = 0;
		try {
			result = ldaJdbcTemplate.update(StaasMigrationConstants.UPDATE_LOCK,lockNo,startTime,id);
		} catch (Exception e) {
			log.error("updateStaasMigrationPayloadLock: Exception caught - " + e);
		}
		return result;
	}
	
	
	public int updateStaasMigrationPayloadCount(Long id, Long count) {
		int result = 0;
		try {
			result = ldaJdbcTemplate.update(StaasMigrationConstants.UPDATE_COUNT,count,id);
		} catch (Exception e) {
			log.error("updateStaasMigrationPayloadCount: Exception caught - " + e);
		}
		return result;
	}
	
	public void persistStaasMigrationPayload(Long startDocResourceId, Long endDocResourceId){
        try {
        	 ldaJdbcTemplate.update(StaasMigrationConstants.INSERT_QUERY,startDocResourceId,endDocResourceId,
        			 StaasMigrationConstants.LONG_ZERO,StaasMigrationConstants.LONG_ZERO,
        			 StaasMigrationConstants.LONG_ZERO,StaasMigrationConstants.LONG_ZERO);
        } catch (Exception e) {
        	log.error("persistStaasMigrationPayload: Exception caught - " + e);
        }
    }
	
	public int updateStaasMigrationPayloadDeletein(Long id,Timestamp endTime) {
		int result = 0;
		try {
			result = ldaJdbcTemplate.update(StaasMigrationConstants.UPDATE_DELETE_IN,endTime,id);
		} catch (Exception e) {
			log.error("updateStaasMigrationRowDeletein: Exception caught - " + e);
		}
		return result;
	}	
	
	public String staasMigrationEnabledFlag (final String serverName) {	
		String result = null;
		try{
			MapSqlParameterSource namedParameters =  new MapSqlParameterSource();            
			namedParameters.addValue(SERVER_NAME, serverName);
			result = ldaNamedJdbcTemplate.queryForObject(StaasMigrationConstants.GET_SERVER_DELETE,
					namedParameters, String.class);
		} catch (EmptyResultDataAccessException e) {
			log.warn("staasMigrationEnabledFlag: No staasMigrationEnabledFlag found");
		}
		return result;
	}
	
	public Long getStndServerIdbyName(final String serverName) {	
		Long result = null;
		try{
			MapSqlParameterSource namedParameters =  new MapSqlParameterSource();            
			namedParameters.addValue(SERVER_NAME, serverName);
			result = ldaNamedJdbcTemplate.queryForObject(StaasMigrationConstants.GET_SERVER_ID,
					namedParameters, Long.class);
		} catch (EmptyResultDataAccessException e) {
			log.warn("getStndServerIdbyName: No getStndServerIdbyName found");
		}
		return result;
	}
	

	
	public List<StaasReprocessPayloadResultSet> getStaasReProcessPayload (final Long serverId){
		long startTime = System.nanoTime();
		List<StaasReprocessPayloadResultSet> staasReprocessPayloadResultSetList = null;
		try{
			MapSqlParameterSource namedParameters =  new MapSqlParameterSource();            
			namedParameters.addValue(SERVER_ID, serverId);
			staasReprocessPayloadResultSetList = ldaNamedJdbcTemplate.query(StaasMigrationConstants.GET_REPROCESS_PAYLOAD_QUERY,
					namedParameters, new DbReprocessResultsetRowMapper());
		} catch (EmptyResultDataAccessException e) {
			log.warn("getStaasReProcessPayload: No getStaasMigrationPayload found");
		}
		log.info(TIME_TAKEN_TO_DB_FETCH_RECORD_DOCUMENT_RESOURCE_ID +serverId + " Time Taken in MILLISECONDS " +
				TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS));
		return staasReprocessPayloadResultSetList;
	}
	
	
	
	
	public int updateStaasReProcessPayloadLock(Long id,Long lockNo,Timestamp startTime) {
		int result = 0;
		try {
			result = ldaJdbcTemplate.update(StaasMigrationConstants.UPDATE_REPROCESS_LOCK,lockNo,startTime,id);
		} catch (Exception e) {
			log.error("updateStaasReProcessPayloadLock: Exception caught - " + e);
		}
		return result;
	}
	
	
	public int updateStaasReProcessPayloadDeletein(Long id,Timestamp endTime) {
		int result = 0;
		try {
			result = ldaJdbcTemplate.update(StaasMigrationConstants.UPDATE_REPROCESS_DELETE_IN,endTime,id);
		} catch (Exception e) {
			log.error("updateStaasReProcessPayloadDeletein: Exception caught - " + e);
		}
		return result;
	}
	

	public void persistStaasReprocessPayload(Long docResourceId,String details,String fileId, Long errorCode){
        try {
        	 ldaJdbcTemplate.update(StaasMigrationConstants.REPROCESS_INSERT_QUERY,docResourceId,details,
        			 StaasMigrationConstants.LONG_ZERO,StaasMigrationConstants.LONG_SIX,
        			 StaasMigrationConstants.LONG_ZERO,StaasMigrationConstants.LONG_ZERO,fileId,errorCode);
        } catch (Exception e) {
        	log.error("persistStaasReprocessPayload: Exception caught - " + e);
        }
    }
	
	/*
	 * Pati one time migration methods 
	 */
   
   
    

    public StaasMigrationPayloadResultSet getDocumentAppIdByServerIdForStaasPayLoad (final String serverName){
        log.info("Start of getDocumentAppIdByServerIdForStaasPayLoad");
        long startTime = System.nanoTime();// getStartTime
        StaasMigrationPayloadResultSet staasMigrationPayloadResultSet = ldaJdbcTemplate.query(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                return con.prepareStatement(StaasMigrationConstants.GET_ONETIME_PATI_MIG_PATI_PAYLOAD_APPID);
            }
        }, new PreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setString(1, serverName);
            }
        }, new ResultSetExtractor<StaasMigrationPayloadResultSet>() {
            @Override
            public StaasMigrationPayloadResultSet extractData(ResultSet rs) throws SQLException  {
                StaasMigrationPayloadResultSet results = new StaasMigrationPayloadResultSet();
                while (rs.next()) {
                    results.setId(rs.getLong("id"));
                    results.setApplicationId(rs.getString("appId"));
                    results.setSrndSreverName(rs.getString("srndSrever"));
                    results.setRetryActualNo(rs.getInt("retryActualNo"));
                    results.setLockCtrlNo(rs.getInt("lockCtrlNo"));
                    results.setSoftDeleted(rs.getInt("softDeleted"));                   
                    results.setStartTs(rs.getTimestamp("startTs"));
                    results.setEndTs(rs.getTimestamp("endTs"));
                    results.setCount(rs.getLong("count"));
                }
                rs.close();
                return results;
            }
        });
        long estimatedTime = System.nanoTime() - startTime; // Calculate the
        // total time taken     
        log.info(TIME_TAKEN_TO_DB_FETCH_RECORD_DOCUMENT_RESOURCE_ID +serverName + "Time Taken in MILLISECONDS " +
                 TimeUnit.MILLISECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS)+staasMigrationPayloadResultSet);
        return staasMigrationPayloadResultSet;
    }
   
    public List<StaasMigrationPayloadResultSet> getBulkPaatiPayloadAppIdsByServer(final String serverName) {
        log.info("Start of getBulkPayloadAppIdsByServerId");
        long startTime = System.nanoTime();// getStartTime
        List<StaasMigrationPayloadResultSet> lstStaasMigrationPayloadResultSet = null;
        try {
            MapSqlParameterSource namedParameters = new MapSqlParameterSource();
            namedParameters.addValue(SERVER_NAME, serverName);
            namedParameters.addValue(TXT_PATIPAYLOADLIMIT, StaasMigrationConstants.PATI_PALYLOAD_LIMIT);
            lstStaasMigrationPayloadResultSet = ldaNamedJdbcTemplate.query(StaasMigrationConstants.GET_BULK_PATI_MIG_PAYLOAD_APPIDS,
                    namedParameters, new PatiPayloadResultsetRowMapper());

        } catch (EmptyResultDataAccessException e) {
            log.warn("getBulkPayloadAppIdsByServerId: No getStaasMigrationPayload found");
        }

        long estimatedTime = System.nanoTime() - startTime; // Calculate the
        // total time taken     
        log.info(TIME_TAKEN_TO_DB_FETCH_RECORD_DOCUMENT_RESOURCE_ID + serverName + "Time Taken in MILLISECONDS " +
                TimeUnit.MILLISECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS) + lstStaasMigrationPayloadResultSet);
        return lstStaasMigrationPayloadResultSet;
    }
    
    public int updateStaasOneTimeMigrationPayloadLock(Long id,Long lockNo,Timestamp startTime) {
        int result = 0;
        try {
            result = ldaJdbcTemplate.update(StaasMigrationConstants.UPDATE_LOCK_PATI,lockNo,startTime,id);
        } catch (Exception e) {
            log.error("updateStaasOneTimeMigrationPayloadLock: Exception caught - " + e);
        }
        return result;
    }
    
    //Updates the retry count to +1
    public int updateStaasOneTimeMigrationPayloadRetryCount(Long id) {
        int result = 0;
        try {
            result = ldaJdbcTemplate.update(StaasMigrationConstants.UPDATE_RETRYCOUNT_PATI, id);
        } catch (Exception e) {
            log.error("updateStaasOneTimeMigrationPayloadRetryCount: Exception caught - " + e);
        }
        return result;
    }
        
   
    public int updatePatiStaasMigrationCount(Long id,Long count) {
        int result = 0;
        try {
            result = ldaJdbcTemplate.update(StaasMigrationConstants.UPDATE_COUNT_PATI,count,id);
        } catch (Exception e) {
            log.error("updatepatiStaasMigrationCount: Exception caught - " + e);
        }
        return result;
    }
     
    
    public int updatepatiStaasMigrationCompletion(Long id,Timestamp endTime) {
        int result = 0;
        try {
            result = ldaJdbcTemplate.update(StaasMigrationConstants.UPDATE_DELETE_IN_PATI,endTime,id);
        } catch (Exception e) {
            log.error("updatepatiStaasMigrationCompletion: Exception caught - " + e);
        }
        return result;
    }
    
	public int updatePatiPayloadFailOverFlag(String applicationId) {
		int result = 0;
        try {
            result = ldaJdbcTemplate.update(StaasMigrationConstants.UPDATE_PATI_PAYLOAD_FAILOVER,applicationId);
        } catch (Exception e) {
            log.error("updatePatiPayloadFailOverFlag: Exception caught - " + e);
        }
        return result;
		
	}
	
	
	public int updateNullPayloadCountPatiStaasMigration(Long id,Timestamp endTime) {
        int result = 0;
        try {
            result = ldaJdbcTemplate.update(StaasMigrationConstants.UPDATE_NULL_PAYLOAD_COUNT_PATI,endTime,id);
        } catch (Exception e) {
            log.error("updateNullPayloadCountPatiStaasMigration: Exception caught - " + e);
        }
        return result;
    }
	
	public void updatePatiDeleteIndicator(List<StaasMigrationPayloadResultSet> lstBulkStaasPatiMigrationPayload) {
        try {
            final List<Long> lstPatiBulkPayLoadIds = new ArrayList<>();
            for (StaasMigrationPayloadResultSet staasMigrationPayloadResultSet : lstBulkStaasPatiMigrationPayload) {
                lstPatiBulkPayLoadIds.add(staasMigrationPayloadResultSet.getId());
            }

            Map<String, ?> paramMap = Collections.singletonMap(PATI_PAYLOADIDS, lstPatiBulkPayLoadIds);
            ldaNamedJdbcTemplate.update(StaasMigrationConstants.UPDATE_DELETE_INDICATOR_FOR_PATI, paramMap);

        } catch (Exception e) {
            log.error("updatePatiDeleteIndicator: Exception raised in update", e);
        }
    }

	public boolean ldaDatabaseCheck(){
		return 	ldaJdbcTemplate.queryForObject(StaasMigrationConstants.HEALTH_CHECK_QUERY,String.class)!=null;
	}
	
	class DbResultsetRowMapper implements RowMapper<StaasMigrationPayloadResultSet> {
		public StaasMigrationPayloadResultSet mapRow(ResultSet rs, int rowNum) throws SQLException {
			StaasMigrationPayloadResultSet result = new StaasMigrationPayloadResultSet();
			result.setId(rs.getLong(StaasMigrationConstants.ONE));
			result.setStartDocResourceId(rs.getLong(StaasMigrationConstants.TWO));					
			result.setEndDocResourceId(rs.getLong(StaasMigrationConstants.THREE));
			result.setSrndSreverName(rs.getString(StaasMigrationConstants.FOUR));
			result.setRetryActualNo(rs.getInt(StaasMigrationConstants.FIVE));
			result.setLockCtrlNo(rs.getInt(StaasMigrationConstants.SIX));
			result.setSoftDeleted(rs.getInt(StaasMigrationConstants.SEVEN));					
			result.setStartTs(rs.getTimestamp(StaasMigrationConstants.EIGHT));
			result.setEndTs(rs.getTimestamp(StaasMigrationConstants.NINE));
			result.setCount(rs.getLong(StaasMigrationConstants.TEN));
			return result;
		}
	}
	
	class DbReprocessResultsetRowMapper implements RowMapper<StaasReprocessPayloadResultSet> {
		public StaasReprocessPayloadResultSet mapRow(ResultSet rs, int rowNum) throws SQLException {
			StaasReprocessPayloadResultSet result = new StaasReprocessPayloadResultSet();
			result.setId(rs.getLong(StaasMigrationConstants.ONE));
			result.setDocResourceId(rs.getLong(StaasMigrationConstants.TWO));					
			result.setDetails(rs.getString(StaasMigrationConstants.THREE));
			result.setSrndSreverName(rs.getString(StaasMigrationConstants.FOUR));
			result.setRetryActualNo(rs.getInt(StaasMigrationConstants.FIVE));
			result.setLockCtrlNo(rs.getInt(StaasMigrationConstants.SIX));
			result.setSoftDeleted(rs.getInt(StaasMigrationConstants.SEVEN));					
			result.setStartTs(rs.getTimestamp(StaasMigrationConstants.EIGHT));
			result.setEndTs(rs.getTimestamp(StaasMigrationConstants.NINE));
			result.setFileId(rs.getString(StaasMigrationConstants.TEN));
			return result;
		}
	}
	
	class PatiPayloadResultsetRowMapper implements RowMapper<StaasMigrationPayloadResultSet> {
        public StaasMigrationPayloadResultSet mapRow(ResultSet rs, int rowNum) throws SQLException {
            StaasMigrationPayloadResultSet result = new StaasMigrationPayloadResultSet();
            result.setId(rs.getLong("id"));
            result.setApplicationId(rs.getString("appId"));
            result.setSrndSreverName(rs.getString("srndSrever"));
            result.setRetryActualNo(rs.getInt("retryActualNo"));
            result.setLockCtrlNo(rs.getInt("lockCtrlNo"));
            result.setSoftDeleted(rs.getInt("softDeleted"));
            result.setStartTs(rs.getTimestamp("startTs"));
            result.setEndTs(rs.getTimestamp("endTs"));
            result.setCount(rs.getLong("count"));

            return result;
        }
    }
}
