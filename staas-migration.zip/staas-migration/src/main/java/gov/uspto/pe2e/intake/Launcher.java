package gov.uspto.pe2e.intake;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Launcher {
    private Launcher() {
    }

    public static void main(String[] args) throws Exception {

        if (args != null && args.length > 0) {
            new RunStaasMigration().exec(args[0]);
        } else {
            log.info("args is null..");
        }
    }
}
