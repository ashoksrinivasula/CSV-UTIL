package gov.uspto.pe2e.intake;

import java.net.InetAddress;

import org.apache.camel.CamelContext;
import org.apache.camel.spring.SpringCamelContext;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import gov.uspto.pe2e.intake.dao.StaasMigrationPayloadJDBCTemplateDao;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RunStaasMigration{ 

	public static final String STAAS_MIGRATION_FLAG_N = "N";
	public static final String STAAS_MIGRATION_FLAG_ZERO = "0";

	public void exec(String migrarionType) throws Exception {
		ApplicationContext appContext = new ClassPathXmlApplicationContext("META-INF/spring/camelContext.xml");
		StaasMigrationPayloadJDBCTemplateDao ldaDao = appContext.getBean(StaasMigrationPayloadJDBCTemplateDao.class);
		CamelContext camelContext = null;
		try {
			log.info("***** Starting Camel Context *****"+migrarionType);
			camelContext = SpringCamelContext.springCamelContext(appContext, false);
			camelContext.start();
			if(migrarionType.trim().equalsIgnoreCase("reprocess")){				
				camelContext.startRoute("reprocessTimerRoute");
				camelContext.startRoute("reprocessRoute");
				camelContext.startRoute("reProcessUploadRoute");
				camelContext.startRoute("reProcessendRoute");
				
			}else if(migrarionType.trim().equalsIgnoreCase("migration")){
				camelContext.startRoute("endRoute");
				camelContext.startRoute("uploadRoute");
				camelContext.startRoute("startRoute");
				camelContext.startRoute("timerRoute");
			}else if (migrarionType.trim().equalsIgnoreCase("patiMigration")){			    
			    log.info("***** pati-migration *****");
				camelContext.startRoute("timerRoutePati");
				camelContext.startRoute("startRoutePati");
				camelContext.startRoute("routePatiIndividualApp");
				camelContext.startRoute("uploadRoutePati");
				camelContext.startRoute("endRoutePati");
			}else{
				log.error("Invalid Option Entered -->"+migrarionType);
				camelContext.stop();
				log.info("***** Invalid Option Completed Shutdown Camel Context *****");
				return;
			}
			while (true) {
				InetAddress addr = InetAddress.getLocalHost();
				String serverName = addr.getHostName();
				String flag =   ldaDao.staasMigrationEnabledFlag(serverName);
				if (!(STAAS_MIGRATION_FLAG_N.equalsIgnoreCase(flag)
						|| STAAS_MIGRATION_FLAG_ZERO.equalsIgnoreCase(flag))) {
					log.info("***** Server delete_in flag set to "+flag+" hence Starting Shutdown Camel Context *****");
					camelContext.stop();
					log.info("***** Completed Shutdown Camel Context *****");
					return;
				} 
				log.info("StaasMigrationEnabledFlag Enabled for Server Name "+serverName);
				Thread.sleep(60000);
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			if (null != camelContext)
				camelContext.stop();
		}
	} 
}
